;;
;; Demo Test unit
;;

;; Load unit testing module
;(real-path)
;(change-dir "F:\\Lisp-Scheme\\newLisp\\MAX\\_unit-test")
(load "nl-unittest.lsp")

;; Functions to test
;(load "test.lsp")
(define (somma a b) (+ a b))
(define (sottrae a b) (- a b))

;; Tests

(define-test (test_somma_1)
  (assert= 2
           (somma 1 1)))

(define-test (test_somma_2)
 (assert= 0
          (somma 1 -1)))

(define-test (test_sottrae_1)
  (assert= (+ 2 2)
           (sottrae 8 4)))

(define-test (test_all)
  (assert= 0
           (somma 4 (sottrae 4 8))))

(UnitTest:run-all 'MAIN)
;-> ======================================================================
;-> === Testing (MAIN:test_all)
;-> >>> Total assertions: 1
;->   - 1 pass(es)
;->   - 0 fail(s)
;->   - Total time: 0ms
;-> 
;-> ----------------------------------------------------------------------
;-> === Testing (MAIN:test_somma_1)
;-> >>> Total assertions: 1
;->   - 1 pass(es)
;->   - 0 fail(s)
;->   - Total time: 0ms
;-> 
;-> ----------------------------------------------------------------------
;-> === Testing (MAIN:test_somma_2)
;-> >>> Total assertions: 1
;->   - 1 pass(es)
;->   - 0 fail(s)
;->   - Total time: 0ms
;-> 
;-> ----------------------------------------------------------------------
;-> === Testing (MAIN:test_sottrae_1)
;-> >>> Total assertions: 1
;->   - 1 pass(es)
;->   - 0 fail(s)
;->   - Total time: 0ms
;-> 
;-> ----------------------------------------------------------------------
;-> STATUS:
;-> ==> RAN 4 test(s) IN 0.996ms
;-> ==> ALL PASSED!!!
;-> ======================================================================
;-> 
;-> true
;(println)
;(exit)