def f(x):
  return (x * x)

for i in range (11):
  print(f(i))

