
#include <stdio.h>

int main()
{
        fprintf(stdout, "Standard Output\n");
        fprintf(stderr, "Standard Error\n");
        return 0;
}
