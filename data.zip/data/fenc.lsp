; demo encrypt file
(define (showinfo) (println "demo encrypt file"))

(define (somma x y) (add x y))
