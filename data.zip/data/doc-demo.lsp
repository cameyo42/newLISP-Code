;; @module doc-demo.lsp
;; @author X Y, xy@doc-demo.com
;; @version 1.0
;; 
;; Questo modulo è un esempio per mostrare
;; il funzionamento del programma newlispdoc
;; che genera automaticamente documentazione
;; per i sorgenti newLISP.

;; @syntax (demo:celsius->fahrenheit gradi-celsius)
;; @param <gradi-celsius> valore in gradi Celsius.
;; @return restituisce il valore in gradi Fahrenheit.
;;
;; La funzione 'celsius->fahrenheit' converte
;; i gradi Celsius in gradi Fahrenheit.
;;
;; @example
;; (celsius->fahrenheit 0)        ==> 32
;; (celsius->fahrenheit 100)      ==> 212
;; (celsius->fahrenheit -273.15)  ==> -459.67

; Creiamo le funzioni in un nuovo contesto
(context 'demo)

(define (celsius->fahrenheit gradi-celsius)
  (add (div (mul gradi-celsius 9) 5) 32))

;; @syntax (demo:fahrenheit->celsius gradi-fahrenheit)
;; @param <gradi-fahrenheit> valore in gradi Fahrenheit.
;; @return restituisce il valore in gradi Celsius.
;;
;; The function 'celsius->fahrenheit' converte
;; i gradi Celsius in gradi Fahrenheit.
;;
;; @example
;; (fahrenheit->celsius 32)       ==> 0
;; (fahrenheit->celsius 212)      ==> 100
;; (fahrenheit->celsius -459.67)  ==> -273.15

(define (fahrenheit->celsius gradi-fahrenheit)
  (div (mul (sub gradi-fahrenheit 32) 5) 9))

; Ritorniamo al contesto principale
(context MAIN)
; eof ;