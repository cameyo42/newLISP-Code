  data = load('sfera500.txt');
  figure;
  scatter3(data(:,1), data(:,2), data(:,3), 'filled');
  title('3D Plot');
  xlabel('X-axis');
  ylabel('Y-axis');
  zlabel('Z-axis');
  axis equal;
