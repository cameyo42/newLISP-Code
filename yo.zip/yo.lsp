;===========================================================================
;; @module yo.lsp
;; @author cameyo 2020-2026 (MIT-0 Licence)
;; @description Module for recreational mathematics and problem solving
;; @version 0.96
;;
;; Library for newLISP 10.7.5
;;
;; 420 functions
;;
;; Load library: (load "yo.lsp")
;;
;; List of functions: (yo-list)
;;
;; yo-library loaded?: yo-library
;;
;; Create help file: newlisp newlispdoc -s yo.lsp
;;

; SECTIONS
; Constants
; Main
; Hash-map
; Conversions
; Boolean
; Fractions
; Complex numbers
; Time Arithmetic
; Mathematical functions
; Lists & Strings
; Combinatorics
; Number Theory
; Numerics
; Statistics
; Geometry
; Graphs
; Random
; Dates
; Bit manipulation
; CAR and CDR
; Miscellaneous
;===========================================================================

;===========================================================================
; FUNCTIONS LIST (alphabetic order)
;===========================================================================
; **: Calculate the integer power of an integer
; *f: Multiplicate two or more fractions (frac1 * frac2)
; +f: Sum two of more fractions (frac1 + frac2)
; -f: Subtract two or more fractions (frac1 - frac2)
; /f: Divide two or more fractions (frac1 / frac2)
; add-poly: Addition between two polynomials
; adjacent4-matrix: Calculate the values of cells adjacent to a cell in a matrix (4 cells)
; adjacent8-matrix: Calculate the values of cells adjacent to a cell in a matrix (8 cells)
; all-contiguous-splits: Split a list into two contiguous sublists in all possible ways
; anagrams: Calculate all the anagrams of a string
; append-nil: Appends multiple objects into one
; ascii-table: Print the ASCII table
; ascii-map: Return the ASCII table
; assoc+: Search a key in an associative list
; b1-b2: Convert an integer from base1 to base2 (2 <= base <= 10)
; back: Change the color of terminal background (ANSI sequence)
; base10-baseX: Convert a number from base 10 to base X <= 10 (return integer)
; baseX-base10: Convert a number from base X <= 10 to base 10 (return integer)
; base10-baseN: Convert a number from base 10 to base N (<=62)
; baseN-base10: Convert a number from base N (<=62) to base 10
; bairstow: Find the roots of a real polynomial of arbitrary degree
; beep: Play a beep (sound)
; bellman-ford: Calculate shortest paths from a node to all other nodes of a graph
; between-close: Return true iff number x is >= y and <= z
; between-open: Return true iff number x is > y and < z
; bigint-int: Convert a big-integer to int (if possible)
; bin-dec: Convert a bynary string to decimal integer
; binary-bigint: Convert a binary string to big integer
; binary-search: Search an item on a sorted list
; binom: Calculate the binomial coefficient (n k) = n!/(k!*(n - k)!) (combinations of k elements without repetition from n elements)
; bit0-count: Count the bit 0 of an integer
; bit1-count: Count the bit 1 of an integer
; bits-i: Convert a decimal integer (big integer) to binary string
; break: Debugging aid: break execution of function with condition and print symbols/value
; butlast: Return the list or string without the last num elements (default num=1)
; car: Return the first element of a list or the first character of a string
; cart-polar: Convert cartesian coordinate to polar coordinate
; cartesian: Calculate the cartesian product of lists
; cartesian-product: Calculate the cartesian product of a list of lists
; cbrt: Calculate the cube root of a number
; cdr: Return all of the items in a list or a string, except for the first
; center-string: Justify a string to the center
; cls: Clear screen of REPL (ANSI sequence)
; cels-fahr: Convert Celsius degrees to Fahrenheit degrees
; cf-fract: Calculate the convergent fraction of a continuous fraction
; cf-num: Calculate the number of a continued fraction
; char-int: Return the ASCII code of a character
; chars-str: Convert a list of chars to string
; check-sislin: Check the solution of a linear system (backwards substitution)
; chinese: Apply the chinese remainder theorem to solve a congruence system
; clean-str: Clean chars from a string
; clear-bit: Clear the bit at the ith position of an integer
; clear-lsb: Clear the least significant bit of an integer
; clear-msb: Clear the most significant bit of an integer
; collatz: Generate the collatz sequence of a positive integer number
; collatz-length: Calculate the length of the collatz sequence of a positive integer number
; comb: Generate all combinations of k elements without repetition from a list of items
; comb-list lst: Generate all combinations by choosing one element from each sublist
; comb-rep: Generate all combinations of k elements with repetition from a list of items
; coprime?: Check if two integer are coprime
; correlation: Calculate correlation coefficient between two lists of numbers
; count-obj: Count elements of lst-obj in obj and returns a list of those counts
; count-same: Count the number of equal element of two list (same value, same index)
; couples: Generate all the couples of a list
; cross-product: Calculate the cross-product of two list/array of length 3
; cube?: Check if an integer is a perfect cube
; cubic: Find the solutions of the cubic equation: A*x^3 + B*x^2 + C*x + D = 0
; curry-s: Extend curry with multiple parameters
; cx-add: Addition of two complex number (cartesian)
; cx-cart2cx-exp: Convert a complex number from cartesian form to exponential form
; cx-conj: Conjugate of a complex number
; cx-div: Division of two complex number (cartesian)
; cx-exp2cx-cart: Convert a complex number from exponential form to cartesian form
; cx-inv: Inverse (reciprocal) of a complex number (cartesian)
; cx-mul: Multiplication of two complex number (cartesian)
; cx-pow: Power of a complex number (cartesian)
; cx-sqrt: Square root of a complex number (cartesian)
; cx-sub: Subtraction of two complex number (cartesian)
; data-list: Generate a list of dates (yyyy mm dd) from data1 to data2
; decimal-period: Calculate integer division m/n, its antiperiod and period
; dec-bin: Convert a decimal integer to binary string
; dec-hex: Convert a decimal integer to hexadecimal string
; def-static: Function to create other statically scoped functions
; deg-rad: Convert decimal degrees to radiants
; deg10-deg60: Convert decimal degrees to sexagesimal degrees
; deg60-deg10: Convert sexagesimal degrees to decimal degrees
; delta%: Calculate the percentage change between two numbers x and y
; derivative: Calculate the arithmetic derivative of an integer
; deter-int: Calculate the determinant of an integer matrix
; die : Roll a die with S sides
; die6: Roll a die with 6 sides
; dice-sum: Roll N dice with S sides and return the sum of numbers
; dice6-sum: Roll N dice with 6 sides and return the sum of numbers
; dice-lst: Roll N dice with S sides and return the list of numbers
; dice6-lst: Roll N dice with 6 sides and return the list of numbers
; dice-lst-freq: Roll N dice with s sides and return a list with the frequency of all sides
; dice6-lst-freq: Roll N dice with 6 sides and return a list with the frequency of all sides
; dice-pick lst: Roll a non-fair dice with N sides
; diff-sum: Calculate the alternate diff/sum of integers of a list
; different-digits?: Check if an integer has all digits different
; digit-cube-sum: Sum the cubes of digits of a number
; digit-min: Find the smallest digit of an integer
; digit-max: Find the largest digit of an integer
; digit-prod: Calculate the product of the digits of an integer
; digit-root: Calculate the repeated sum of the digits of an integer
; digit-sum: Calculate the sum of the digits of an integers
; digit-square-sum: Sum the squares of digits of a number
; digit?: Check if a char is a digit (0..9)
; diofantea: Solve a linear Diophantine equation ax + by = c
; dism: Generate all dismutations without repeating from a list of items
; dist: Calculate Cartesian distance of two points N dimensional: P1=(x1 y1 ... z1) e P2=(x2 y2 ... z2)
; dist-chebyshev: Calculate Chebyshev distance of two points P1=(x1 y1) e P2=(x2 y2)
; dist-chebyshevN: Calculate Chebyshev distance of two points N dimensional: P1=(x1 y1 ... z1) e P2=(x2 y2 ... z2)
; dist-earth: Calculate the minimal distance of two points on a sphere with haversine formula
; dist-manh4: Calculate Manhattan distance (4 directions - rook) of two points P1=(x1 y1) e P2=(x2 y2)
; dist-manh8: Calculate Manhattan distance (8 directions - queen) of two points P1=(x1 y1) e P2=(x2 y2)
; dist2d: Calculate 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)
; dist2d-2: Calculate the square of 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)
; dist3d: Calculate 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)
; dist3d-2: Calculate the square of 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)
; div-poly: Division between two polynomials
; divide: Calculate the division num1/num2 with a predefined number of digits after the decimal point
; divisors: Generate all the divisors of an integer number
; divisors-count: Count the divisors of an integer number
; divisors-sum: Sum all the divisors of integer number
; doc: Return the docstring, if present, of a function
; dot-product: Calculate the dot-product of two list/array of arbitrary length
; egypt: Calculate the egyptian fractions of a generic fraction
; emit: Print name and value of quoted symbols and values
; eval-rpn: Evaluate a RPN expression
; extract-matrix: Extract a submatrix from a matrix
; fact-i: Calculate the factorial of an integer number
; fact-i-arr: Create an array of factorials for numbers 0..num
; factor-group: Factorize an integer number
; factor-i: Factorize a big integer number
; factorizations: Calculate all the factorizations of an integer number
; fahr-cels: Convert Fahrenheit degrees to Celsius degrees
; faircoin: Simulate the flip of a coin (John VonNeumann algorithm)
; fibo-i: Calculate the Fibonacci number of an integer number
; file-list: Create a list with all the lines of a text file
; filter-str: Filter chars from a string
; find-all-ref: Find all start indexes of a substring in a string
; find-ceil: Find in a list the integer closest to x that is greater than or equal to x
; find-closest: Find closest number in a list
; find-floor: Find in a list the integer closest to x that is less than or equal to x
; find-from-end: Find an element from the end of a list
; first-digit: Return the first digit of a non-negative integer
; fore: Change the color of terminal foreground (text) (ANSI sequence)
; frac-gen: Find the generating fraction of a floating number (periodic or non-periodic)
; fract-cf: Calculate all the terms of the continued fraction of a fraction
; fractional: Return the fractional part of a number
; free-vars: Print a list of free symbols/variables
; frequency: Calculate the count and the frequency of items in a list
; func-xy: Create a list of points of a function y=f(x)
; gale-shapley: Bind all the n items of group A with the n items of group B based on preferences of each items
; gather: Gather the elements of list into sublists of identical elements
; gcd-frac: Calculate lcm of two or more fractions
; gdate-add: Add days to a gregorian date
; gdate-diff: Calculate the difference between two gregorian dates
; gdate-julian: Convert gregorian date to julian day number (valid only from 15 ottobre 1582 A.D.)
; gdate-sub: Subtract days from a gregorian date
; gensym: Generate a unique symbol
; get-bit: Get the bit at the ith position of an integer
; get-lsb: Get the least significant bit of an integer
; get-msb: Get the most significant bit of an integer
; group-all: Generate all partitions of a set into two disjoint, complementary sublists of size (k, N-k), with 1 ≤ k ≤ floor(N/2)
; group-half: Generate all partitions of a set into two disjoint, complementary sublists of size (N/2, N/2) (or (N/2, (N/2 + 1))
; group-block: Create a list with blocks of elements: (0..num) (1..num+1) (n..num+n)
; group-by-first: Group the values of the sublists based on the first value of each sublist
; groups: Group the elements of a set into disjoint sublists
; hash-clear: Delete all the items of a hash-map
; hash-create: Create a hash-map
; hash-del: Delete an item with a predefinite key from a hash-map
; hash-destroy: Destroy a hash-map
; hash-empty?: Check if a hash-map is empty
; hash-get-key: Get the key with a predefinite value from a hash-map
; hash-get-val: Get the value with a predefinite key from a hash-map
; hash-items: Generate the list of all the items (key value) of a hash-map
; hash-key?: Check the existence of a predefinite key in a hash-map
; hash-keys: Generate the list of all the keys of a hash-map
; hash-map-lambda: Apply a function to all the items of a hash-map
; hash-set: Insert an item (key value) in a hash-map
; hash-set-alist: Insert an associative list in a hash-map
; hash-set-list: Insert a list in a hash-map (autocreate key)
; hash-size: Length of a hash-map
; hash-value?: Check the existence of a predefinite value in a hash-map
; hash-values: Generate the list of all the values of a hash-map
; hash?: Check if a symbol is a hash-map
; hayashi: Function symmetric to curry
; hex-dec: Convert a hexadecimal string to decimal integer
; histogram: Print the histogram of a list of integer numbers
; hsv-rgb: Convert a color from hsv to rgb
; index-items: Find the index of all elements of a list in another list
; index-list: Create a list of indexes for all the elements of a list
; index-seq: Find the sequence of elements of a list in another list
; insert-k: Insert element into a list every k
; int-char: Return the character of an ASCII code (0-255)
; int-list: Convert an integer to a list of digits
; int-roman: Convert an integer to a roman number
; intersects: Calculate intersection of lists (sets)
; jdate-julian: Convert julian date to julian day number (valid only until 4 ottobre 1582 A.D.)
; julian-gdate: Convert julian day number to gregorian date (valid only from 15 ottobre 1582 A.D.)
; julian-jdate: Convert julian day number to julian date (valid only until 4 ottobre 1582 A.D.)
; julian-weekday: Find the day of week (number) of a julian day number
; lcm: Calculate the lcm of two or more number
; lcm-frac: Calculate lcm of two or more fractions
; last-digit: Return the last digit of a non-negative integer
; leap?: Check if a year is a leap year
; left-string: Justify a string to the left
; levenshtein: Calculate the difference between two strings (Levenshtein distance)
; line-fit: Calculate the coefficients of linear regression of a list of points
; list-array: Convert a list to an array
; list-break: Break a list into sub-lists of specified lengths
; list-csv: Create a file csv from a list
; list-int: Convert a list of digits to integer
; list-IM: Create a graphic file (RGBA 8 bit) from a list of coords (with ImageMagick)
; log-i: Calculate the integer logarithm of a positive number
; lookup+: Search a key in an associative list
; lower?: Check if a char is lowercase (a..z)
; lst-str: Convert a list of symbols to string
; make-poly: Generate a function who evaluate a polynomial with those coefficients
; make-poly-horner: Generate a function who evaluate (horner) a polynomial with those coefficients
; map-all: Apply a function to all the elements of annidate list
; match?: Wildcard string matching
; matrix-eye: Generate an identity matrix
; matrix-poly: Calculate the characteristic polynomial of a matrix: p(λ) = λ^n + c1·λ^(n-1) + ... + cn (Faddeev-LeVerrier)
; matrix-trace: Calculate the trace of a matrix (sum of diagonal elements)
; max-idx: Return max value and its index in a list
; mean: Calculate the mean of a list of numbers, (x1 + x2 +...+ xn)/n
; mean-geometric: Calculate the geometric mean of a list of numbers, nth-root(x1*x2*...*xn)
; mean-harmonic: Calculate the harmonic mean of a list of numbers, n/(1/x1 + 1/x2 +...+ 1/n)
; median: Calculate the median of a list of numbers
; memoize: Memoize a function
; merge-matrix: Merge two matrix
; merge-string: Superposition of one string on another string
; min-max-idx: Return min and max values with their index in a list
; min-idx: Return min value and its index in a list
; minor-matrix: Remove a row and a column from a matrix
; mode: Calculate the mode of a list of numbers
; msetq: Assign the return values (list) of function to symbols
; mul-poly: Moltplication between two polynomials
; multi-line: Read multi-line user-input
; nand: NAND operator
; natural-sort: Sorts the strings of a list in natural order
; negative?: Check if a number is lesser than 0
; nesting: Return an association list (element nested-level)
; next-pow2: Find the first power of 2 greater than or equal to a number
; noecho: Evaluate expr without echo on REPL (standard output)
; nor: NOR operator
; norm: Calculate the norm of a vector of arbitrary length (distance from origin)
; normalize: Normalize a list of numbers in the range (a,b)
; num-cf: Calculate the first n terms of the continued fraction of a number
; number-stamp: Calculate the stamp of a number
; number-string: Find the relative string (1=A,...,26=Z,...,702=ZZ,...)
; one?: Check if a number is equal to 1 (one)
; one-in: Convert probability (0..1) to '1 in x events'
; order-type: Check the sort order of a list
; orthogonal?: Check if two segments s1(p1 p2) and s2(p3 p4) are orthogonal
; pad-matrix: Insert and fills numpad rows and columns around a matrix m x n with a number or char or string
; pad-string: Pad a string to a predefinite length with a predefinite char
; pairs-ij: Generate all pairs of elements of a list with (index i < index j)
; pair-func: Produces a list applying a function to each pair of elements of a list
; palindrome?: Check if a list or a string or a number is palindrome
; papersize: Calculate dimensions of standard paper (mm)
; parallel?: Check if two segments s1(p1 p2) and s2(p3 p4) are parallel
; partition: Generate all the partitions of a list
; partition-num: Generate a list of all the partitions of a positive integer
; partition-numbers: Calculate a list of all numbers of partitions from 0 to a positive integer
; perfect?: Check if an integer number is a perfect number (num = sum(proper-divisors))
; period: Convert a millisec number in hours, minutes, seconds, millisecs
; perm: Generate all permutations without repeating from a list of items
; perm-alternate: Generates all permutations in which the elements of two lists alternate
; perm-circ: Generate all circular permutations without repetition from a list of items
; perm-rep: Generate all permutations of k elements with repetition from a list of items
; pers-add: Calculate the additive persistence of an integer
; pers-mul: Calculate the multiplicative persistence of an integer
; plot-xy: Plot a list of points on terminal
; polar-cart: Convert polar coordinate to cartesian coordinate
; poly-fit: Calculate the coefficients of polynomial regression of a list of points
; polygonal-number: Calculate the nth polygonal number with s sides
; pop-count0: Calculate the number of 0 in binary value of an integer number
; pop-count1: Calculate the number of 1 in binary value of an integer number
; positive?: Check if a number is greater than 0
; pow-i: Calculate the integer power of an integer
; power-of?: Check if number y is a power of number x
; power-of-2?: Check if an integer is a power of 2
; power?: Check (and find) if a number is a power of another number
; powerset: Generate all sublists of a list
; powerset-i: Generate all sublists of a list (binary mask)
; powmod: Calculate (base^exponent % modulo)
; prev-pow2: Find the first power of 2 less than or equal to a number
; prime-pairs: Generate pairs of twin primes in the interval [n1..n2]
; prime?: Check if a number is prime
; primes: Generate a given number of prime numbers (starting from 2)
; primes-range: Generate all prime numbers in the interval [n1..n2]
; primes-to: Generate all prime numbers less than or equal to a given number
; primes-to-count: Calculate the number of primes less than or equal to a given number
; print-grid: Print a matrix with only digits (0..9)
; print-matrix: Print a matrix m x n
; print-matrix-chars: Print a matrix m x n of chars
; print-matrix-int: Print a matrix of integer
; print-table: Print a matrix (list) m x n as a table
; println-unix: Print the args with \n (unix style)
; println-windows: Print the args with \r\n (windows style)
; proportion: Calcolate the missing value (0) of proportion a/b=c/d
; psetq: Assign the value of symbols in parallel
; quadratic: Find the solutions of the quadratic equation: A*x^2 + B*x + C = 0
; quantile: Calculate the p quantile of a list of numbers
; rad-deg: Convert radiants to decimal degrees
; radical: Calculate the radical of a positive integer number (product of unique prime factors of num)
; rand-ascii: Generate a random string of a given length in a range of characters
; rand-circle1: Generate points (x y) within a circle (center (0,0) - radius = 1) (linear method)
; rand-circle2: Generate points (x y) within a circle (center (0,0) - radius = 1) (polar method)
; rand-list: Generate a list with random elements
; rand-range: Generate a random integer in a closed range
; rand-range-f: Generate a random float in a closed range
; rand-pick: Pick an index from a list of relative probabilities
; random-binary-matrix: Generate a random binary matrix (rows x cols) (optional: with k cells at 1)
; regex-all: Find all occurrences of a regex in a string
; remove: Remove an element from a list (first or all occurrence)
; remove-common: Remove common elements of two lists (remove 1:1)
; remove-commons: Remove common elements of n lists (remove 1:1)
; remove-at: Remove elements from a list with a list of indexes
; remove-items: Remove from lst the elements in items (remove 1:1)
; remove-k: Remove elements from a list every k
; replace-all: Multiple replace on list and string
; reverse-digits: Reverse the digits of an integer
; reverse-digits-big: Reverse the digits of an integer or big-integer
; reverse-part: Reverse part of list or string
; rgb-hsv: Convert a color from rgb to hsv
; riffle: Create a list that alternates the elements of lists and atoms
; right-string: Justify a string to the right
; rle-decode: Decode list with Run Length Encoding
; rle-encode: Encode list with Run Length Encoding
; rms: Calculate the root-mean-square of a list of numbers, sqrt((x1^2 + x2^2 +...+ xn^2)/n)
; roman-int: Convert an integer to a roman number
; rotate-index: Rotate index in a circular list
; same-digit? Check if an integer has all digits equal
; same-digits? Check if two numbers have the same digits
; same-sign?: Check if two numbers have same sign
; sample-list: Generate a sample of items from a list
; sample-list-unique: Generate a sample of unique items from a list
; select-even: Select the elements of a list that have even index
; select-freq: Select elements from a list with specified frequency
; select-k: Select elements from a list every k
; select-odd: Select the elements of a list that have odd index
; select-once: Select the elements of a list that appear only once
; select-multi: Select the elements of a list that appear more than once
; sequence-alpha: Generate an alphanumeric sequence
; set-bit: Set the bit at the ith position of an integer
; shifted?: Check if two lists are rotated with each other
; sigmoid: Calculate the value of sigmoid (logistic) function at x
; sign: Return the sign of a number
; sislin-c: Solve a linear system with Cramer's method (determinant)
; sislin-g: Solve a linear system with Gauss's method (elimination with pivot and backwards substitution)
; slice-all: Generate all the slice of a list or a string
; slice-range: Extract a sublist or a substring from a list or a string
; snoob: Find the next number with the same number of 1-bit
; solve-maze: Search a solution path in a maze
; sort-colums: Sort the colums of a matrix
; sort-rows: Sort the rows of a matrix
; sorensen-list: Calculate the Sorensen-Dice coefficient for two lists (similarity)
; sorensen-string: Calculate the Sorensen-Dice coefficient for two strings (similarity)
; sort-with: Sort a list with the order of another list
; soundex: Phonetic algorithm for indexing names by sound
; spigot-e: Calculate digits of 'e' with spigot method
; spigot-pi: Calculate digits of 'pi' with spigot method
; split-integer: Generate all the splits of an integer in order
; split-list: Generate all the splits of a list in order
; split-string: Generate all the splits of a string in order
; sqrt-i: Calculate the integer square root of a positive integer
; square?: Check if an integer is a perfect square
; stdev: Calculate the standard deviation of a list of numbers (population: N)
; stdev2: Calculate the standard deviation of a list of numbers (sample: N-1)
; str-chars: Convert a string to list of chars
; str-lst: Convert a string into list of symbols
; string-int Convert a numeric string to big-integer
; string-number: Find the relative number from a string (A=1,...,Z=26,...,ZZ=702,...)
; sub-poly: Subtraction between two polynomials
; sublist?: Check if all elements of a list (lst1) are in another list (lst2)
; sublists-sum-to: Generate all sublists that sum to a given number
; submatrix? Check if a matrix is a submatrix
; substitute: Multiple substitution on a list
; sum-diff: Calculate the alternate sum/diff of integers of a list
; sum-digit-pairs: Generate the sums of the mirror digit pairs of a number
; sum-free?: Check if a list is sum-free (no pair of numbers (not necessarily distinct) sums to a number in the list)
; sum-num-from-list: Check if a number can be a sum of some other numbers
; swap-cols: Swap the cols of a matrix (all if col1 and col2 are nil)
; swap-rows: Swap the rows of a matrix (all if row1 and row2 are nil)
; system-info: Report some informations on system
; take-common: Take common elements of two lists (take 1:1)
; take-commons: Take common elements of n lists (take 1:1)
; time-add: Addiction of two or more time values (hh mm ss)
; time-list: Generate a list of times (hh mm ss) from t1 to t2
; time-sec: Convert a time (hours minutes seconds) in seconds
; time<: Check if a time (t1) is lesser of another time (t2)
; time<=: Check if a time (t1) is equal or lesser of another time (t2)
; time=: Check if two times are equal
; time>: Check if a time (t1) is greater of another time (t2)
; time>=: Check if a time (t1) is equal or greater of another time (t2)
; time-sub: Subtraction of two or more time values (hh mm ss)
; toggle-bit: Toggle the bit at the ith position of an integer
; toggle-bits: description Toggle all the bits of num (complement)
; totient: Calculate the eulero totient of a given number
; totient-big: Calculate the eulero totient of a given big-integer number
; totients-to: Calculate totients for all numbers less than or equal to a given number
; trim-leading: Removes all initial occurrences of an element in a list
; trim-trailing: Removes all final occurrences of an element in a list
; twins: Generate twins primes less than or equal to a given number
; type-of: Get the type of a symbol
; unpad-matrix: Remove numpad rows and columns around a matrix m x n
; upper?: Check if a char is uppercase (A..Z)
; user-symbols1: Create a list of user symbols
; user-symbols2: Create a list of user functions and user symbols
; verify-date: Check if a date is valid
; xlate: Convert infix-prefix-postfix expression to prefix expression
; xnor: XNOR operator
; xor: XOR operator
; yo-list: Print the list of all functions with docstring
; zip: Transpose multiple lists into one
;===========================================================================

;===========================================================================
;===========================================================================
;; <p><b><center>CONSTANTS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (constant (global '_YO) true)
;; @description Used to checks if library is loaded
(constant (global '_YO) true)

;; @syntax (constant 'STDIN_FILENO 0)
;; @description Standard input value, stdin. Its value is 0.
(constant 'STDIN_FILENO 0)

;; @syntax (constant 'STDOUT_FILENO 1)
;; @description Standard output value, stdout. Its value is 1.
(constant 'STDOUT_FILENO 1)

;; @syntax (constant 'STDERR_FILENO 2)
;; @description Standard error value, stderr. Its value is 2.
(constant 'STDERR_FILENO 2)

;; @syntax (constant (global 'MAX-INT) 9223372036854775807)
;; @description Maximum value of int64
(constant (global 'MAX-INT) 9223372036854775807)

;; @syntax (constant (global 'MIN-INT) -9223372036854775808)
;; @description Minimum value of int64
(constant (global 'MIN-INT) -9223372036854775808)

;; @syntax (constant (global 'E) 2.7182818284590451)
;; @description Euler number
(constant (global 'E) 2.7182818284590451)

;; @syntax (constant (global 'PI) 3.1415926535897931)
;; @description PI Greek
(constant (global 'PI) 3.1415926535897931)

;; @syntax (constant (global 'TAU) 6.2831853071795862)
;; @description Tau (2*PI)
(constant (global 'TAU) 6.2831853071795862)

;; @syntax (constant (global 'PHI) 1.6180339887498949)
;; @description Golden ratio
(constant (global 'PHI) 1.6180339887498949)

;; @syntax (constant (global 'UPPER) "ABCDEFGHIJKLMNOPQRSTUVWXYZ")
;; @description Uppercase
(constant (global 'UPPER) "ABCDEFGHIJKLMNOPQRSTUVWXYZ")

;; @syntax (constant (global 'LOWER) "abcdefghijklmnopqrstuvwxyz")
;; @description Lowercase
(constant (global 'LOWER) "abcdefghijklmnopqrstuvwxyz")

;; @syntax (constant (global 'DIGITS) "0123456789")
;; @description Digits
(constant (global 'DIGITS) "0123456789")

;; @syntax (constant (global 'MARKS) "`!\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~ ")
;; @description Punctuation marks
(constant (global 'MARKS) "`!\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~ ")

;; @syntax (constant (global 'get-workdir) real-path)
;; @description Return the working directory
(constant (global 'get-workdir) real-path)

;; @syntax (constant (global 'set-workdir) change-dir)
;; @description Change working directory
(constant (global 'set-workdir) change-dir)

;; @syntax (constant (global 'C) 299792458)
;; @description Speed of light (m/sec) (Conferenza Generale dei Pesi e delle Misure (CGPM) 1983)
;  Il metro è stato ridefinito come:
;  "La distanza percorsa dalla luce nel vuoto in 1/299792458 di secondo."
(constant (global 'C) 299792458)

;; @syntax (constant (global 'G) 6.67430e-11)
;; @description Gravitational constant (newton x m^2/kg^2) (CODATA 2018)
(constant (global 'G) 6.67430e-11)


;###########################################################################
; Define a new context
;(context 'yo)
;###########################################################################

;===========================================================================
;===========================================================================
;; <p><b><center>MAIN</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (system-info)
;; @description Report some informations on system
;; @param <> none
;; @return list
;; @example
;; (system-info)  ==>
;; Number of Lisp cells: 733
;; Maximum number of Lisp cells constant: 576460752303423488
;; Number of symbols: 407
;; Evaluation/recursion level: 4
;; Environment stack level: 1
;; Maximum call stack constant: 2048
;; Pid of the parent process or 0: 0
;; Pid of running newLISP process: 3216
;; Version number as an integer constant: 10705
;; Operating System: windows
;; ffilib: yes
;; IPV6: no
;; 64 bit: yes
;; UTF-8: yes
;; library: no
;; (959 576460752303423488 425 2 0 2048 0 6884 10705 1414)
(define (system-info)
"Report some informations on system"
  (local (info num num$ so)
    (setq info (sys-info))
    (println "Number of Lisp cells: " (info 0))
    (println "Maximum number of Lisp cells constant: " (info 1))
    (println "Number of symbols: " (info 2))
    (println "Evaluation/recursion level: " (info 3))
    (println "Environment stack level: " (info 4))
    (println "Maximum call stack constant: " (info 5))
    (println "Pid of the parent process or 0: " (info -4))
    (println "Pid of running newLISP process: " (info -3))
    (println "Version number as an integer constant: " (info -2))
    (setq num (sys-info -1))
    (setq num$ (bits num))
    (setq so (int (slice num$ (- (length num$) 4)) 0 2))
    (print "Operating System: ")
    (case so
        (1  (println "linux"))
        (2  (println "bsd"))
        (3  (println "osx"))
        (4  (println "solaris"))
        (5  (println "nil"))
        (6  (println "windows"))
        (7  (println "os/2"))
        (8  (println "cygwin"))
        (9  (println "tru64 unix"))
        (10 (println "aix"))
        (11 (println "android"))
        (true (println so))
    );case
    ; ffilib -> bit 11
    (print "ffilib: ")
    (if (zero? (& (>> num 10) 1)) (println "no") (println "yes"))
    ; IPV6 -> bit 10
    (print "IPV6: ")
    (if (zero? (& (>> num 9) 1)) (println "no") (println "yes"))
    ; 64 bit -> bit 9
    (print "64 bit: ")
    (if (zero? (& (>> num 8) 1)) (println "no") (println "yes"))
    ; utf8 -> bit 8
    (print "UTF-8: ")
    (if (zero? (& (>> num 7) 1)) (println "no") (println "yes"))
    ; library -> bit 7
    (print "library: ")
    (if (zero? (& (>> num 6) 1)) (println "no") (println "yes"))
    info))

;  Insert the following expression in init.lsp
;  (constant (global 'SIMBOLI) (map string (symbols)))
;; @syntax (user-symbols1)
;; @description Create a list of user symbols
;; @return List of user symbols
;; @example
;; ; from a new REPL
;; (user-symbols1)  ==> ("user-symbols1")
(define (user-symbols1)
"Create a list of user symbols"
  (difference (map string (symbols)) SIMBOLI))

;; @syntax (user-symbols2 _ctx)
;; @description Create a list of user functions and user symbols
;; @param <_ctx> context name
;; @return list ((functions) (symbols))
;; @example
;; (user-symbols2 MAIN)  ==> ((module) ())
(define (user-symbols2 _ctx)
"Create a list of user functions and user symbols"
  (local (_func _other)
    (if (= _ctx nil) (setq _ctx (context)))
    (setq _func '())
    (setq _other '())
    (dolist (_el (symbols _ctx))
      (if (and (lambda? (eval _el))
               (not (= _el 'user-symbols2)))
          (push _el _func -1))
      (if (and (not (lambda? (eval _el)))
               (not (primitive? (eval _el)))
               (not (protected? _el))
               (not (global? _el))
               (not (= _el '_func))
               (not (= _el '_other))
               (not (= _el '_el))
               (not (= _el '_ctx)))
          (push _el _other -1)))
    (list _func _other)))

;; @syntax (free-vars _ctx)
;; @description Print a list of free symbols/variables
;; @param <ctx> context name
;; @return nil
;; @example
;; (define (test a b) (setq c (+ a b)))
;; (test 5 10)  ==> 15
;; (free-vars)  ==> c 15
(define (free-vars _ctx)
"Print a list of free symbols/variables"
  (local (_vars _lst-ctx)
    (if (= _ctx nil) (setq _ctx (context)))
    (setq _vars '())
    (setq _lst-ctx '())
    (dolist (_el (symbols _ctx))
      (if (and (context? (eval _el))
               (not (= _el '_ctx))
               (not (= _el 'MAIN))
               (not (= _el 'Tree))
               (not (= _el 'Class)))
          (push (eval _el) _lst-ctx -1))
      (if (and (not (lambda? (eval _el)))
               (not (macro? (eval _el)))
               (not (primitive? (eval _el)))
               (not (protected? _el))
               (not (global? _el))
               (not (= _el '_ctx))
               (not (= _el '_lst-ctx))
               (not (= _el '_vars))
               (not (= _el '_el))
               (not (= _el '_v)))
          (push _el _vars -1)))
    (dolist (_v _vars)
      (if (eval _v)
        (println _v { } (eval _v))))
    (dolist (_v _lst-ctx)
      (if (eval _v)
        (println (eval _v) { } (eval-string (string "(" _v ")")))))
    nil))

;; @syntax (gensym)
;; @description Generate a unique symbol
;; @param <> none
;; @return symbol (unique)
;; @example
;; (gensym)  ==> g-7E31347F-6EEB-477E-BFF0-4868BE374F6B
;; (gensym)  ==> g-4DE95DAB-4A11-431F-9EBE-D267E9646C4C
;; (gensym)  ==> g-5ECA1A6B-6E8B-4ADB-9189-D352CE488876
(define (gensym)
"Generate a unique symbol"
  (sym (string "g-" (uuid))))

;; @syntax (type-of x)
;; @description Get the type of a symbol
;; @param <x> symbol
;; @return type of symbol (string)
;; @example
;; (type-of dump)      ==> "primitive"
;; (type-of type-of)   ==> "lambda"
;; (type-of '(1 2 3))  ==> "list"
;; (type-of MAIN)      ==> "context"
;; (type-of abc)       ==> "nil"
(define (type-of x)
"Get the type of a symbol"
  (let (table '("nil" "true" "int" "float" "string" "symbol" "context"
                "primitive" "import" "ffi" "quote" "list" "lambda"
                "fexpr" "array" "dyn_symbol"))
    (table (& 0xf ((dump x) 1)))))

;; @syntax (doc func)
;; @description Return the docstring, if present, of a function
;; @param <func> function or macro
;; @return docstring of function or nil
;; @example
;; (doc doc)  ==> "Return the docstring, if present, of a function"
(define (doc f)
"Return the docstring, if present, of a function"
  (if (and (or (lambda? f) (macro? f)) (string? (nth 1 f)))
      (nth 1 f)
      nil))

;; @syntax (yo-list)
;; @description Print the list of all functions with docstring
;; @param <none>
;; @return print list of functions with docstring
;; @example
;; (yo-list)  ==>
(define (yo-list)
"Print the list of all functions with docstring"
  (let (counter 0)
    (dolist (f (symbols))
      (if (and (or (lambda? (eval f)) (macro? (eval f))) (string? (nth 1 (eval f))))
          (begin
            (++ counter)
            (println f ": " (nth 1 (eval f))))))
    (println "and car and cdr to four levels (c????r)")) '>)

;; @syntax (psetq lst-var lst-expr)
;; @description Assign the value of symbols in parallel
;; @param <lst-var> list of symbols/variables
;; @param <lst-expr> list of assignment expressions
;; @return last assignment
;; @example
;; (setq x 2 y 3)
;; (psetq (x y) ((+ 1 y) (+ 1 x)))
;; (list x y)    ==> (4 3)
;; (setq x 1 y 2 z 3)
;; (psetq (x y z) ((+ x y z) (- z y x) (- x y z)))
;; (list x y z)  ==> (6 0 -4)
(define-macro (psetq)
"Assign the value of symbols in parallel"
  (let ((_var '()) (_ex '()))
    ; per ogni espressione in (args 1)...
    (for (i 0 (- (length (args 1)) 1))
      ; espande l'espressione i-esima con il valore
      ; di ogni variabile (args 0)
      (setq _ex (expand (args 1 i) (args 0 0)))
      ; ciclo che espande l'espressione i-esima per ogni variabile
      (for (j 1 (- (length (args 0)) 1))
        (setq _ex (expand _ex (args 0 j))))
      ; aggiunge l'espressione espansa ad una lista
      (push _ex _var -1))
    ; assegna ad ogni variabile la valutazione
    ; della relativa espressione della lista creata
    (dolist (el _var)
      (set (args 0 $idx) (eval el)))))

;; @syntax (msetq lst-var func)
;; @description Assign the return values (list) of function to symbols
;; @param <lst-var> list of symbols/variables
;; @param <func> function to evaluate
;; @return last assignment
;; @example
;; (define (test a b) (list a (sin b) 'add))
;; (msetq (x y z) (test 3 4 'add))
;; (list x y z)
;; (3 -0.7568024953079282 add@40D926)
(define-macro (msetq)
"Assign the return values (list) of function to symbols"
    ; Assegna ad ogni variabile di (args 0)
    ; la relativa variabile ottenuta dalla
    ; valutazione della funzione in (args 1)
    ; (cioè dei valori della lista ritornata dalla funzione)
    (dolist (_el (eval (args 1)))
      (set (args 0 $idx) (eval _el))))

;; @syntax (break sym-lst cond-str)
;; @description Debugging aid: break execution of function with condition and print symbols/value
;; @param <sym-lst> list of symbols/variables
;; @param <cond-str> condition to evaluate
;; @return nil
;; @example
;; (break '(out) "(or (> c 20) (> d 100))")
;; (break '(out) "(> (length out) 5)")
;; (break '(c d out) "true")
; global variable used to allow/deny the execution of "break" function
(global '_BREAK)
; allow "break" function
(setq _BREAK true)
(define (break sym-lst cond-str)
"Debugging aid: break execution of function with condition and print symbols/value"
        ; se (_BREAK = true) e
        ; se la condizione "cond-str" viene valutata true
  (cond ((and _BREAK (eval-string cond-str))
          ; allora stampiamo tutti i simboli con i relativi valori
          ; contenuti nella lista sym-lst
          (dolist (el sym-lst)
            (print el " = " (eval el) "; "))
          (println "")
          ; Aspetta un comando/espressione:
          ; 1) 'Invio' continua l'esecuzione della funzione chiamante
          ; 2) espressione da valutare
          ; 3) (setq _BREAK nil)
          ; 4) Ctrl+C
          (read-line)
          (while (> (length (current-line)) 0)
            (println (eval-string (current-line)))
            (read-line)))))

;; @syntax (multi-line endchar)
;; @description Read multi-line user-input
;; @param <eofchar> char to end the input
;; @return String with multi-line text
;; @example
;; (multi-line "~")
;; pippo pluto
;; topolino minnie
;; qui quo qua
;; ~
;; ==> "pippo pluto\r\ntopolino minnie\r\nqui quo qua\r\n"
(define (multi-line endchar)
"Read multi-line user-input"
(catch
  (let (out "" ch "")
    (while (setf ch (read-char))
      (if (!= (char ch) endchar)
        (setf out (append out (char ch)))
        (throw out)))
    out)))

;; @syntax (def-static name body)
;; @description Function to create other statically scoped functions
;  Define a function or macro to create other functions enclosed in their own namespace.
;  This function works by creating a context and default functor from the name of the function.
;  def-static should only be used while in MAIN context.
;; @param <name> function name
;; @param <body> function body
;; @return function
;; @example
;; (def-static 'acc (lambda (x)
;;     (if sum (inc sum x)
;;             (set 'sum x))))
;; (acc 5)  ==> 5
;; (acc 5)  ==> 10
;; (acc 2)  ==> 12
;; acc:sum  ==> 12
;; acc:x    ==> nil
(define (def-static name body)
"Function to create other statically scoped functions"
    (def-new 'body (sym name name)))

;; @syntax (hayashi func exp [exp])
;; @description Function symmetric to curry
; Transforms func from a function f(x, y) that takes two arguments into a function fy(x) that takes a single argument
;; @param <func> function name
;; @param <exp> expression
;; @return function
;; @example
;; (set 'f (curry + 10))    ->  (lambda ($x) (+ 10 $x))
;; (set 'g (hayashi + 10))  ->  (lambda (_x) (+ _x 10))
;; (map (curry div 2) '(4 8 10))    ==> (0.5 0.25 0.2)
;; (map (hayashi div 2) '(4 8 10))  ==> (2 4 5)
(define-macro (hayashi)
"Function symmetric to curry"
  (letex (_func (push '_x (args) 1))
    (fn (_x) _func )))

;; @syntax (curry-s func exp [exp])
;; @description Extend curry with multiple parameters
; Transforms func from a function f(x, y, ... ,z ) that takes n arguments into a function fx(y...z) that takes a single argument
;; @param <func> function name
;; @param <exp> expression
;; @return function
;; @example
;; (set 'f (curry + 10 20))     ->  (lambda ($x) (+ 10 $x))
;; (set 'g (curry-s + 10 20))   ->  (lambda (_x) (+ 10 20 x))
;; (map (curry div 2) '(4 8 10))    ==> (0.5 0.25 0.2)
;; (map (curry-s div 2 2) '(4 8 10))  ==> (0.25 0.125 0.1)
;; (map (curry-s div 2 2 2) '(4 8 10))  ==> (0.125 0.0625 0.05)
(define-macro (curry-s)
"Extend curry with multiple parameters"
   (letex (_func (push '_x (args) -1))
    (fn (_x) _func )))

;; @syntax (memoize mem-func func)
;; @description Memoize a function
;; @param <mem-func> name of new funtion
;; @param <func> function to memoize
;; @return function
;; @example
;; (memoize A004149
;;   (lambda (num)
;;     (cond ((or (= num -1) (= num 0) (= num 1) (= num 2)) 1L)
;;           (true
;;             (let (sum 0L)
;;               (for (k 2 (- num 1)) (++ sum (* (A004149 k) (A004149 (- num 2 k)))))
;;               sum)))))
;; (map A004149 (sequence 1 20)) (1L 1L 1L 2L 4L 8L 16L 33L 69L 146L 312L 673L 1463L 3202L 7050L 15605L 34705L 77511L 173779L 390966L)
(define-macro (memoize mem-func func)
"Memoize a function"
  (set (sym mem-func mem-func)
    (letex (f func c mem-func)
      (lambda ()
        (or (context c (string (args)))
        (context c (string (args)) (apply f (args))))))))

;===========================================================================
;===========================================================================
;; <p><b><center>HASH-MAP</center></b></p>
;===========================================================================
;===========================================================================
; HASH-CREATE: Creazione di una hash-map
; HASH-SET: Inserimento di una coppia (chiave-valore)
; HASH-GET-VAL: Lettura di un valore tramite chiave
; HASH-GET-KEY: Lettura di una chiave tramite valore
; HASH-KEYS: Lista di tutte le chiavi
; HASH-VALUES: Lista di tutti i valori
; HASH-ITEMS: Lista associativa di tutti gli elementi (coppie chiave-valore)
; HASH-DEL: Eliminazione di un valore tramite chiave
; HASH-SIZE: Numero di elementi (coppie chiave-valore)
; HASH-KEY?: Chiave esistente?
; HASH-VALUE?: Valore esistente?
; HASH-EMPTY?: Hash-Map vuota?
; HASH-CLEAR: Eliminazione di tutti gli elementi (coppie chiave-valore)
; HASH-DESTROY: Eliminazione di una hash-map
; HASH-SET-ALIST: Inserimento degli elementi (coppie chiave-valore) di una lista associativa
; HASH-SET-LIST: Insert a list in a hash-map (autocreate key)
; HASH?: Hash-map esistente?
; HASH-MAP-LAMBDA: Applica una funzione (kv-fn) agli elementi (coppie chiave-valore)

;; @syntax (hash-create x)
;; @description Create a hash-map
;; @param <x> symbol or string
;; @return hash-map name
;; @example
;; (hash-create 'hh)  ==> hh
;; (hash-create "aa")  ==> aa
(define (hash-create x)
"Create a hash-map"
  (new Tree (sym x)))

;; @syntax (hash-set hash key value)
;; @description Insert an item (key value) in a hash-map
;; @param <hash> hash name
;; @param <key> key
;; @param <value> value
;; @return value
;; @example
;; (hash-set hh 1 "a")  ==> "a"
;; (hash-set hh 2 "b")  ==> "b"
;; (hash-set hh 3 "c")  ==> "c"
;; (hash-set hh 4 "d")  ==> "d"
(define (hash-set hash key value)
"Insert an item (key value) in a hash-map"
  (hash key value))

;; @syntax (hash-get-val hash key)
;; @description Get the value with a predefinite key from a hash-map
;; @param <hash> hash name
;; @param <key> key
;; @return value
;; @example
;; (hash-get-val hh "1")  ==> "a"
;; (hash-get-val hh 1)    ==> "a"
;; (hash-get-val hh 5)    ==> nil
(define (hash-get-val hash key)
"Get the value with a predefinite key from a hash-map"
  (hash key))

;; @syntax (hash-get-key hash value)
;; @description Get the key with a predefinite value from a hash-map
;; @param <hash> hash name
;; @param <value> value
;; @return key
;; @example
;; (hash-get-key hh "c")  ==> "3"
;; (hash-get-key hh "z")  ==> nil
(define (hash-get-key hash value)
"Get the key with a predefinite value from a hash-map"
  (local (key break)
    (dolist (item (hash) break)
      (if (= (last item) value)
          (set 'key (first item) 'break true)))
    key))

;; @syntax (hash-keys hash)
;; @description Generate the list of all the keys of a hash-map
;; @param <hash> hash name
;; @return list with all the keys
;; @example
;; (hash-keys hh)  ==> ("1" "2" "3" "4")
(define (hash-keys hash)
"Generate the list of all the keys of a hash-map"
  (map first (hash)))

;; @syntax (hash-values hash)
;; @description Generate the list of all the values of a hash-map
;; @param <hash> hash name
;; @return list with all the values
;; @example
;; (hash-values hh)  ==> ("a" "b" "c" "d")
(define (hash-values hash)
"Generate the list of all the values of a hash-map"
  (map last (hash)))

;; @syntax (hash-items hash)
;; @description Generate the list of all the items (key value) of a hash-map
;; @param <hash> hash name
;; @return list with all the items (key value)
;; @example
;; (hash-items hh)  ==> (("1" "a") ("2" "b") ("3" "c") ("4" "d"))
(define (hash-items hash)
"Generate the list of all the items (key value) of a hash-map"
  (hash))

;; @syntax (hash-del hash key)
;; @description Delete an item with a predefinite key from a hash-map
;; @param <hash> hash name
;; @param <key> key
;; @return nil
;; @example
;; (hash-del hh "1")  ==> nil
;; (hash-del hh 2)    ==> nil
;; (hash-del hh 5)    ==> nil
;; (hash-items hh)    ==> (("3" "c") ("4" "d"))
(define (hash-del hash key)
"Delete an item with a predefinite key from a hash-map"
  (hash key nil))

;; @syntax (hash-size hash)
;; @description Length of a hash-map
;; @param <hash> hash name
;; @return Length of hash-map
;; @example
;; (hash-size hh)  ==> 2
(define (hash-size hash)
"Length of a hash-map"
  (length (hash)))

;; @syntax (hash-key? hash key)
;; @description Check the existence of a predefinite key in a hash-map
;; @param <hash> hash name
;; @param <key> key
;; @return true or nil
;; @example
;; (hash-key? hh 1)    ==> nil
;; (hash-key? hh 3)    ==> true
;; (hash-key? hh "4")  ==> true
(define (hash-key? hash key)
"Check the existence of a predefinite key in a hash-map"
  (if (hash (string key)) true nil))

;; @syntax (hash-value? hash value)
;; @description Check the existence of a predefinite value in a hash-map
;; @param <hash> hash name
;; @param <value> value
;; @return true or nil
;; @example
;; (hash-value? hh 3)    ==> nil
;; (hash-value? hh "c")  ==> true
(define (hash-value? hash value)
"Check the existence of a predefinite value in a hash-map"
  (let (out nil)
    (dolist (item (hash) out)
      (if (= (last item) value)
          (setq out true)))
    out))

;; @syntax (hash-empty? hash)
;; @description Check if a hash-map is empty
;; @param <hash> hash name
;; @return true or nil
;; @example
;; (hash-empty? hh)  ==> nil
(define (hash-empty? hash)
"Check if a hash-map is empty"
  (empty? (hash)))

;; @syntax (hash-clear hash)
;; @description Delete all the items of a hash-map
;; @param <hash> hash name
;; @return true or nil
;; @example
;; (hash-create 'aa)    ==> aa
;; (hash-set aa 1 "x")  ==> "x"
;; (hash-set aa 2 "y")  ==> "y"
;; (hash-set aa 3 "z")  ==> "z"
;; (aa)                 ==> (("1" "x") ("2" "y") ("3" "z"))
;; (hash-clear aa)      ==> nil
;; (aa)                 ==> ()
(define (hash-clear hash)
"Delete all the items of a hash-map"
  (map delete (symbols hash))
  nil)

;; @syntax (hash-destroy hash)
;; @description Destroy a hash-map
;; @param <hash> hash name
;; @return true
;; @example
;; (aa)                 ==> ()
;; (hash-set aa 1 "x")  ==> "x"
;; (hash-set aa 2 "y")  ==> "y"
;; (aa)                 ==> (("1" "x") ("2" "y"))
;; (hash-destroy 'aa)   ==> true
;; (aa)                 ==> ERR: invalid function : (aa)
(define (hash-destroy hash)
"Destroy a hash-map"
  (delete hash) (delete hash))

;; @syntax (hash-set-alist hash lst)
;; @description Insert an associative list in a hash-map
;; @param <hash> hash name
;; @param <lst> associative list
;; @return true
;; @example
;; (hh)                               ==> (("3" "c") ("4" "d"))
;; (setq lista '((1 "A") ("2" "B")))  ==> ((1 "A") ("2" "B"))
;; (hash-set-alist hh lista)          ==> hh
;; (hh)                               ==> (("1" "A") ("2" "B") ("3" "c") ("4" "d"))
(define (hash-set-alist hash lst)
"Insert an associative list in a hash-map"
  (hash lst))

;; @syntax (hash-set-list hash lst)
;; @description Insert a list in a hash-map (autocreate key)
;; @param <hash> hash name
;; @param <lst> list
;; @return true
;; @example
;; (hash-create 'bb)          ==> bb
;; (bb)                       ==> ()
;; (setq lista '("a" "A" "b" "B"))
;; (hash-set-list bb lista)   ==> bb
;; (bb)                       ==> (("1" "a") ("2" "A") ("3" "b") ("4" "B"))
;; (setq nuova '("g" "h"))
;; (hash-set-list bb nuova)   ==> bb
;; (bb)                       ==> (("1" "g") ("2" "h") ("3" "b") ("4" "B"))
(define (hash-set-list hash lst)
"Insert a list in a hash-map (autocreate key)"
  (hash (map list (sequence 1 (length lst)) lst)))

;; @syntax (hash? hash)
;; @description Check if a symbol is a hash-map
;; @param <hash> hash/symbol name
;; @return true or nil
;; @example
;; (hash? 'hh)  ==> true
;; (hash? hh)   ==> true
;; (hash? 'aa)  ==> nil
;; (hash? aa)   ==> nil
;; (hash? hh)   ==> true
(define (hash? hash)
"Check if a symbol is a hash-map"
  (and (context? (eval hash))
       (not (list? (eval (sym (term hash) hash nil))))))

;; @syntax (hash-map-lambda kv-fn hash)
;; @description Apply a function to all the items of a hash-map
;; @param <kv-fn> function
;; @param <hash> hash name
;; @return list
;; @example
;; (define (hm-keys hash)
;;   (hash-map-lambda (fn (key _) key) hash))
;; (hm-keys hh)    ==> ("1" "2" "3" "4")
;; (define (hm-values hash)
;;   (hash-map-lambda (fn (_ value) value) hash))
;; (hm-values hh)  ==> ("A" "B" "c" "d")
;; (define (hm-items hash)
;;   (hash-map-lambda (fn (key value) (list key value)) hash))
;; (hm-items hh)   ==> (("1" "A") ("2" "B") ("3" "c") ("4" "d"))
(define (hash-map-lambda kv-fn hash)
"Apply a function to all the items of a hash-map"
  (let (acc)
    (dotree (h hash true)
      (push (kv-fn (rest (term h)) (eval h)) acc -1))
    acc))

;===========================================================================
;===========================================================================
;; <p><b><center>BOOLEANS</center></b></p>
;===========================================================================
;===========================================================================
;
; AND, OR and NOT are primitive functions.
;
;; @syntax (nand x y)
;; @description Logical NAND operator
;; @param <x> boolean value (true or nil)
;; @param <y> boolean value (true or nil)
;; @return result of NAND operation
;; @example
;; (nand true nil)  ==> true
(define (nand x y)
"NAND operator"
  (not (and x y)))

;; @syntax (nor x y)
;; @description Logical NOR operator
;; @param <x> boolean value (true or nil)
;; @param <y> boolean value (true or nil)
;; @return result of NOR operation
;; @example
;; (nor true nil)  ==> nil
(define (nor x y)
"NOR operator"
  (not (or x y)))

;; @syntax (xor x b)
;; @description Logical XOR operator
;; @param <x> boolean value (true or nil)
;; @param <y> boolean value (true or nil)
;; @return result of XOR operation
;; @example
;; (xor true nil)  ==> true
(define (xor x y)
"XOR operator"
  (if (nand x y) (or x y) nil))

;; @syntax (xnor x b)
;; @description Logical XNOR operator
;; @param <x> boolean value (true or nil)
;; @param <y> boolean value (true or nil)
;; @return result of XNOR operation
;; @example
;; (xnor true nil)  ==> nil
(define (xnor x y)
"XNOR operator"
  (not (xor x y)))

;===========================================================================
;===========================================================================
;; <p><b><center>CONVERSIONS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (string-int str)
;; @description Convert a numeric string to big-integer
;; @param <str> string
;; @return big-integer
;; @example
;; (string-int "3652")  ==> 3652L
;; (string-int "1234L")  ==> 1234L
;; (string-int "34585725372834572357423")    ==> 34585725372834572357423L
;; (string-int "-34585725372834572357423L")  ==> -34585725372834572357423L
(define (string-int str)
"Convert a numeric string to big-integer"
  (let (num 0L)
    (if (= (str -1) "L") (pop str -1))
    (cond ((= (str 0) "-")
            (pop str)
            (dolist (el (explode str)) (setq num (+ (* num 10) (int el))))
            (* num -1))
          (true
            (dolist (el (explode str)) (setq num (+ (* num 10) (int el))))))))

;; @syntax (bigint-int num)
;; @description Convert a big-integer to int (if possible)
;; @param <num> big-integer
;; @return integer or big-integer
;; @example
;; (bigint-int 3652L)  ==> 3652
;; (bigint-int 34585725372834572357423475L)  ==> 34585725372834572357423475L
;; (bigint-int -34585725372834572357423475L)  ==> -34585725372834572357423475L
(define (bigint-int num)
"Convert a big-integer to int (if possible)"
  (let ( (MAX-INT 9223372036854775807) (MIN-INT -9223372036854775808) )
    (if (or (< num MIN-INT) (> num MAX-INT))
        num
        (+ 0 num))))

;; @syntax (int-list num)
;; @description Convert an integer to a list of digits
;; @param <num> integer
;; @return list (d1 d2 ... dn)
;; @example
;; (int-list 1623)  ==> (1 6 2 3)
;; (int-list 0375)  ==> (2 5 3)
(define (int-list num)
"Convert an integer to a list of digits"
  (if (zero? num) '(0)
  (let (out '())
    (while (!= num 0)
      (push (% num 10) out)
      (setq num (/ num 10))) out)))

;; @syntax (list-int lst)
;; @description Convert a list of digits to integer
;; @param <lst> list of digits (d1 d2 ... dn)
;; @return integer
;; @example
;; (list-int '(1 6 2 3)) ==> 1623
;; (list-int '(2 5 3))   ==> 253
;; (list-int '(0 2 1))   ==> 21
(define (list-int lst)
"Convert a list of digits to integer"
  (let (num 0)
    (dolist (el lst) (setq num (+ el (* num 10))))))

;; @syntax (str-chars str)
;; @description Convert a string to list of chars
;; @param <str> string
;; @return list of chars
;; @example
;; (str-chars "explode")  ==> ("e" "x" "p" "l" "o" "d" "e")
;; (str-chars "0123")     ==> ("0" "1" "2" "3")
(define (str-chars str)
"Convert a string to list of chars"
  (explode str))

;; @syntax (chars-str lst)
;; @description Convert a list of chars to string
;; @param <lst> list of chars
;; @return string
;; @example
;; (chars-str '("j" "o" "i" "n"))  ==> "join"
;; (chars-str '("0" "1" "2" "3"))  ==> "0123"
(define (chars-str lst)
"Convert a list of chars to string"
  (join lst))

;; @syntax (lst-str lst)
;; @description Convert a list of symbols to string
;; @param <lst> list of symbols
;; @param <merge> merge symbols on one string (true or nil)
;; @return string
;; @example
;; (lst-str '(a f 3 t h u))       ==> "a f 3 t h u"
;; (lst-str '(a f 3 t h u) true)  ==> "af3thu"
;; (lst-str '(af3thu))            ==> "af3thu"
;; (lst-str '(af3thu) true)       ==> "af3thu"
;; (lst-str '("a" "f" "3"))       ==> "a f 3"
;; (lst-str '("a" "f" "3") true)  ==> "af3"
(define (lst-str lst merge)
"Convert a list of symbols to string"
  (if merge
      (join (map string lst))
      (join (map string lst) " ")))

;; @syntax (str-lst str)
;; @description Convert a string into list of symbols
;; @param <str> string
;; @param <merge> merge string on one symbols (true or nil)
;; @return list of symbols
;; @example
;; (str-lst "af3thu")            ==> (a f 3 t h u)
;; (str-lst "af3thu" true)       ==> (af3thu)
;; (str-lst "a f 3 t h u")       ==> (a f 3 t h u)
;; (str-lst "a f 3 t h u" true)  ==> (a f 3 t h u)
(define (str-lst str merge)
"Convert a string into list of symbols"
  (if (or merge (find " " str))
      (map sym (parse str))
      (map sym (explode str))))

;; @syntax (list-array lst)
;; @description Convert a list to an array
;; @param <lst> list
;; @return array with the elements of list
;; @example
;; (setq lst '(1 2 3 4 5))
;; (setq vet (list-array lst)) ==> (1 2 3 4 5)
;; (list? lst)   ==> true
;; (array? vet)  ==> true
(define (list-array lst)
"Convert a list to an array"
  (array (length lst) lst))

;; @syntax (b1-b2 num base1 base2)
;; @description Convert an integer from base1 to base2 (2 <= base <= 10)
;; @param <num> integer number
;; @param <base1> initial base
;; @param <base2> final base
;; @return number (int)
;; @example
;; (b1-b2 -24569 10 4)                  ==> -11333321
;; (b1-b2 -11333321 4 10)               ==> -24569
;; (b1-b2 1133 10 2)                    ==> 10001101101
;; (b1-b2 10001101101 2 10)             ==> 1133
;; (b1-b2 9223372036854775807L 10L 2L)  ==> 111111111111111111111111111111111111111111111111111111111111111L
;; (b1-b2 (+ 1L MAX-INT) 10L 2L)        ==> 1000000000000000000000000000000000000000000000000000000000000000L
(define (b1-b2 num base1 base2)
"Convert an integer from base1 to base2 (2 <= base <= 10)"
  (if (zero? num) num
      (+ (% num base2) (* base1 (b1-b2 (/ num base2) base1 base2)))))

;; @syntax (bits-i num)
;; @description Convert a decimal integer (big integer) to binary string
;; @param <num> decimal integer (big integer)
;; @return bynary value (string)
;; @example
;; (bits-i 0)   ==> "0"
;; (bits-i 15)  ==> "1111"
;; (bits-i 12345678901234567890L)                 ==> "1010101101010100101010011000110011101011000111110000101011010010"
;; (bits-i (eval-string "12345678901234567890"))  ==> "1010101101010100101010011000110011101011000111110000101011010010"
(define (bits-i num)
"Convert a decimal integer (big integer) to binary string"
  (setq max-int (pow 2 62)) ; put this outside when doing a lot of calls
  (define (prep s) (string (dup "0" (- 62 (length s))) s))
  (if (<= num max-int) (bits (int num))
      (string (bits-i (/ num max-int))
              (prep (bits (int (% num max-int)))))))

;; @syntax (binary-bigint bin)
;; @description Convert a binary string to big integer
;; @param <bin> binary string
;; @return big-integer
;; @example
;; (binary-bigint "00")     ==> 0L
;; (binary-bigint "00101")  ==> 5L
;; (binary-bigint "111111111111111111111111111111111111111111111111111")  ==> 2251799813685247L
(define (binary-bigint bin)
"Convert a binary string to big integer"
  (let (num 0L)
    ; remove left padded 0
    (while (= (bin 0) "0") (pop bin))
    (if (= bin "") 0L
        ; else, build big integer number
        (dolist (el (explode bin))
          (setq num (+ (* num 2) (int el)))))))

;; @syntax (dec-bin num)
;; @description Convert a decimal integer to binary string
;; @param <num> decimal integer
;; @return bynary value (string)
;; @example
;; (dec-bin 0)   ==> "0"
;; (dec-bin 5)   ==> "101"
;; (dec-bin 15)  ==> "1111"
(define (dec-bin num)
"Convert a decimal integer to binary string"
  (bits num))

;; @syntax (bin-dec str)
;; @description Convert a bynary string to decimal integer
;; @param <str> binary string
;; @return decimal value (integer)
;; @example
;; (bin-dec "0")     ==> 0
;; (bin-dec "0101")  ==> 5
;; (bin-dec "1111")  ==> 15
(define (bin-dec str)
"Convert a bynary string to decimal integer"
  (int str 0 2))

;; @syntax (dec-hex num)
;; @description Convert a decimal integer to hexadecimal string
;; @param <num> decimal integer
;; @return hexadecimal value (string)
;; @example
;; (dec-hex 16)      ==> "10"
;; (dec-hex 0)       ==> "0"
;; (dec-hex 6)       ==> "6"
;; (dec-hex 255)     ==> "FF"
;; (dec-hex 100001)  ==> "186A1"
;; (dec-hex MAX-INT)  ==> "7FFFFFFFFFFFFFFF"
;; (dec-hex (+ 10L MAX-INT))  ==>"8000000000000009"
(define (dec-hex num)
"Convert a decimal integer to hexadecimal string"
  (if (zero? num) "0"
      (reverse (dec-hex-aux num))))
; routine di ausiliaria conversione
(define (dec-hex-aux num)
  (local (digit x y)
    (setq digit "0123456789ABCDEF")
    (setq x (% num 16))
    (setq y (/ num 16))
    (if (zero? y) (nth x digit)
        (append (nth x digit) (dec-hex-aux y)))))

;; @syntax (hex-dec str)
;; @description Convert a hexadecimal string to decimal integer
;; @param <str> hexadecimal string
;; @return decimal integer (int)
;; @example
;; (hex-dec "0")                 ==> 0L
;; (hex-dec "FF")                ==> 255L
;; (hex-dec "3")                 ==> 3L
;; (hex-dec "0123456789ABCDEF")  ==> 81985529216486895L
;; (hex-dec "7FFFFFFFFFFFFFFF")  ==> 9223372036854775807L
;; (hex-dec "8000000000000009")  ==> 9223372036854775817L
(define (hex-dec str)
"Convert a hexadecimal string to decimal integer"
  (local (digit val)
    (setq digit "0123456789ABCDEF")
    (setq val 0L)
    (dostring (c str)
      ; Ponendo val prima del numero 16 newLISP trasforma in big integer
      ; il risultato dell'operazione di moltiplicazione.
      (setq val (+ (* val 16) (find (char c) digit))))))

;; @syntax (base10-baseX number base)
;; @description Convert a number from base 10 to base X <= 10 (return integer)
;; @param <number> positive integer (base 10)
;; @param <base> destination base (X)
;; @return number in base X (int)
;; @example
;; (base10-baseX 45 7)   ==> 63
;; (base10-baseX 15 6)   ==> 23
;; (base10-baseX 23 4)  ==> 113
(define (base10-baseX number base)
  "Convert a number from base 10 to base X <= 10 (return integer)"
  (letn ((result 0) (power 1))
    (while (> number 0)
      (setq result (+ result (* (% number base) power)))
      (setq number (/ number base))
      (setq power (* power 10)))
    result))

;; @syntax (baseX-base10 number base)
;; @description Convert a number from base X <= 10 to base 10 (return integer)
;; @param <number> positive integer (base X)
;; @param <base> origin base (X)
;; @return number in base 10 (int)
;; @example
;; (baseX-base10 63 7)   ==> 45
;; (baseX-base10 23 6)   ==> 15
;; (baseX-base10 113 4)  ==> 23
(define (baseX-base10 number base)
  "Convert a number from base X <= 10 to base 10 (return integer)"
  (letn ((result 0) (power 1) (n number))
    (while (> n 0)
      (setq result (+ result (* (% n 10) power)))
      (setq n (/ n 10))
      (setq power (* power base)))
    result))

;; @syntax (base10-baseN number base)
;; @description Convert a number from base 10 to base N (<=62)
;; @param <number> positive integer (base 10)
;; @param <base> destination base (N)
;; @return number in base N (string)
;; @example
;; (base10-baseN 123 20)        ==> "63"
;; (base10-baseN 123 60)        ==> "23"
;; (base10-baseN 123456789 20)  ==> "1IBC1J9"
(define (base10-baseN number base)
"Convert a number from base 10 to base N (<=62)"
  (let ((charset "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
        (result '())
        (quotient number))
    (while (>= quotient base)
      (push (charset (% quotient base)) result)
      (setq quotient (/ quotient base)))
    (push (charset quotient) result)
    (join result)))

;; @syntax (baseN-base10 number-string base)
;; @description Convert a number from base N (<=62) to base 10
;; @param <number-string> number as string (base N)
;; @param <base> origin base (N)
;; @return number in base 10 (int)
;; @example
;; (baseN-base10 "63" 20)        ==> 123
;; (baseN-base10 "23" 60)        ==> 123
;; (baseN-base10 "1IBC1J9" 20)  ==> 123456789
(define (baseN-base10 number-string base)
"Convert a number from base N (<=62) to base 10"
  (let ((charset "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
        (result 0)
        (len (length number-string)))
    (dolist (digit (explode number-string))
      (setq result (+ (* result base) (find digit charset))))
    result))

;; @syntax (deg10-deg60 deg)
;; @description Convert decimal degrees to sexagesimal degrees
;; @param <deg> decimal degrees (float)
;; @return list (degs mins secs) sexagesimal degrees (float)
;; @example
;; (deg10-deg60 30.5)   ==> (30 30 0)
;; (deg10-deg60 2.8)    ==> (2 47 59.99999999999939)
;; (deg10-deg60 180.3)  ==> (180 18 4.096722960866828e-011)
(define (deg10-deg60 degrees)
"Convert decimal degrees to sexagesimal degrees"
  (local (udegree d m s)
    (if (> 0.0 degrees)
        (setq udegree (abs degrees))
        (setq udegree degrees))
    (setq d (int udegree))
    (setq m (int (mul 60.0 (sub udegree d))))
    (setq s (mul 3600.0 (sub udegree d (div m 60.0))))
    (if (> 0.0 degrees) (setq d (sub d 0)))
    (list d m s)))

;; @syntax (deg60-deg10 degs mins secs)
;; @description Convert sexagesimal degrees to decimal degrees
;; @param <degs> sexagesimal degrees (float)
;; @param <mins> sexagesimal minutes (float)
;; @param <secs> sexagesimal seconds (float)
;; @return decimal degrees (float)
;; @example
;; (deg60-deg10 30 30 0)                        ==> 30.5
;; (deg60-deg10 2 47 59.99999999999939)         ==> 2.8
;; (deg60-deg10 180 18 4.096722960866828e-011)  ==> 180.3
(define (deg60-deg10 degs mins secs)
"Convert sexagesimal degrees to decimal degrees"
  (local (dd)
    (if (< 0.0 degs)
        (setq dd (add degs (div mins 60.0) (div secs 3600.0)))
        (setq dd (add degs (- 0.0 (div mins 60.0)) (- 0.0 (div secs 3600.0)))))
    dd))

;; @syntax (deg-rad deg)
;; @description Convert decimal degrees to radiants
;; @param <deg> decimal degrees (float)
;; @return radiant (float)
;; @example
;; (deg-rad 1)    ==> 0.0174532925199433
;; (deg-rad 90)   ==> 1.570796326794897
;; (deg-rad 180)  ==> 3.141592653589793
(define (deg-rad deg)
"Convert decimal degrees to radiants"
  (mul deg 1.745329251994329577e-2))
;(define (deg-rad deg)
;"Convert decimal degrees to radiants"
;  (div (mul deg PI) 180))

;; @syntax (rad-deg rad)
;; @description Convert radiants to decimal degrees
;; @param <rad> radiant (float)
;; @return decimal degree (float)
;; @example
;; (rad-deg 1)   ==> 57.29577951308232
;; (rad-deg PI)  ==> 180
;; (rad-deg 0)   ==> 0
(define (rad-deg rad)
"Convert radiants to decimal degrees"
  (mul rad 57.29577951308232088))
;(define (rad-deg rad)
;"Convert radiants to decimal degrees"
;  (div (mul rad 180) PI))

;; @syntax (cart-polar x y)
;; @description Convert cartesian coordinate to polar coordinate
;; @param <x> coordinate x (float)
;; @param <y> coordinate y (float)
;; @return list (r theta) (float)
;; @example
;; (cart-polar 0 0)    ==> (0 0)
;; (cart-polar 3 4)    ==> (5 53.13010235415598)
;; (cart-polar -1 -1)  ==> (1.414213562373095 -135)
(define (cart-polar x y)
"Convert cartesian coordinate to polar coordinate"
  (list (sqrt (add (mul x x) (mul y y)))
        (div (mul (atan2 y x) 180) PI)))

;; @syntax (polar-cart r theta)
;; @description Convert polar coordinate to cartesian coordinate
;; @param <r> distance from origin (0,0) (float)
;; @param <theta> angle (degree) with x axis (float)
;; @return list (x y) (float)
;; @example
;; (polar-cart 0 0)                    ==> (0 0)
;; (polar-cart 5 53.13010235415598)    ==> (3 4)
;; (polar-cart 1.414213562373095 -135) ==> (-0.9999999999999998 -1)
(define (polar-cart r theta)
"Convert polar coordinate to cartesian coordinate"
  (let (t (div (mul theta PI) 180))
       (list (mul r (cos t)) (mul r (sin t)))))

;; @syntax (cels-fahr celsius)
;; @description Convert Celsius degrees to Fahrenheit degrees
;; @param <celsius> Celsius degree (float)
;; @return Fahrenheit degree (float)
;; @example
;; (cels-fahr 0)        ==> 32
;; (cels-fahr 100)      ==> 212
;; (cels-fahr -273.15)  ==> -459.67
(define (cels-fahr celsius)
"Convert Celsius degrees to Fahrenheit degrees"
  (add (div (mul celsius 9) 5) 32))

;; @syntax (fahr-cels fahrenheit)
;; @description Convert Fahrenheit degrees to Celsius degrees
;; @param <fahrenheit> Fahrenheit degree (float)
;; @return Celsius degree (float)
;; @example
;; (fahr-cels 32)       ==> 0
;; (fahr-cels 212)      ==> 100
;; (fahr-cels -459.67)  ==> -273.15
(define (fahr-cels fahrenheit)
"Convert Fahrenheit degrees to Celsius degrees"
  (div (mul (sub fahrenheit 32) 5) 9))

;; @syntax (rgb-hsv red green blu)
;; @description Convert a color from rgb to hsv
;; @param <red> red value (from 0 to 255.0)
;; @param <green> green value (from 0 to 255.0)
;; @param <blu> blu (from 0 to 255.0)
;; @return list (hue saturation value) (float)
;; @example
;; (rgb-hsv 255 255 255)       ==> (0 0 1)
;; (rgb-hsv 0 0 0)             ==> (0 0 0)
;; (rgb-hsv 80 80 80)          ==> (0 0 0.3137254901960784)
;; (rgb-hsv 63.75 127.5 127.5) ==> (0.4999999999999999 0.5 0.5)
(define (rgb-hsv r g b)
"Convert a color from rgb to hsv"
  (local (h s v var-r var-g var-b var-min var-max del-max del-r del-g del-b)
    (setq var-r (div r 255))
    (setq var-g (div g 255))
    (setq var-b (div b 255))
    (setq var-min (min var-r var-g var-b)) ; valore minimo di RGB
    (setq var-max (max var-r var-g var-b)) ; valore massimo di RGB
    (setq del-max (sub var-max var-min))   ; delta RGB
    (setq v var-max)
    (cond ((= 0 del-max) (setq h 0) (setq s 0)) ; tono di grigio
           (true ; colore
              (setq s (div del-max var-max))
              (setq del-r (div (add (div (sub var-max var-r) 6) (div del-max 2)) del-max))
              (setq del-g (div (add (div (sub var-max var-g) 6) (div del-max 2)) del-max))
              (setq del-b (div (add (div (sub var-max var-b) 6) (div del-max 2)) del-max))
              (cond ((= var-r var-max) (setq h (sub del-b del-g)))
                    ((= var-g var-max) (setq h (add (div 1 3) (sub del-r del-b))))
                    ((= var-b var-max) (setq h (add (div 2 3) (sub del-g del-r))))
                    (true println "error"))
              (if (< h 0) (setq h (add 1 h)))
              (if (> h 1) (setq h (sub 1 h)))))
    (list h s v)))

;; @syntax (hsv-rgb hue saturation value)
;; @description Convert a color from hsv to rgb
;; @param <hue> hue value (from 0 to 1.0)
;; @param <saturation> saturation value (from 0 to 1.0)
;; @param <value> value value (from 0 to 1.0)
;; @return list (red green blu) (float)
;; @example
;; (hsv-rgb 0 0 1)                   ==> (255 255 255)
;; (hsv-rgb 0 0 0)                   ==> (0 0 0)
;; (hsv-rgb 0 0 0.3137254901960784)  ==> (80 80 80)
;; (hsv-rgb 0.5 0.5 0.5)             ==> (63.75 127.5 127.5)
(define (hsv-rgb h s v)
"Convert a color from hsv to rgb"
  (local (r g b var-h var-i var-1 var-2 var-3 var-4 var-r var-g var-b)
    (cond ((= 0 s) (setq r (mul v 255)) (setq g (mul v 255)) (setq b (mul v 255)))
          (true
             (setq var-h (mul h 6))
             (if (= var-h 6) (setq var-h 0)) ; h deve essere minore di 1
             (setq var-i (floor var-h))
             (setq var-1 (mul v (sub 1 s)))
             (setq var-2 (mul v (sub 1 (mul s (sub var-h var-i)))))
             (setq var-3 (mul v (sub 1 (mul s (sub 1 (sub var-h var-i))))))
             (cond ((= 0 var-i) (setq var-r v)     (setq var-g var-3) (setq var-b var-1))
                   ((= 1 var-i) (setq var-r var-2) (setq var-g v)     (setq var-b var-1))
                   ((= 2 var-i) (setq var-r var-1) (setq var-g v)     (setq var-b var-3))
                   ((= 3 var-i) (setq var-r var-1) (setq var-g var-2) (setq var-b v))
                   ((= 4 var-i) (setq var-r var-3) (setq var-g var-1) (setq var-b v))
                   (true        (setq var-r v    ) (setq var-g var-1) (setq var-b var-2)))
             (setq r (mul var-r 255))
             (setq g (mul var-g 255))
             (setq b (mul var-b 255))))
    (list r g b)))

;; @syntax (int-roman num)
;; @description Convert an integer to a roman number
;; @param <num> integer number
;; @return roman number (string)
;; @example
;; (int-roman 4444)  ==> "MMMMCDXLIV"
;; (int-roman 16)    ==> "XVI"
(define (int-roman num)
"Convert an integer to a roman number"
  (local (table roman k)
    (setq table '(("M" 1000) ("CM" 900) ("D" 500) ("CD" 400)
          ("C" 100)("XC" 90)("L" 50)("XL" 40) ("X" 10) ("IX" 9) ("V" 5)
          ("IV" 4) ("I" 1)))
    (setq roman "")
    (dolist (el table)
      (setq k (/ num (last el)))
      (setq num (% num (last el)))
      (extend roman (dup (first el) k)))
    roman))

;; @syntax (roman-int roman)
;; @description Convert a roman number to integer
;; @param <roman> roman number (string)
;; @return integer number (int)
;; @example
;; (roman-int "MMMMCDXLIV")  ==> "4444"
;; (roman-int "XIIIIII")     ==> "16"
(define (roman-int roman)
"Convert a roman number to integer"
  (local (table curr prev num)
    (setq table '(("I" 1) ("V" 5) ("X" 10) ("L" 50) ("C" 100) ("D" 500) ("M" 1000)))
    (setq prev 0 num 0)
    ; iterate through all characters
    (dostring (ch roman)
      ; converts the current character into an integer
      (setq curr (lookup (char ch) table))
      ; pick the right case to add or subtract
      (if (>= prev curr)
          (setq num (+ num prev))
          (setq num (- num prev)))
      (setq prev curr))
    ; add the last value
    (setq num (+ num curr))))

;; @syntax (xlate <str-expression>)
;; @param <str-expression> The expression (infix, postfix, prefix) in a string
;; @return A newLISP expression or 'nil' on failure.
;; When 'nil' is returned then the error message is in 'result'.
;;
;; Note that the parser requires operators, variables and constants surrounded
;; by spaces except where parenthesis are used.
;;
;; @example
;; (xlate "3 + 4")                            ==> (add 3 4) ;; parses infix
;; (xlate "+ 3 4")                            ==> (add 3 4) ;; parses prefix s-expressions
;; (xlate "3 4 +")                            ==> (add 2 4) ;; parses postfix
;; (xlate "3 + * 4")                          ==> "ERR: missing argument for +"
;; (eval (xlate "3 + 4"))                     ==> 7
;; (xlate "(3 + 4.12) * (5 - 2.5)")           ==> (mul (add 3 4.12) (sub 5 2.5))
;; (xlate "(a + b) ^ 2 + (a - b) ^ 2")        ==> (add (pow (add a b) 2) (pow (sub a b) 2))
;; (xlate "x = (3 + sin(20)) * (5 - 2)")      ==> (setq x (mul (add 3 (sin 20)) (sub 5 2)))
;; (xlate "x = (3 + sin(10 - 2)) * (5 - 2)")  ==> (setq x (mul (add 3 (sin (sub 10 2))) (sub 5 2)))
;; (xlate "((a and b) or (c and (d or e)))")  ==> (or (and a b) (and c (or d e)))
;
; Main function
(define (xlate str)
"Convert infix-prefix-postfix expression to prefix" expression
(local (result operators)
  (if (catch (infix-xlate str) 'result)
    result                      ; if starts with ERR: is error else result
    (append "ERR: " result))))  ; newLISP error has occurred
; Auxiliary function
(define (infix-xlate str)
(local (tokens varstack opstack expression ops op nops var vars)
; operator priority table
; (token operator arg-count priority)
  (set 'operators '(
    ("=" setq 2 2)
    ("+" add 2 3)
    ("-" sub 2 3)
    ("*" mul 2 4)
    ("/" div 2 4)
    ("^" pow 2 5)
    ("abs" abs 1 9)
    ("acos" acos 1 9)
    ("asin" asin 1 9)
    ("atan" atan 1 9)
    ("sin" sin 1 9)
    ("sqrt" sqrt 1 9)
    ("tan" tan 1 9)
    ("cos" cos 1 9)
    ; added
    ("not" not 1 9)
    ("and" and 2 9)
    ("or" or 2 9)
    ; user functions
    ("nand" nand 2 9)
    ("nor" nor 2 9)
    ("xor" xor 2 9)
    ("xnor" xnor 2 9)))  ; add what else is needed
  (set 'tokens (parse str))
  (set 'varstack '())
  (set 'opstack '())
  (dolist (tkn tokens)
  (case tkn
        ("(" (push tkn opstack))
        (")" (close-parenthesis))
        (true (if (assoc tkn operators)
                  (process-op tkn)
                  (push tkn varstack)))))
  (while (not (empty? opstack))
        (make-expression))
  (set 'result (first varstack))
  (if (or (> (length varstack) 1) (not (list? result)))
    (throw "ERR: wrong syntax")
    result)))
; pop all operators and make expressions
; until an open parenthesis is found
(define (close-parenthesis)
 (while (not (= (first opstack) "("))
    (make-expression))
 (pop opstack))
; pop all operator, which have higher/equal priority
; and make expressions
(define (process-op tkn)
  (while (and opstack
              (<= (lookup tkn operators 3) (lookup (first opstack) operators 3)))
        (make-expression))
  (push tkn opstack))
; pops an operator from the opstack and makes/returns an
; newLISP expression
(define (make-expression)
  (set 'expression '())
  (if (empty? opstack)
        (throw "ERR: missing parenthesis"))
  (set 'ops (pop opstack))
  (set 'op (lookup ops operators 1))
  (set 'nops (lookup ops operators 2))
  (dotimes (n nops)
    (if (empty? varstack) (throw (append "ERR: missing argument for " ops)))
    (set 'vars (pop varstack))
    (if (atom? vars)
            (if (not (or (set 'var (float vars))
                         (and (legal? vars) (set 'var (sym vars))) ))
                (throw (append vars "ERR: is not a variable"))
                (push var expression))
            (push vars expression)))
  (push op expression)
  (push expression varstack))

;; @syntax (string-number str)
;; @description Find the relative number (A=1,...,Z=26,...,ZZ=702,...) (like spreadsheet column name)
;; @param <str> uppercase string
;; @return number (integer)
;; @example
;; (setq lst '("A" "B" "Z" "AA" "AB" "AZ" "ZZ" "AAA" "ABC"))
;; (map (fn(x) (list x (string-number x))) lst) ==>
;; (("A" 1) ("B" 2) ("Z" 26) ("AA" 27) ("AB" 28) ("AZ" 52) ("ZZ" 702) ("AAA" 703) ("ABC" 731))
(define (string-number str)
"Find the relative number from a string (A=1,...,Z=26,...,ZZ=702,...)"
  (let (num 0)
    ; like a base26 conversion
    (dostring (ch str)
      (setq num (+ (* num 26) ch -64)))
    num))

;; @syntax (number-string num)
;; @description Find the relative string (1=A,...,26=Z,...,702=ZZ,...) (like spreadsheet column name)
;; @param <num> integer number
;; @return string
;; @example
;; (setq numbers '(1 2 26 27 28 52 702 703 731))
;; (map (fn(x) (list x (number-string x))) numbers)  ==>
;; ((1 "A") (2 "B") (26 "Z") (27 "AA") (28 "AB") (52 "AZ") (702 "ZZ") (703 "AAA") (731 "ABC"))
(define (number-string num)
"Find the relative string from a number (1=A,...,26=Z,...,702=ZZ,...)"
  (local (str rem)
    (setq str "")
    (while (> num 0)
      ; calculate remainder
      (setq rem (% num 26))
      (cond ((zero? rem) ; rem = 0 --> "Z"
              ;(extend str "Z")
              (push "Z" str)
              (setq num (- (/ num 26) 1)))
            (true ; rem != 0 --> indexed char
              ;(extend str (char (+ (- rem 1) (char "A"))))
              (push (char (+ (- rem 1) 65)) str)
              (setq num (/ num 26)))))
    str))

;===========================================================================
;===========================================================================
;; <p><b><center>FRACTIONS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (frac-gen num len-p len-a)
;; @description Find the generating fraction of a floating number (periodic or non-periodic)
;; @param <num> floating number (float)
;; @param <len-p> length of period
;; @param <len-a> length of antiperiod
;; @return list (numerator denominator numerator/denominator) (int int float)
;; @example
;; (frac-gen 1.625 2 1)     ==> (1609 990 1.625252525252525)
;; (frac-gen 1.42703 3 2)   ==> (3853 2700 1.427037037037037)
;; (frac-gen 10.52803 2 3)  ==> (13897 1320 10.5280303030303)
;; (frac-gen 1.2 1 0)       ==> (11 9 1.222222222222222)
;; (frac-gen 3.141592 1 5)  ==> (2827433 900000 3.141592222222222)
;; (frac-gen 3.141592 1 6)  ==> (2827433 900000 3.141592)
;; (frac-gen 3.14159 1 4)   ==> (3927 1250 3.1416)
;; (frac-gen 1.9 1 0)       ==> (2 1 2)
;; (frac-gen 1.6250 1 3)    ==> (13 8 1.625)
(define (frac-gen num len-p len-a)
"Find the generating fraction of a floating number (periodic or non-periodic)"
  (local (n n1 n2 d d1 d2 g)
     ; calcolo numeratore
    (setq n1 (mul num (pow 10 (add len-p len-a))))
    (setq n2 (int (mul num (pow 10 len-a))) 0 10)
    (setq n (sub n1 n2))
    ; calcolo denominatore
    (setq d1 (dup "9" len-p))
    (setq d2 (dup "0" len-a))
    (setq d (int (append d1 d2)))
    ;semplifica numeratore/denominatore
    (setq g (gcd n d))
    (setq n (/ n g))
    (setq d (/ d g))
    ; risultato
    (list n d (div n d))))

; Funzioni ausiliarie
; Funzioni per il calcolo delle quattro operazioni
; aritmetiche con le frazioni: "+", "-" "*" "/"
;(define (rat n d)
;  (let (g (gcd n d))
;    (map (curry * 1L) ; for big-integer output
;         (list (/ n g) (/ d g)))))
;(define (+rat r1 r2)
;  (rat (+ (* (r1 0) (r2 1))
;          (* (r2 0) (r1 1)))
;       (* (r1 1) (r2 1))))
;(define (-rat r1 r2)
;  (rat (- (* (r1 0) (r2 1))
;          (* (r2 0) (r1 1)))
;       (* (r1 1) (r2 1))))
;(define (*rat r1 r2)
;  (rat (* (r1 0) (r2 0))
;       (* (r1 1) (r2 1))))
;(define (/rat r1 r2)
;  (rat (* (r1 0) (r2 1))
;       (* (r1 1) (r2 0))))
;
; Funzioni per il calcolo delle quattro operazioni
; aritmetiche con le frazioni: "+", "-" "*" "/"
; (big-integer enabled)
; Note: 0 is '(0 1)
; La funzione 'rat' riduce una frazione n/d ai minimi termini
(define (rat n d)
  (let (g (gcd n d))
    (map (curry * 1L)
         (list (/ n g) (/ d g)))))
(define (+rat r1 r2)
  (setq r1 (list (bigint (r1 0)) (bigint(r1 1))))
  (setq r2 (list (bigint (r2 0)) (bigint(r2 1))))
  (rat (+ (* (r1 0L) (r2 1L))
          (* (r2 0L) (r1 1L)))
       (* (r1 1L) (r2 1L))))
(define (-rat r1 r2)
  (setq r1 (list (bigint (r1 0)) (bigint(r1 1))))
  (setq r2 (list (bigint (r2 0)) (bigint(r2 1))))
  (rat (- (* (r1 0L) (r2 1L))
          (* (r2 0L) (r1 1L)))
       (* (r1 1L) (r2 1L))))
(define (*rat r1 r2)
  (setq r1 (list (bigint (r1 0)) (bigint(r1 1))))
  (setq r2 (list (bigint (r2 0)) (bigint(r2 1))))
  (rat (* (r1 0L) (r2 0L))
       (* (r1 1L) (r2 1L))))
(define (/rat r1 r2)
  (setq r1 (list (bigint (r1 0)) (bigint(r1 1))))
  (setq r2 (list (bigint (r2 0)) (bigint(r2 1))))
  (rat (* (r1 0L) (r2 1L))
       (* (r1 1L) (r2 0L))))

;; @syntax (+f frac1 frac2)
;; @description Sum two of more fractions (frac1 + frac2)
;; @param <frac1> pair of integer (num1 den1)
;; @param <frac2> pair of integer (num2 den2)
;; @return addition of fractions list (num den)
;; @example
;; (+f '(1 2) '(1 2))           ==> (1L 1L)
;; (+f '(1 2) '(1 2) '(1 2))    ==> (3L 2L)
;; (+f '(-1 -2) '(2 1) '(1 1))  ==> (-7L -2L)
(define-macro (+f)
"Sum two of more fractions (frac1 + frac2)"
  (apply +rat (map eval (args)) 2))

;; @syntax (-f frac1 frac2)
;; @description Subtract two or more fractions (frac1 - frac2)
;; @param <frac1> pair of integer (num1 den1)
;; @param <frac2> pair of integer (num2 den2)
;; @return difference of fractions list (num den)
;; @example
;; (-f '(1 2) '(1 2))          ==> (0L 1L)
;; (-f '(1 2) '(1 2) '(1 2))   ==> (-1L 2L)
(define-macro (-f)
"Subtract two or more fractions (frac1 - frac2)"
  (apply -rat (map eval (args)) 2))

;; @syntax (*f frac1 frac2)
;; @description Multiplicate two or more fractions (frac1 * frac2)
;; @param <frac1> pair of integer (num1 den1)
;; @param <frac2> pair of integer (num2 den2)
;; @return multiplication of fractions list (num den)
;; @example
;; (*f '(2 5) '(5 2))         ==> (1L 1L)
;; (*f '(1 2) '(1 2) '(1 2))  ==> (1L 8L)
(define-macro (*f)
"Multiplicate two or more fractions (frac1 * frac2)"
  (apply *rat (map eval (args)) 2))

;; @syntax (/f frac1 frac2)
;; @description Divide two or more fractions (frac1 / frac2)
;; @param <frac1> pair of integer (num1 den1)
;; @param <frac2> pair of integer (num2 den2)
;; @return division of fractions list (num den)
;; @example
;; (/f '(1 2) '(1 2) '(1 2))    ==> (2L 1L)
;; (/f '(4 1) '(1 1) '(1 2))    ==> (8L 1L)
(define-macro (/f)
"Divide two or more fractions (frac1 / frac2)"
  (apply /rat (map eval (args)) 2))

;; @syntax (gcd-frac frac1 frac2 ... fracN)
;; @description Calculate gcd of two or more fractions
;; @param <frac1> pair of integer (num1 den1)
;; @param <frac2> pair of integer (num2 den2)
;; @param <fracN> pair of integer (numN denN)
;; @return gcd of all fractions (num den)
;; @example
;; (gcd-frac '(10 20) '(40 30))           ==> (1L 6L)
;; (gcd-frac '(1 2) '(40 30))             ==> (1L 6L)
;; (gcd-frac '(77 120) '(4 11) '(14 45))  ==> (1L 3960L)
(define (gcd-frac)
"Calculate the gcd of two or more fractions"
  (setq lst '())
  ; riduce le frazioni ai minimi termini
  (doargs (f) (push (apply rat f) lst))
  ; calcola gcd delle frazioni
  (rat (apply gcd (map first lst))
       (apply lcm (map last lst))))

;; @syntax (lcm-frac frac1 frac2 ... fracN)
;; @description Calculate lcm of two or more fractions
;; @param <frac1> pair of integer (num1 den1)
;; @param <frac2> pair of integer (num2 den2)
;; @param <fracN> pair of integer (numN denN)
;; @return lcm of all fractions (num den)
;; @example
;; (lcm-frac '(10 20) '(40 30))           ==> (4L 1L)
;; (lcm-frac '(1 2) '(40 30))             ==> (4L 1L)
;; (lcm-frac '(77 120) '(4 11) '(14 45))  ==> (308L 1L)
(define (lcm-frac)
"Calculate the lcm of two or more fractions"
  (setq lst '())
  ; riduce le frazioni ai minimi termini
  (doargs (f) (push (apply rat f) lst))
  ; calcola lcm delle frazioni
  (rat (apply lcm (map first lst))
       (apply gcd (map last lst))))

;; @syntax (num-cf x terms)
;; @description Calculate the first n terms of the continued fraction of a number
;; @param <x> number (float)
;; @param <terms> number of terms of continued fraction
;; @return continued fraction (list)
;; @example
;; (num-cf (sqrt 2) 10)  ==> (1 2 2 2 2 2 2 2 2 2)
;; (num-cf 1.5 10)       ==> (1 2)
;; (num-cf 2 10)         ==> (2)
;; (num-cf 3.14159 6)    ==> (3 7 15 1 25 1)
;; (num-cf 3.245 10)     ==> (3 4 12 3 1 247777268231 4 1 2 1) (wrong)
(define (num-cf x terms)
"Calculate the first n terms of the continued fraction of a number:"
  (local (cf xi stop)
    (setq cf '())
    (setq stop nil)
    (for (k 0 (- terms 1) 1 stop)
      (setq xi (floor x))
      (push xi cf -1)
      (if (zero? (sub x xi) )
          (setq stop true)
          (setq x (div 1 (sub x xi)))))
    cf))

;; @syntax (fract-cf num den)
;; @description Calculate all the terms of the continued fraction of a fraction
;; @param <num> numerator of fraction
;; @param <den> denominator of fraction
;; @return continued fraction (list)
;; @example
;; (fract-cf 3 2)            ==> (1 2)
;; (fract-cf 2 1)            ==> (2)
;; (fract-cf 314159 100000)  ==> (3 7 15 1 25 1 7 4)
;; (fract-cf 3245 1000)      ==> (3 4 12 4) (correct)
(define (fract-cf num den)
"Calculate all the terms of the continued fraction of a fraction"
  (local (fc r out)
    (setq out '())
    (while (!= 0 r)
      (setq r (% num den))
      (setq fc (/ num den))
      (push fc out -1)
      (setq num den)
      (setq den r))
    out))

;; @syntax (cf-num cf)
;; @description Calculate the number of a continued fraction
;; @param <cf> continued fraction
;; @return number (float)
;; @example
;; (cf-num '(1 2 2 2 2 2 2 2 2 2))              ==> 1.41421362489487
;; (cf-num '(1 2))                              ==> 0.5
;; (cf-num '(2))                                ==> 2
;; (cf-num '(3 7 15 1 25 1))                    ==> 3.141590013140605
;; (cf-num '(3 4 12 3 1 247777268231 4 1 2 1))  ==> 3.245
;; (cf-num '(3 4 12 4))                         ==> 3.245
(define (cf-num cf)
"Calculate the number of a continued fraction"
  (local (x)
    (cond ((= (length cf) 1) (setq x (first cf)))
          (true
           (setq x (cf -1))
           (for (k (- (length cf) 2) 0 -1)
             (setq x (add (cf k) (div 1 x))))))
    x))

;; @syntax (cf-fract cf)
;; @description Calculate the convergent fraction of a continuous fraction
;; @param <cf> continued fraction
;; @return numerator and denominator (list of big integer)
;; @example
;; (cf-fract '(1 2 2 2 2 2 2 2 2 2))              ==> (3363 2378)
;; (cf-fract '(1 2))                              ==> (3 2)
;; (cf-fract '(2))                                ==> (2 1)
;; (cf-fract '(3 7 15 1 25 1 7 4))                ==> (314159 100000)
;; (cf-fract '(3 4 12 4))                         ==> (649 200)
(define (cf-fract cf)
"Calculate the convergent fraction of a continuous fraction"
  (local (p0 q0 p1 q1 p2 q2)
    (cond ((= (length cf) 1) (setq p2 (first cf) q2 1))
          (true
           (setq p0 1L q0 0L)
           (setq p1 (bigint (cf 0)) q1 1L)
           (for (k 1 (- (length cf) 1))
             (setq p2 (+ (* p1 (cf k)) p0))
             (setq q2 (+ (* q1 (cf k)) q0))
             ; k-esimo convergente
             ;(println (list p2 q2 (div p2 q2)))
             (setq p0 p1 q0 q1 p1 p2 q1 q2))))
    (list p2 q2)))

;; @syntax (egypt num den)
;; @description Calculate the egyptian fractions of a generic fraction
;; @param <num> numerator of fraction
;; @param <num> denominator of fraction
;; @return ((num1 den1) (num2 den2) ... (numN denN)) (list)
;; @example
;; (egypt 6 14)   ==>  ((1 3) (1 11) (1 231))
;; 6/14 = 3/7 = 1/3 + 1/11 + 1/231
;; (egypt 21 17)  ==>  ((1 1) (1 5) (1 29) (1 1233) (1 3039345))
(define (egypt num den)
"Calculate the egyptian fractions of a generic fraction"
  (let (out '())
    (egypt-aux num den)
    out))
; auxiliary function
(define (egypt-aux nr dr)
        ; numeratore o denominatore nullo
  (cond ((or (zero? nr) (zero? dr)) nil)
        ; se il numeratore divide il denominatore
        ; allora con una semplice divisione
        ; costruiamo la frazione nella forma 1/n
        ((zero? (% dr nr))
         (push (list 1 (/ dr nr)) out -1))
        ; se il denominatore divide il numeratore
        ; allora la frazione è un numero intero
        ((zero? (% nr dr))
         (push (list (/ nr dr) 1) out -1))
        ; quando il numeratore è maggiore del denominatore
        ; la prima frazione è un numero intero >= 1
        ((> nr dr)
         (push (list (/ nr dr) 1) out -1)
         ; ricorsione sulla parte rimanente
         (egypt-aux (% nr dr) dr))
        (true
         (let (n (+ (/ dr nr) 1))
          (push (list 1 n) out -1)
          ; ricorsione sulla parte rimanente
          (egypt-aux (- (* nr n) dr) (* dr n))))))

;===========================================================================
;===========================================================================
;; <p><b><center>COMPLEX NUMBERS</center></b></p>
;===========================================================================
;===========================================================================
;
; Simple math functions for complex number
;
; (a + ib) ==> (a b)
; a = real part
; b = imaginary part
;
; Extract real part "real"
(define (real num) (first num))
; Extract imaginary part "imag"
(define (imag num) (last num))
;
; |z|*e^it  ==> (z t)
; z = modulo
; t = phase
;
; Extract modulo
(define (modulo num) (first num))
; Extract phase
(define (phase num) (last num))

;; @syntax (cx-cart2cx-exp num)
;; @description Convert a complex number from cartesian form to exponential form
;; @param <num> complex number in cartesian form
;; @return complex number in exponential form (list)
;; @example
;; (cx-cart2cx-exp (list (sqrt 3) 1))  ==> (2 -0.5235987755982987)
(define (cx-cart2cx-exp num)
"Convert a complex number from cartesian form to exponential form"
  (let (modulo (sqrt (add (mul (real num) (real num)) (mul (imag num) (imag num)))))
       (list modulo
             (if (< (imag num) 0)
                 (acos (div (real num) modulo))
                 (sub 0 (acos(div (real num) modulo)))))))

; Convert a complex number from exponential form to cartesian form
;; @syntax (cx-exp2cx-cart num)
;; @description Convert a complex number from exponential form to cartesian form
;; @param <num> complex number in exponential form
;; @return complex number in cartesian form (list)
;; @example
;; (cx-cart2cx-exp (list (sqrt 3) 1))  ==> (2 -0.5235987755982987)
(define (cx-exp2cx-cart num)
"Convert a complex number from exponential form to cartesian form"
  (list (mul (modulo num) (cos (phase num)))
        (mul (modulo num) (sin (phase num)))))

;; @syntax (cx-add num1 num2)
;; @description Addition of two complex number (cartesian)
;; @param <num1> complex number in cartesian form
;; @param <num2> complex number in cartesian form
;; @return complex number in cartesian form (list)
;; @example
;;  (cx-add '(2 4) '(3 2)) ==> (5 6)
(define (cx-add num1 num2)
"Addition of two complex number (cartesian)"
  (list (add (real num1) (real num2)) (add (imag num1) (imag num2))))

;; @syntax (cx-sub num1 num2)
;; @description Subtraction of two complex number (cartesian)
;; @param <num1> complex number in cartesian form
;; @param <num2> complex number in cartesian form
;; @return complex number in cartesian form (list)
;; @example
;; (cx-sub '(5 6) '(3 2)) ==> (2 4)
(define (cx-sub num1 num2)
"Subtraction of two complex number (cartesian)"
  (list (sub (real num1) (real num2)) (sub (imag num1) (imag num2))))

;; @syntax (cx-mul num1 num2)
;; @description Multiplication of two complex number (cartesian)
;; @param <num1> complex number in cartesian form
;; @param <num2> complex number in cartesian form
;; @return complex number in cartesian form (list)
;; @example
;; (cx-mul '(5 6) '(3 2)) ==> (3 28)
(define (cx-mul num1 num2)
"Multiplication of two complex number (cartesian)"
  (list (sub (mul (real num1) (real num2)) (mul (imag num1) (imag num2)))
        (add (mul (imag num1) (real num2)) (mul (real num1) (imag num2)))))

;; @syntax (cx-div num1 num2)
;; @description Division of two complex number (cartesian)
;; @param <num1> complex number in cartesian form
;; @param <num2> complex number in cartesian form
;; @return complex number in cartesian form (list)
;; @example
;; (cx-div '(3 28) '(3 2)) ==> (5 6)
(define (cx-div num1 num2)
"Division of two complex number (cartesian)"
  (if (and (zero? (real num2)) (zero? imag num2))
    (list nil nil)
    (list (div (add (mul (real num1) (real num2)) (mul (imag num1) (imag num2)))
               (add (mul (real num2) (real num2)) (mul (imag num2) (imag num2))))
          (div (sub (mul (imag num1) (real num2)) (mul (real num1) (imag num2)))
               (add (mul (real num2) (real num2)) (mul (imag num2) (imag num2)))))))

;; @syntax (cx-conj num)
;; @description Conjugate of a complex number
;; @param <num> complex number in cartesian form
;; @return conjugate complex number in cartesian form (list)
;; @example
;; (cx-conj '(3 28)) ==> (3 -28)
;; (cx-conj '(2 -4)) ==> (2 4)
(define (cx-conj num)
"Conjugate of a complex number"
  (list (real num) (sub (imag num))))

;; @syntax (cx-inv num)
;; @description Inverse (reciprocal) of a complex number (cartesian)
;; @param <num> complex number in cartesian form
;; @return complex number in cartesian form (list)
;; @example
;; (cx-inv '(3 2))                 ==> (0.2307692307692308 -0.1538461538461539)
;; (cx-mul '(3 2) (cx-inv '(3 2))) ==> (1 0)
(define (cx-inv num)
"Inverse (reciprocal) of a complex number (cartesian)"
  (if (and (= (real num) 0) (= (imag num) 0))
      ; (list (nil nil)
      (list (div 1 0) (div 1 0))
      (list (div (real num) (add (mul (real num) (real num)) (mul (imag num) (imag num))))
            (div (sub 0 (imag num)) (add (mul (real num) (real num)) (mul (imag num) (imag num)))))))

;; @syntax (cx-pow num power)
;; @description Power of a complex number (cartesian)
;; @param <num> complex number in cartesian form
;; @param <power> power number
;; @return complex number in cartesian form (list)
;; @example
;; (cx-pow '(3 2) 2) ==> (5 12)
(define (cx-pow num power)
"Power of a complex number (cartesian)"
  (local (phase)
    (cond ((zero? power) (if (= 0 (real num)) (list 0 0) (list 1 0))) ;potenza nulla
          ((= power 1) (list (real num) (imag num))) ;potenza uguale ad 1
          ((> power 1) ;potenza positiva maggiore di 1
            (setq phase num)
            (for (i 1 (sub power 1))
              (setq phase (cx-mul (list (real phase) (imag phase)) (list (real num) (imag num)))))
            (list (real phase) (imag phase)))
          ((< power 0) ;potenza negativa
            (setq phase num)
            (setq power (abs power))
            (for (i 1 (sub power 1))
              (setq phase (cx-mul (list (real phase) (imag phase)) (list (real num) (imag num)))))
            (cx-inv (list (real phase) (imag phase))))))) ;calcolo numero inverso

;; @syntax (cx-sqrt num)
;; @description Square root of a complex number (cartesian)
;; @param <num> complex number in cartesian form
;; @return complex number in cartesian form (list)
;; @example
;; (cx-sqrt '(5 12)) ==> (3 2)
;; (cx-sqrt '(4 0)) ==> (2 0)
(define (cx-sqrt num)
"Square root of a complex number (cartesian)"
  (local (a b a1 b1)
    (setq a (real num))
    (setq b (imag num))
    (setq a1 (mul .5 (sqrt 2) (sqrt (add (sqrt (add (mul a a) (mul b b))) a))))
    (cond ((> b 0)
           (setq b1 (mul .5 (sqrt 2) (sqrt (sub (sqrt (add (mul a a) (mul b b))) a)))))
          ((< b 0)
           (setq b1 (- (mul .5 (sqrt 2) (sqrt (sub (sqrt (add (mul a a) (mul b b))) a))))))
          ((zero? b)
           (setq b1 0)))
    (list a1 b1)))

;===========================================================================
;===========================================================================
;; <p><b><center>TIME ARITHMETIC</center></b></p>
;===========================================================================
;===========================================================================
;
; Addition and subtraction of time values
;
; time = hours-minutes-seconds ==> (hh mm ss)
;
; Time normalization
; check and recalculate times that have minutes
; and/or seconds values greater than or equal to 60
; (do not work with negative value)
(define (redux-time t)
  (local (h m s get-hh get-mm get-ss)
    ; Extract hours
    (define (get-hh t) (t 0))
    ; Extract minutes
    (define (get-mm t) (t 1))
    ; Extract seconds
    (define (get-ss t) (t 2))
    (setq h (get-hh t)) (setq m (get-mm t)) (setq s (get-ss t))
    ; normalizza secondi (il valore dei secondi deve essere minore di 60)
    (while (>= s 60) (setq s (sub s 60)) (++ m))
    ; normalizza minuti (il valore dei minuti deve essere minore di 60)
    (while (>= m 60) (setq m (sub m 60)) (++ h))
    (list h m s)))

; Addition of time (auxiliary function)
(define (time-add-aux t1 t2)
  (local (h m s ch)
    ; riduzione dei tempi ai minimi termini
    (setq t1 (redux-time t1))
    (setq t2 (redux-time t2))
    (setq h (add (get-hh t1) (get-hh t2)))
    (setq m (add (get-mm t1) (get-mm t2)))
    (setq s (add (get-ss t1) (get-ss t2)))
    (redux-time (list h m s))))

; Subtraction of time (auxiliary function)
(define (time-sub-aux t1 t2)
  (local (h m s h1 m1 s1 h2 m2 s2 ch)
    ; riduzione dei tempi ai minimi termini
    (setq t1 (redux-time t1))
    (setq t2 (redux-time t2))
    ; estrazione ore (h), minuti (m), secondi (s)
    (setq h1 (get-hh t1)) (setq m1 (get-mm t1)) (setq s1 (get-ss t1))
    (setq h2 (get-hh t2)) (setq m2 (get-mm t2)) (setq s2 (get-ss t2))
    ; trova il tempo maggiore
    (if (< (+ (* (t1 0) 3600) (* (t1 1) 60) (t1 2))
           (+ (* (t2 0) 3600) (* (t2 1) 60) (t2 2)))
        (begin (swap h1 h2) (swap m1 m2) (swap s1 s2) (setq ch true)))
    ; sottrazione dei tempi
    (if (<= s2 s1) (setq s (sub s1 s2))
        (begin (setq s (add 60 (sub s1 s2))) (++ m2)))
    (if (<= m2 m1) (setq m (sub m1 m2))
        (begin (setq m (add 60 (sub m1 m2))) (++ h2)))
    (setq h (sub h1 h2))
    ; se abbiamo scambiato i due tempi (perchè il primo tempo era minore)
    ; allora cambiamo il segno delle ore o dei minuti o dei secondi
    (if (= ch true)
      (begin
        (setq h (sub 0 h))
        (if (= h 0) (setq m (sub 0 m)))
        (if (and (= h 0) (= m 0) (setq s (sub 0 s))))))
    (list h m s)))

;; @syntax (time-add t1 t2 ... tn)
;; @description Addition of two or more time values (hh mm ss)
;; @param <t1> time values
;; @param <t2> time values
;; @return time (list)
;; @example
;; (time-add '(10 60 60) '(10 30 30))           ==> (21 31 30)
;; (time-add '(60 1200 1200) '(60 120 300))     ==> (142 25 0)
;; (time-add '(155 3 20) '(122 13 21))          ==> (277 16 41)
;; (time-add '(150 300 200) '(120 130 201))     ==> (277 16 41)
;; (time-add '(2 20 20) '(2 20 20) '(2 20 20))  ==> (7 1 0)
;; (time-add '(1 20 40) '(0 20 40) '(1 0 0))    ==> (2 41 20)
;; (time-add '(0 0 -5) '(0 0 5))                ==> (0 0 0)
;; (time-add '(-1 5 -5) '(2 4 5))               ==> (1 9 0)
;; (time-add '(-2 2 -59) '(1 1 50))             ==> (-1 3 -9)
(define-macro (time-add)
"Addition of two or more time values (hh mm ss)"
  ; somma tutti i tempi passati come argomento
  (apply time-add-aux (map eval (args)) 2))

;; @syntax (time-sub t1 t2 ... tn)
;; @description Subtraction of two or more time values (hh mm ss)
;; @param <t1> time values
;; @param <t2> time values
;; @return time (list)
;; @example
;; (time-sub '(2 2 2) '(1 1 1) '(1 1 1))        ==> (0 0 0)
;; (time-sub '(155 3 20) '(122 13 21))          ==> (32 49 59)
;; (time-sub '(150 300 200) '(120 130 201))     ==> (32 49 59)
;; (time-sub '(120 130 201) '(150 300 200))     ==> (-32 49 59)
;; (time-sub '(24 58 2) '(24 58 1))             ==> (0 0 1)
;; (time-sub '(24 58 1) '(24 58 2))             ==> (0 0 -1)
;; (time-sub '(24 58 1) '(24 59 2))             ==> (0 -1 1)
;; (time-sub '(-3 0 0) '(-2 0 0))               ==> (-1 0 0)
;; (time-sub '(0 0 -1) '(0 0 -2))               ==> (0 0 1)
;; (time-sub '(2 20 20) '(2 20 20) '(2 20 20))  ==> (-2 20 20)
;; (time-sub '(1 20 30) '(1 20 35) '(0 0 5))    ==> (0 0 -10)
;; (time-sub '(2 20 30) '(2 20 35))             ==> (0 0 -5)
;; (time-sub '(2 20 30) '(2 20 35) '(0 0 5))    ==> (0 0 -10)
;; (time-sub '(11 2 26) '(0 32 56))             ==> (10 29 30)
(define-macro (time-sub)
"Subtraction of two or more time values (hh mm ss)"
  ; sottrae tutti i tempi passati come argomento
  (apply time-sub-aux (map eval (args)) 2))

; time comparison operator: =, >, <, >=, <=

;; @syntax (time-sec t)
;; @description Convert a time (hours minutes seconds) in seconds
;; @param <t1> time values (hh mm ss) (list)
;; @return number of seconds (integer)
;; @example
;; (time-sec '(12 30 10))  ==> 45010
(define (time-sec t)
"Convert a time (hours minutes seconds) in seconds"
  (+ (* (t 0) 3600) (* (t 1) 60) (t 2)))

;; @syntax (time= t1 t2)
;; @description Check if two times are equal
;; @param <t1> time values
;; @return true or nil (boolean)
;; @example
;; (time= '(12 30 10) '(12 30 10))  ==> true
;; (time= '(12 30 10) '(13 30 10))  ==> nil
(define (time= t1 t2)
"Check if two times are equal"
  (= (time-sec t1) (time-sec t2)))

;; @syntax (time> t1 t2)
;; @description Check if a time (t1) is greater of another time (t2)
;; @param <t1> time values
;; @param <t2> time values
;; @return true or nil (boolean)
;; @example
;; (time> '(12 30 10) '(12 30 10))  ==> nil
;; (time> '(12 30 10) '(13 30 10))  ==> nil
;; (time> '(14 30 10) '(13 30 10))  ==> true
(define (time> t1 t2)
"Check if a time (t1) is greater of another time (t2)"
  (> (time-sec t1) (time-sec t2)))

;; @syntax (time< t1 t2)
;; @description Check if a time (t1) is lesser of another time (t2)
;; @param <t1> time values
;; @param <t2> time values
;; @return true or nil (boolean)
;; @example
;; (time< '(12 30 10) '(12 30 10))  ==> nil
;; (time< '(12 30 10) '(13 30 10))  ==> true
;; (time< '(14 30 10) '(13 30 10))  ==> nil
(define (time< t1 t2)
"Check if a time (t1) is lesser of another time (t2)"
  (< (time-sec t1) (time-sec t2)))

;; @syntax (time>= t1 t2)
;; @description Check if a time (t1) is equal or greater of another time (t2)
;; @param <t1> time values
;; @param <t2> time values
;; @return true or nil (boolean)
;; @example
;; (time>= '(12 30 10) '(12 30 10))  ==> true
;; (time>= '(12 30 10) '(13 30 10))  ==> nil
;; (time>= '(14 30 10) '(13 30 10))  ==> true
(define (time>= t1 t2)
"Check if a time (t1) is equal or greater of another time (t2)"
  (>= (time-sec t1) (time-sec t2)))

;; @syntax (time<= t1 t2)
;; @description Check if a time (t1) is equal or lesser of another time (t2)
;; @param <t1> time values
;; @param <t2> time values
;; @return true or nil (boolean)
;; @example
;; (time<= '(12 30 10) '(12 30 10))  ==> true
;; (time<= '(12 30 10) '(13 30 10))  ==> true
;; (time<= '(14 30 10) '(13 30 10))  ==> nil
(define (time<= t1 t2)
"Check if a time (t1) is equal or lesser of another time (t2)"
  (<= (time-sec t1) (time-sec t2)))

;; @syntax (period msec show)
;; @description Convert a millisec number in hours, minutes, seconds, millisecs
;; @param <msec> Positive integer number of millisec (int)
;; @param <show> true or nil (true -> print the values of conversion)
;; @return list (days hours minutes seconds millisecs)
;; @example
;; (period 1000 true)     ==> 1s (0 0 0 1 0)
;; (period 1184567 true)  ==> 19m 44s 567ms (0 0 19 44 567)
;; (period 163458000)     ==> (1 21 24 18 0)
(define (period msec show)
"Print a millisec number in hours, minutes, seconds, millisec"
  (local (conv unit expr val out)
    (setq conv '(("d" 86400000) ("h" 3600000) ("m" 60000) ("s" 1000) ("ms" 1)))
    (setq out '())
    (setq msec (int msec))
    (dolist (el conv)
      (setq unit (el 0))
      (setq expr (el 1))
      (setq val (/ msec expr))
      ; numero di millisecondi rimasti
      ; (resto della divisione)
      (setq msec (% msec expr))
      (push val out -1)
      (if (and (> val 0) show)
        (print val unit " ")))
    (if show (println))
    out))

;; @syntax (time-list t1 t2)
;; @description Generate a list of times (hh mm ss) from t1 to t2
;; @param <t1> time values
;; @param <t2> time values
;; @return list of times ((hh1 mm1 ss1) ... (hh2 mm2 ss2))
;; @example
;; (time-list '(1 0 0) '(1 0 10))  ==> ((1 0 0) (1 0 1) (1 0 2) (1 0 3) (1 0 4) (1 0 5) (1 0 6) (1 0 7) (1 0 8) (1 0 9) (1 0 10)
;; (length (time-list '(0 0 0) '(23 59 59))) ==> 86400
(define (time-list t1 t2)
"Generate a list of times (hh mm ss) from t1 to t2"
  (local (out a b)
    (setq out '())
    (for (h (t1 0) (t2 0))
      (for (m 0 59)
        (for (s 0 59)
          (push (list h m s) out -1))))
    (setq a (find t1 out))
    (setq b (find t2 out))
    (slice out a (+ (- b a) 1))))

;===========================================================================
;===========================================================================
;; <p><b><center>MATHEMATICAL FUNCTIONS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (positive? x)
;; @description Check if a number is greater than 0
;; @param <x> float or integer number
;; @return true or nil
;; @example
;; (positive? 3)   ==> true
;; (positive? -1)  ==> nil
;; (positive? 0)   ==> nil
(define (positive? x)
"Check if a number is greater than 0"
  (> x 0))

;; @syntax (negative? x)
;; @description Check if a number is lesser than 0
;; @param <x> float or integer number
;; @return true or nil
;; @example
;; (negative? 3)   ==> nil
;; (negative? -1)  ==> true
;; (negative? 0)   ==> nil
(define (negative? x)
"Check if a number is greater than 0"
  (< x 0))

;; @syntax (cbrt x)
;; @description Calculate the cube root of a number
;; @param <x> float or integer number
;; @return cube root of x (float)
;; @example
;; (cbrt 12)    ==> 2.289428485106664
;; (cbrt 125)   ==> 4.999999999999999
;; (cbrt -125)  ==>-4.999999999999999
(define (cbrt x)
"Calculate the cube root of a number"
  (if (< x 0)
      (sub (pow (sub x) (div 3)))
      ;else (positive number)
      (pow x (div 3))))

;; @syntax (sign x)
;; @description Return the sign of a number
;; @param <x> float or integer number
;; @return 0 or 1 or -1 (integer)
;; @example
;; (sign 2)     ==> 1
;; (sign -3)    ==> -1
;; (sign 0.0)   ==> 0
;; (sign -0.0)  ==> 0
;; (sign +0.0)  ==> 0
(define (sign x)
"Return the sign of a float number"
  (cond ((> x 0) 1)
        ((< x 0) -1)
        (true 0)))

;; @syntax (fractional x)
;; @description Return the fractional part of a number
;; @param <x> float or integer number
;; @return fractional part (integer)
;; @example
;; (fractional 1.123456789)           ==> 123456789
;; (fractional 2)                     ==> 0
;; (fractional 3.)                    ==> 0
;; (fractional 4.1)                   ==> 1
;; (fractional 1.123456789123456789)  ==> 123456789123457
(define (fractional x)
"Return the fractional part of a number"
  (letn ( (x (string x)) (idx (find "." x)) )
    (if idx
        (int (slice x (+ (find "." x) 1)) 0 10)
        ;else
        0)))

;; @syntax (divide num1 num2 digits)
;; @description Calculate the division num1/num2 with a predefined number of digits after the decimal point
;; @param <num1> dividend
;; @param <num2> divisor
;; @param <digits> number of digits after the decimal point
;; @return string
;; @example
;; (divide 12345 123456)     ==> "0.0999951399688958"
;; (divide 12345 123456 40)  ==> "0.0999951399688958009331259720062208398133"
;; (divide 12345 111 20)     ==> "111.21621621621621621621"
(define (divide num1 num2 digits)
"Calculate the division num1/num2 with a predefined number of digits after the decimal point"
  (local (intero out resto resti virgola dividendo cifra)
    ; calcolo parte intera
    (setq intero "")
    (cond ((= num1 num2) "1")
          ((zero? (% num1 num2)) (string (/ num1 num2)))
          (true
          (when (> num1 num2)
                (setq intero (string (/ num1 num2)))
                (setq num1 (% num1 num2)))
          ; calcolo parte decimale
          (setq out '())
          (setq resto nil)
          (setq virgola nil)
          (setq digits (or digits 16))
          ; Ciclo fino a che non abbiamo resto 0...
          (until (zero? resto)
            ; Calcolo del dividendo corrente
            (setq dividendo (divide-aux num1 num2))
            ; Calcola la cifra corrente del risultato
            (setq cifra (/ dividendo num2))
            (push cifra out -1)
            ; Calcolo del resto
            (setq resto (- dividendo (* cifra num2)))
            ; Calcolo nuovo numero
            (cond
              ; Se resto = 0,
              ; allora fine della divisione (se abbiamo messo la virgola)
              ((and (zero? resto) virgola) nil)
              (true
                ; Creazione nuovo numero
                (setq num1 (int (string resto
                                (slice (string num1) (length dividendo))) 0 10))
                ; Se il nuovo numero < divisore, allora mettiamo la virgola e
                ; aggiungiamo uno zero al nuovo numero
                (when (< num1 num2)
                  (setq num1 (* num1 10))
                  ; mettiamo la virgola se non l'abbiamo già messa prima
                  (if (not virgola) (begin
                      (setq virgola true) (push "." out -1))))))
            ;(print (join (map string out))) (read-line)
            ; Se abbiamo calcolato il numero di decimali predefinito,
            ; allora fermiamo la divisione (ponendo resto = 0)
            (when virgola
              (if (> (length (slice out (find "." out))) digits)
                  (setq resto 0))))
          (when (!= intero "")
            (pop out) (push intero out))
          (join (map string out))))))
; Funzione che trova il dividendo più piccolo tra due numeri
(define (divide-aux num1 num2)
  (cond ((<= num1 num2) num1)
    (true
      (let ( (dividendo 0L) (k 0) (L1 (int-list num1)) )
        (while (< dividendo num2)
          (setq dividendo (+ (L1 k) (* dividendo 10)))
          (++ k))
        dividendo))))

;; @syntax (decimal-period m n)
;; @description Calculate integer division m/n, its antiperiod and period
;; @param <m> integer
;; @param <n> integer
;; @return list (m/n antiperiod period) (int string string)
;; @example
;; (decimal-period 13 12)   ==> (1 "08" "3")
;; (decimal-period 1 7)     ==> (0 "" "142857")
;; (decimal-period 4 4)     ==> (1 "" "0")
;; (decimal-period 1 4)     ==> (0 "25" "0")
;; (decimal-period 8 4)     ==> (2 "" "0")
;; (decimal-period 1 983)   ==> (0 "" "0010172939...499491353")
(define (decimal-period M N)
"Calculate integer division m/n, its antiperiod and period"
  (let ( (resti '())
         (cifre '())
         (indici '())
         (resto (% M N))
         (idx '())
         (decimali "")
         (periodo "")
         (antiperiodo "") )
    ; ciclo fino a che i resti sono diversi
    (while (not (member resto resti))
      (push resto resti -1)
      (push (floor (/ (* resto 10) N)) cifre -1)
      (setq resto (% (* resto 10) N)))
    ; cifra seguente il periodo
    (push (floor (/ (* resto 10) N)) cifre -1)
    ; ultimo resto (uguale ad un resto precedente)
    (push resto resti -1)
    ; trova gli indici del periodo (dalla lista dei resti)
    (setq idx (ref-all (resti -1) resti))
    ; crea la stringa con tutti i decimali
    (setq decimali (join (map string cifre)))
    ; calcola il periodo
    (setq periodo (slice decimali (idx 0 0) (- (idx 1 0) (idx 0 0))))
    ; calcola l'antiperiodo
    (setq antiperiodo (slice decimali 0 (idx 0 0)))
    ; Output formato stringa
    ;(println (string (/ M N) "." antiperiodo "(" periodo ")"))
    ; Output formato lista
    (list (/ M N) antiperiodo periodo)))

;; @syntax (between-close x y z)
;; @description Return true iff number x is >= y and <= z
;; @param <x> float or integer number
;; @param <y> float or integer number
;; @param <z> float or integer number
;; @return true or nil
;; @example
;; (between-close -0.1 -0.1 2)  ==> true
;; (between-close 2 4 -2)       ==> true
;; (between-close 2 -2 4)       ==> true
;; (between-close 2 -7 5)       ==> true
;; (between-close 2 -5 -7)      ==> nil
(define (between-close x y z)
  "Return true iff number x is >= y and <= z."
  (or (<= y x z) (>= y x z)))

;; @syntax (between-open x y z)
;; @description Return true iff number x is > y and < z
;; @param <x> float or integer number
;; @param <y> float or integer number
;; @param <z> float or integer number
;; @return true or nil
;; @example
;; (between-open -0.1 -0.1 2)   ==> nil
;; (between-open -0.01 -0.1 2)  ==> true
;; (between-open -0.1 -0.1 2)   ==> nil
(define (between-open x y z)
  "Return true iff number x is > y and < z."
  (or (< y x z) (> y x z)))

;; @syntax (mul-poly p1 p2)
;; @description Multiplication between two polynomials
;; @param <p1> First polynomial
;; @param <p2> Second polynomial
;; @return polynomial (list)
;; @example
;; f(x) = a0 + a1*x + a2*x^2 + ... + an*x^n
;; (a0 a1 a2 ... an)
;; (mul-poly '(0 1 2) '(0 1 2))  ==> (0 0 1 4 4)
(define (mul-poly p1 p2)
"Multiplication between two polynomials"
  (local (res l1 l2)
    (setq l1 (length p1))
    (setq l2 (length p2))
    (setq res (dup 0 (+ l1 l2 (- 1))))
    (for (i 0 (- l1 1))
      (for (j 0 (- l2 1))
        (setf (res (+ i j)) (add (res (+ i j)) (mul (p1 i) (p2 j))))))
    res))

;; @syntax (div-poly p1 p2)
;; @description Division between two polynomials
;; @param <p1> First polynomial
;; @param <p2> Second polynomial
;; @return quotient list and remainder list (list)
;; @example
;; f(x) = a0 + a1*x + a2*x^2 + ... + an*x^n
;; (a0 a1 a2 ... an)
;; (div-poly '(-42 0 -12 1) '(-3 1))  ==> ((-27 -9 1) (-123))
(define (div-poly p1 p2)
"Division between two polynomials"
  (local (res normalizer coef)
    (reverse p1)
    (reverse p2)
    (setq res p1)
    (setq normalizer (p2 0))
    (for (i 0 (- (length p1) (- (length p2) 1) 1))
      (setf (res i) (div (res i) normalizer))
      (setq coef (res i))
      (if (!= coef 0)
          (for (j 1 (- (length p2) 1))
            (setf (res (+ i j)) (sub (res (+ i j)) (mul (p2 j) coef))))))
    (setq separator (- (length res) (- (length p2) 1)))
    (list (reverse (slice res 0 separator)) (reverse (slice res separator)))))

;; @syntax (add-poly p1 p2)
;; @description Addition between two polynomials
;; @param <p1> First polynomial
;; @param <p2> Second polynomial
;; @return polynomial (list)
;; @example
;; f(x) = a0 + a1*x + a2*x^2 + ... + an*x^n
;; (a0 a1 a2 ... an)
;; (add-poly '(5 0 10 6) '(1 2 4))  ==> (6 2 14 6)
(define (add-poly p1 p2)
"Addition between two polynomials"
  (local (res l1 l2)
    (setq l1 (length p1))
    (setq l2 (length p2))
    (cond ((>= l1 l2)
           (setq res p1)
           (for (i 0 (- l2 1))
             (setf (res i) (add (res i) (p2 i)))))
          ((< l1 l2)
           (setq res p2)
           (for (i 0 (- l1 1))
             (setf (res i) (add (res i) (p1 i))))))
    res))

;; @syntax (sub-poly p1 p2)
;; @description Subtraction between two polynomials
;; @param <p1> First polynomial
;; @param <p2> Second polynomial
;; @return polynomial (list)
;; @example
;; f(x) = a0 + a1*x + a2*x^2 + ... + an*x^n
;; (a0 a1 a2 ... an)
;; (sub-poly '(5 0 10 6) '(1 2 4))  ==> (4 -2 6 6)
(define (sub-poly p1 p2)
"Subtraction between two polynomials"
  (local (res l1 l2)
    (setq l1 (length p1))
    (setq l2 (length p2))
    (cond ((>= l1 l2)
           (setq res p1)
           (for (i 0 (- l2 1))
             (setf (res i) (sub (res i) (p2 i)))))
          ((< l1 l2)
           (setq res p2)
           (for (i 0 (- l1 1))
             (setf (res i) (sub (p1 i) (res i))))))
    res))

;; @syntax (delta% x y)
;; @description Calculate the percentage change between two numbers x and y.
;; @param <x> number (int o float)
;; @param <y> number (int o float)
;; @return delta percentage (float)
;; @example
;; (delta% 50 100) ==> 100
;; (delta% 100 50) ==> -50
;; (delta% 20 60)  ==> 200
;; (delta% 60 20)  ==> -66.66666666666667
(define (delta% x y)
"Calculate the percentage change between two numbers x and y."
  (div (mul (sub y x) 100) x))

;; @syntax (one? num)
;; @description Check if a number is equal to 1 (one)
;; @param <num> number (int o float)
;; @return true or nil
;; @example
;; (one? 1)    ==> true
;; (one? 1.0)  ==> true
;; (one? 0)    ==> nil
(define (one? num)
"Check if a number is equal to 1 (one)"
  (= num 1))

;; @syntax (same-sign? num)
;; @description Check if two numbers have same sign
;; @param <num> number (int o float)
;; @return true or nil
;; @example
;; (same-sign? 2 2)    ==> true
;; (same-sign? -2 2)   ==> nil
;; (same-sign? -2 -2)  ==> true
;; (same-sign? 2 -2)   ==> nil
;; (same-sign? 2 0)    ==> nil
(define (same-sign? x y)
"Check if two numbers have same sign"
  (if (or (zero? x) (zero? y)) nil
      ;else
      (= (> x 0) (> y 0))))

;; @syntax (dot-product x y)
;; @description Calculate the dot-product of two list/array of arbitrary length
;; @param <x> list or array
;; @param <y> list or array
;; @return float number (dot-product)
;; @example
;; (dot-product '(1 3) '(-2 -1))       ==> -5
;; (dot-product '(1 3 -5) '(4 -2 -1))  ==> 3
(define (dot-product x y)
"Calculate the dot-product of two list/array of arbitrary length"
  (apply add (map mul x y)))

;; @syntax (cross-product x y)
;; @description Calculate the cross-product of two list/array of length 3
;; @param <x> list or array
;; @param <y> list or array
;; @return list or array (cross-product)
;; @example
;; (cross-product '(3 -5 4) '(2 6 5))  ==> (-49 -7 28)
;; (cross-product '(2 3 4) '(5 6 7))   ==> (-3 6 -3)
(define (cross-product x y)
"Calculate the cross-product of two list/array of length 3"
  (let ((xlen (length x)) (ylen (length y)))
    (cond ((or (zero? xlen) (zero? ylen)) '())
          ((or (!= 3 xlen) (!= 3 ylen)) '())
          ((!= xlen ylen) '())
          (true
            (list (sub (mul (x 1) (y 2)) (mul (x 2) (y 1)))
                  (sub (mul (x 2) (y 0)) (mul (x 0) (y 2)))
                  (sub (mul (x 0) (y 1)) (mul (x 1) (y 0))))))))

;; @syntax (deter-int matrix)
;; @description Calculate the determinant of an integer matrix
;; @param <matrix> list of list
;; @return big-integer
;; @example
;; (deter-int '((0 0 1) (0 2 3) (1 4 5)))  ==> -2L
;; (deter-int '((1 2 3) (4 5 6) (7 8 8)))  ==> 3L
(define (deter-int matrix)
"Calculate the determinant of an integer matrix"
  (local (n m d pivot segno riga i j k tmp trovato)
    (setq n (length matrix))
    ; converte i valori della matrice in big integer
    (setq m (map (fn (row) (map bigint row)) matrix))
    (cond
      ((= n 0) 1L)
      ((= n 1) (bigint ((m 0) 0)))
      (true
        (setq d 1L)
        (setq segno 1L)
        (for (k 0 (- n 2))
          ; cerca un pivot non nullo
          (setq trovato nil)
          (setq riga k)
          (while (and (< riga n) (not trovato))
            (if (!= ((m riga) k) 0)
                (setq trovato true)
                (++ riga)))
          ; matrice singolare
          (if (not trovato)
              (begin
                (setq segno 0L)
                (setq k n)))
          ; eventuale scambio di righe
          (if (and (!= segno 0L) (!= riga k))
              (begin
                (setq tmp (m k))
                (setf (m k) (m riga))
                (setf (m riga) tmp)
                (setq segno (- segno))))
          (if (!= segno 0L)
              (begin
                (setq pivot ((m k) k))
                (for (i (+ k 1) (- n 1))
                  (for (j (+ k 1) (- n 1))
                    (setf ((m i) j)
                          (/ (- (* pivot ((m i) j))
                                (* ((m i) k) ((m k) j)))
                             d))))
                (setq d pivot))))
        (if (= segno 0L)
            0L
            (* segno ((m (- n 1)) (- n 1))))))))

;; @syntax (proportion a b c d)
;; @description Calcolate the missing value (0) of proportion a/b=c/d
;; @param <a,b,c,d> numbers (0=missing value) (int o float)
;; @return missing value or true or nil o (nil)
;; @example
;; (proportion 4 0 10 5)  ==> 2
;; (proportion 10 5 4 3)  ==> nil
;; (proportion 10 5 4 2)  ==> true
;; (proportion 4 3 0 0)   ==> (nil)
(define (proportion a b c d)
"Calcolate the missing value (0) of proportion a/b=c/d"
        ; nessuno zero: controllo proporzione...
  (cond ((= '(0) (count '(0) (list a b c d)))
         (= (div a b) (div c d)))
        ; numero zeri maggiore di 1: (nil)
        ((!= '(1) (count '(0) (list a b c d))) (list nil))
        ; numero zeri uguale a 1: calcolo proporzione...
        ((= a 0) (div (mul b c) d))
        ((= b 0) (div (mul a d) c))
        ((= c 0) (div (mul a d) b))
        ((= d 0) (div (mul b c) a))))

;; @syntax (correlation a b)
;; @description Calculate correlation coefficient between two lists of numbers
;; @param <a,b> lists of numbers with equal length. (length a) is default.
;; @return correlation coefficient (float)
;; @example
;; (correlation '(15 18 21 24 27) '(25 25 27 31 32))  --> 0.9534625892455922
;; (correlation '(43.2 21.4 25.6) '(99.1 6.5 7.9))    --> 0.985688381203512
(define (correlation a b)
"Calculate correlation coefficient between two lists of numbers"
  (local (sum-a sum-b sum-ab square-sum-a square-sum-b n)
    (set 'sum-a 0 'sum-b 0 'sum-ab 0 'square-sum-a 0 'square-sum-b 0)
    (setq n (length a))
    (for (i 0 (- n 1))
      # sum of elements of array a
      (setq sum-a (add sum-a (a i)))
      # sum of elements of array b
      (setq sum-b (add sum-b (b i)))
      # sum of a[i] * b[i]
      (setq sum-ab (add sum-ab (mul (a i) (b i))))
      # sum of square of array elements
      (setq square-sum-a (add square-sum-a (mul (a i) (a i))))
      (setq square-sum-b (add square-sum-b (mul (b i) (b i)))))
    ; calculates correlation coefficient
    (div (sub (mul n sum-ab) (mul sum-a sum-b))
        (sqrt (mul (sub (mul n square-sum-a) (mul sum-a sum-a))
                    (sub (mul n square-sum-b) (mul sum-b sum-b)))))))

;; @syntax (eval-rpn lst)
;; @description Evaluate a RPN expression
;; @param <lst> RPN expression
;; @return evaluation of RPN expression (float)
;; @example
;; (eval-rpn '(3 4 2 * 1 5 - 2 3 pow pow / +)) ==> 3
;; (setq a 10 b 20)
;; (eval-rpn '(a b + 5 - sqrt)) ==> 5
(define (eval-rpn lst)
"Evaluate a RPN expression"
  (local (_stack _a _b _op _op1 _op2)
    (setq _stack '())
    ; lista operatori con un argomento
    (setq _op1 '(abs sqrt exp sin cos tan asin acos atan))
    ; lista operatori con due argomenti
    (setq _op2 '(+ - * / % add sub mul div mod pow atan2))
    ; Valuto gli elementi della lista (espressione rpn) e
    ; assegno il valore alle variabili
    (setq lst (map (fn (x) (if (not (protected? x)) (eval x) x)) lst))
    ; Per ogni simbolo della lista...
    (dolist (el lst)
      (cond ((number? el)      ; se è un numero...
             (push el _stack)) ; lo metto nella pila
            (true ; altrimenti è un operatore
             (cond ((find el _op1) ;operatore unario
                    (setq _a (pop _stack))    ; prendo numeri dalla pila
                    (setq _op (eval el))     ; calcolo operazione
                    (push (_op _a) _stack))    ; inserisco risultato nella pila
                   ((find el _op2) ;operatore binario
                    (setq _a (pop _stack))    ; prendo numeri dalla pila
                    (setq _b (pop _stack))    ; prendo numeri dalla pila
                    (setq _op (eval el))     ; calcolo operazione
                    (push (_op _b _a) _stack))  ; inserisco risultato nella pila
                   (true (println "error:" el))))))
    ;restituisco il valore in cima alla pila
    (pop _stack)))

;; @syntax (print-table lst fixed)
;; @description Print a matrix m x n as a table
;; @param <lst> matrix (list of list) of integer, float and/or string
;; @param <fixed> true -> column with same width (max)
;; @return nil (print the matrix)
;; @example
;; (print-table '((1 2 "pippo") ("paperino" "pluto" -98784749) (-1000 -100000 "tre")))  ==>
;; +----------+---------+-----------+
;; | 1        | 2       | pippo     |
;; +----------+---------+-----------+
;; | paperino | pluto   | -98784749 |
;; +----------+---------+-----------+
;; | -1000    | -100000 | tre       |
;; +----------+---------+-----------+
;; (print-table '((1) (-2) (pippo)))
;; +-------+
;; | 1     |
;; +-------+
;; | -2    |
;; +-------+
;; | pippo |
;; +-------+
(define (print-table lst fixed)
"Print a matrix (list of lists) as a table"
  (local (tab plus minus ver rows cols col-len-max len-max
          line-len line ind)
    ; conversione di tutti i valori della lista in stringa
    (setq tab (map-all string lst))
    ; caratteri grafici
    (setq plus "+")
    (setq minus "-")
    (setq ver "|")
    ; calcolo righe e colonne della lista
    (setq rows (length tab))
    (setq cols (length (tab 0)))
    ; vettore per le lunghezze massime dei valori di ogni colonna
    (setq col-len-max (array cols '(0)))
    ; calcola la lunghezza massima dei valori di ogni colonna
    (for (c 0 (- cols 1))
      (setq len-max 0)
      (for (r 0 (- rows 1))
        (setf len-max (max len-max (length (tab r c)))))
      (setf (col-len-max c) len-max))
    ; column with same width (max)
    (if fixed
        (let (cmax (apply max col-len-max))
          (setq col-len-max (array-list (array (length col-len-max) (list cmax))))))
    ;(println col-len-max)
    ; lunghezza della linea =
    ; (somma delle lunghezze massime) +
    ; (2 spazi x ogni colonna) +
    ; (colonne + 1 per "|")
    (setq line-len (+ (apply + col-len-max) (* cols 2) (+ cols 1)))
    (setq line (dup minus line-len))
    (setf (line 0) plus)
    (setf (line -1) plus)
    ; calcola i limiti di stampa dei valori
    ; (inserisce "+" nella linea "line")
    (setq ind 1)
    (dolist (c col-len-max)
      (setq ind (+ ind 2 c))
      (setf (line ind) plus)
      (++ ind))
    ; stampa della lista come tabella
    (dolist (r tab)
      (println line)
      (dolist (c r)
        (print ver { } c (dup " " (- (col-len-max $idx) (length c))) { }))
      (println ver))
    (println line)))

;; @syntax (print-matrix matrix border)
;; @description Print a matrix
;; @param <matrix> list or array of integer, float and/or string
;; @param <border> boolean (true -> print border of matrix)
;; @return nil (print the matrix)
;; @example
;; (print-matrix '((10 2 3) (4 5 6) (7 8 9)))
;; 10 2 3
;;  4 5 6
;;  7 8 9
;; (print-matrix '((1234.5 "bb" "ccc") (111 "lungo" "f") ("hh" "kkk" "zzzz")) true)
;; | 1234.5    bb   ccc |
;; |    111 lungo     f |
;; |     hh   kkk  zzzz |
(define (print-matrix matrix border)
"Print a matrix"
  (local (row col lenmax fmtstr)
    ; converto matrice in lista?
    (if (array? matrix) (setq matrix  (array-list matrix)))
    ; righe della matrice
    (setq row (length matrix))
    ; colonne della matrice
    (setq col (length (first matrix)))
    ; valore massimo della lunghezza tra gli elementi (come stringa)
    (setq lenmax (apply max (map length (map string (flat matrix)))))
    ; creo stringa di formattazione
    (setq fmtstr (append "%" (string (+ lenmax 1) "s")))
    ; stampa la matrice
    (for (i 0 (- row 1))
      (if border (print "|"))
      (for (j 0 (- col 1))
        (print (format fmtstr (string (matrix i j)))))
      (if border (println " |") (println)))))

;; @syntax (print-matrix-int matrix)
;; @description Print a matrix of integer
;; @param <matrix> list of lists of integer
;; @return nil (print the matrix)
;; @example
;; (print-matrix-int '((-1 -883 -10) (-100 10 20) (3 4 -3335)))
;;    -1 -883   -10
;;  -100   10    20
;;     3    4 -3335
(define (print-matrix-int matrix)
"Print a matrix of integer"
  (let ( (row (length matrix))
         (col (length (first matrix)))
         (len-cols '()) (fmt "") )
    ; calcola la larghezza di ogni colonna
    ; (in base all'intero più grande/lungo di ogni colonna)
    (setq len-cols (map (fn(col) (apply max (map length (flat col))))
                           (transpose matrix)))
    ; ciclo per ogni numero intero della matrice...
    (for (i 0 (- row 1))
      (for (j 0 (- col 1))
        ; formattazione dell'intero corrente --> (larghezza-colonna + 2)
        ; (uno spazio ed un eventuale segno -)
        (setq fmt (string "%" (+ (len-cols j) 2) "d"))
        ; stampa dell'intero corrente
        (print (format fmt (matrix i j))))
      (println))))

;; @syntax (print-matrix-chars matrix space)
;; @description Print a matrix of chars
;; @param <matrix> list of lists of chars
;; @return nil (print the matrix)
;; @example
;; (setq m '(("╔" "═" "╦" "═" "╗")
;;           ("║" "a" "║" "b" "║")
;;           ("╚" "═" "╩" "═" "╝")))
;; (print-matrix-chars m)
;; ╔═╦═╗
;; ║a║b║
;; ╚═╩═╝
;; (print-matrix-chars m 1)
;; ╔ ═ ╦ ═ ╗
;; ║ a ║ b ║
;; ╚ ═ ╩ ═ ╝
(define (print-matrix-chars matrix space)
"Print a matrix of chars"
  (local (rows cols)
    (setq space (or space 0))
    (setq rows (length matrix))
    (setq cols (length (matrix 0)))
    (for (r 0 (- rows 1))
      (for (c 0 (- cols 1))
        (print (matrix r c) (dup " " space)))
      (println))))

;; @syntax (print-grid grid ch0 ch1 coord)
;; @description Print a matrix with only digits (0..9)
;; @param <grid> list of lists of digits
;; @param <ch0> char for 0
;; @param <ch1> char for 1
;; @param coord boolean (print coords if true)
;; @return nil (print the grid)
;; @example
;; (setq m '((1 0 1) (1 1 1) (2 0 0)))
;; (print-grid m "" "")
;;  1 0 1
;;  1 1 1
;;  2 0 0
;; (print-grid m "" "" true)
;;    0 1 2
;;  0 1 0 1
;;  1 1 1 1
;;  2 2 0 0
;; (print-grid m " 0" " 1")
;;  1 0 1
;;  1 1 1
;;  2 0 0
;; (print-grid m " 0" " 1" true)
;;    0 1 2
;;  0 1 0 1
;;  1 1 1 1
;;  2 2 0 0
;; (print-grid m " A" " B" true)
;;    0 1 2
;;  0 B A B
;;  1 B B B
;;  2 2 A A
;; (print-grid m " #" " 1" true)
;;    0 1 2
;;  0 1 # 1
;;  1 1 1 1
;;  2 2 # #
;; (print-grid m " 0" " $" true)
;;    0 1 2
;;  0 $ 0 $
;;  1 $ $ $
;;  2 2 0 0
(define (print-grid grid ch0 ch1 coord)
"Print a matrix with only digits (0..9)"
  (local (row col)
    (setq row (length grid))
    (setq col (length (first grid)))
    ; indici di colonna della griglia
    (if coord
        (println "  " (join (map (fn(x) (format "%2d" x)) (sequence 0 (- col 1))))))
    (for (i 0 (- row 1))
      ; indice di riga della griglia
      (if coord (print (format "%2d" i)))
      ; stampa della griglia
      (for (j 0 (- col 1))
        (if (and (!= ch0 "") (!= ch1 ""))
            (begin
              (cond ((= (grid i j) 0) (print ch0))
                    ((= (grid i j) 1) (print ch1))
                    (true
                      (print (format "%2d" (grid i j))))))
            ;else
            (print (format "%2d" (grid i j)))))
      (println))))

;; @description Generate an identity matrix
;; @param <dim> dimension of the matrix
;; @return list of lists
;; @example
;; (matrix-eye 3)  ==> ((1 0 0) (0 1 0) (0 0 1))
(define (matrix-eye dim)
"Generate an identity matrix"
  (let (eye (array-list (array dim dim '(0))))
    (dotimes (i dim) (setf (eye i i) 1))
    eye))

;; @description Calculate the trace of a matrix (sum of diagonal elements)
;; @param <matrix> list of lists of numbers
;; @return list of lists
;; @example
;; (matrix-trace '((1 2 3) (4 5 6) (7 8 9)))  ==> 15
(define (matrix-trace matrix)
"Calculate the trace of a matrix (sum of diagonal elements)"
  (let ((rows (length matrix)) (sum 0))
    (dotimes (r rows) (inc sum (matrix r r)))
    sum))

;; @description "Calculate the characteristic polynomial of a matrix: p(λ) = λ^n + c1·λ^(n-1) + ... + cn (Faddeev-LeVerrier)"
;; @param <matrix> list of lists of numbers
;; @return (c1 c2 ... cn) list of floats
;; @example
;; (matrix-poly '((1 2) (3 4)))  ==> (1 -5 -2)
;; (matrix-poly '((2 1 0)(1 3 1)(0 1 2)))  ==> (1 -7 14 -8)  ; autovalori 1, 2, 4
(define (matrix-poly matrix)
"Calculate the characteristic polynomial of a matrix: p(λ) = λ^n + c1·λ^(n-1) + ... + cn (Faddeev-LeVerrier)"
  (letn ((n (length matrix))
         (M (matrix-eye n))   ; M(k), parte da identità
         (coeffs (list 1))    ; c[0] = 1 (coefficiente di λ^n)
         (ck 0)               ; coefficiente corrente
         (I M))               ; matrice identità
    (dotimes (k n)
      ; M(k+1) = A * M(k) - c(k) * I   (con M(1) = A)
      (setf M (multiply matrix M))
      ; c(k+1) = -tr(M(k+1)) / (k+1)
      ;(setf ck (div (mul -1 (matrix-trace M)) (+ k 1)))
      (setf ck (div (matrix-trace M) (- (+ k 1))))
      (push ck coeffs -1)
      ; aggiorna M togliendo il termine scalare prima della prossima iter.
      (setf M (mat - M (mat * I (mul -1 ck)))))
    coeffs))

;; @syntax (sort-rows matrix type)
;; @description Sort the rows of a matrix
;; @param <matrix> list or array of integer, float and/or string
;; @param <type> order type (>= or <=)
;; @return matrix
;; @example
;; (print-matrix (setq m1 '((1 2 3) (4 5 6) (7 8 9))))
;; ==> 1 2 3
;; ==> 4 5 6
;; ==> 7 8 9
;; (print-matrix (sort-rows m1 >=))
;; ==> 3 2 1
;; ==> 6 5 4
;; ==> 9 8 7
;; (print-matrix (setq m2 '((9 8 7) (6 5 4) (3 2 1))))
;; ==> 9 8 7
;; ==> 6 5 4
;; ==> 3 2 1
;; (print-matrix (sort-rows m2 <=))
;; ==> 7 8 9
;; ==> 4 5 6
;; ==> 1 2 3
(define (sort-rows matrix type)
"Sort the rows of a matrix"
  (map (fn(x) (sort x type)) matrix))

;; @syntax (sort-colums matrix type)
;; @description Sort the colums of a matrix
;; @param <matrix> list or array of integer, float and/or string
;; @param <type> order type (>= or <=)
;; @return matrix
;; @example
;; (print-matrix (sort-columns (setq m1 '((1 2 3) (4 5 6) (7 8 9))) >=))
;; ==> 7 8 9
;; ==> 4 5 6
;; ==> 1 2 3
;; (print-matrix (sort-columns (setq m2 '((9 8 7) (6 5 4) (3 2 1))) <=))
;; ==> 3 2 1
;; ==> 6 5 4
;; ==> 9 8 7
(define (sort-columns matrix type)
"Sort the colums of a matrix"
  (transpose (map (fn(x) (sort x type)) (transpose matrix))))

;; @syntax (random-binary-matrix rows cols k)
;; @description Generate a random binary matrix (rows x cols) (optional: with k cells at 1)
;; @param <rows> number of rows (integer)
;; @param <cols> number of cols (integer)
;; @param <k> number of cells at 1 (integer)
;; @return binary matrix (list of lists)
;; @example
;; (random-binary-matrix 4 4)     ==> ((0 1 1 1) (1 0 0 0) (1 1 0 0) (1 0 0 0))
;; (random-binary-matrix 5 5 10)  ==> ((0 0 0 0 1) (0 0 1 0 1) (0 0 0 0 1) (0 0 1 1 1) (0 0 1 1 1))
;; (random-binary-matrix 3 3 0)   ==> ((0 0 0) (0 0 0) (0 0 0))
;; (random-binary-matrix 3 3 10)  ==> nil
;; (random-binary-matrix 3 3 9)   ==> ((1 1 1) (1 1 1) (1 1 1))
(define (random-binary-matrix rows cols k)
"Generate a random binary matrix (rows x cols) (optional: with k cells at 1)"
  (let ( (matrix '())
         (posizioni '())
         (tot (* rows cols))
         (p 0) (r 0) (c 0) )
    (cond ((nil? k) ; matrice random binaria
            (array-list (array rows cols (rand 2 tot))))
          ((> k tot) nil) ; (celle a 1) > celle --> impossibile
          (true ; matrice random binaria con k celle a 1
            (setq matrix (array-list (array rows cols '(0))))
            ; posizioni random degli 1
            (setq posizioni (slice (randomize (sequence 0 (- tot 1))) 0 k))
            ; Inserimento degli 1 (k)
            (dolist (p posizioni)
              ; indicizzazione lineare
              (setq r (/ p cols)) ; indice riga
              (setq c (% p cols)) ; indice colonna
              (setf (matrix r c) 1))
            matrix))))

;; @syntax (minor-matrix matrix row col)
;; @description Remove a row and a column from a matrix
;; @param <matrix> list or array of integer, float and/or string
;; @param <row> index of row to remove
;; @param <col> index of column to remove
;; @return matrix
;; @example
;; (setq m1 '((1 2 3) (4 5 6) (7 8 9) (10 11 12) (13 14 15)))
;; ==>  1  2  3
;; ==>  4  5  6
;; ==>  7  8  9
;; ==> 10 11 12
;; ==> 13 14 15
;; (minor-matrix m1 0 0)
;; ==>  5  6
;; ==>  8  9
;; ==> 11 12
;; ==> 14 15
;; (minor-matrix m1 1 1)
;; ==>  1  3
;; ==>  7  9
;; ==> 10 12
;; ==> 13 15
;; (minor-matrix m1 1 2)
;; ==>  1  2
;; ==>  7  8
;; ==> 10 11
;; ==> 13 14
;; (minor-matrix m1 4 0)
;; ==>  2  3
;; ==>  5  6
;; ==>  8  9
;; ==> 11 12
(define (minor-matrix matrix row col)
"Remove a row and a column from a matrix"
  (pop matrix row)
  (setq matrix (transpose matrix))
  (pop matrix col)
  (transpose matrix))

;; @syntax (extract-matrix matrix ri cj rows cols)
;; @description Extract a submatrix from a matrix
;; @param <matrix> list or array of integer, float and/or string
;; @param <ri> start row of matrix
;; @param <cj> start column of matrix
;; @param <rows> number of rows to extract
;; @param <cols> number of columns to extract
;; @return matrix
;; @example
;; (setq a '((1 2 3) (4 5 6) (7 8 9)))
;; ==> ((1 2 3)
;; ==>  (4 5 6)
;; ==>  (7 8 9))
;; (extract-matrix a 1 1 1 2)
;; ==> (5 6)
;; (extract-matrix a 0 0 3 1)
;; ==> ((1)
;; ==>  (4)
;; ==>  (7))
;; (extract-matrix a 0 0 3 3)
;; ==> ((1 2 3)
;; ==>  (4 5 6)
;; ==>  (7 8 9))
;; (extract-matrix a 1 1 3 3)
;; ==> ERR: invalid list index in function setf
;; ==> called from user function (extract-matrix a 1 1 3 3)
(define (extract-matrix matrix ri cj rows cols)
"Extract a submatrix from a matrix"
  (local (sub-mat ic jc)
    ; no passing rows, cols then
    ; select all sub-matrix from matrix(ri cj)
    (if (= rows nil) (setq rows (- (length matrix) ri)))
    (if (= cols nil) (setq cols (- (length (matrix 0)) cj)))
    ;; no passing rows, cols and
    ;; if (rows + ri) or (cols + cj) exceed matrix dimension then
    ;; select all sub-matrix from matrix(ri cj)
    ;(if (or (= rows nil) (> (+ rows ri) (length matrix)))
    ;    (setq rows (- (length matrix) ri))
    ;)
    ;(if (or (= cols nil) (> (+ cols ri) (length (matrix 0))))
    ;    (setq cols (- (length (matrix 0)) cj))
    ;)
    ; create the result array (empty)
    (setq sub-mat (array rows cols '(0)))
    ; index for rows of sub-mat
    (setq ic 0)
    (for (rr ri (+ rows ri -1))
      ; index for cols of sub-mat
      (setq jc 0)
      (for (cc cj (+ cols cj -1))
        (setf (sub-mat ic jc) (matrix rr cc))
        (++ jc))
      (++ ic))
    ; restituisce una lista
    (array-list sub-mat)))

;; @syntax (submatrix? sub-mat matrix idx)
;; @description Check if a matrix is a submatrix
;; @param <sub-mat> start row of matrix mat
;; @param <matrix> matrix of integer, float and/or string
;; @param <idx> boolean (true -> return start indexes)
;; @return boolean or list of start indexes
;; @example
;; (setq m '((1 2 3)
;;           (4 5 6)
;;           (7 8 9)))
;; (setq s '((2 3)
;;           (5 6)))
;; (submatrix? s m)       ==> true
;; (submatrix? s m true)  ==> (0 1)
;; (setq s '((1 2 3)
;;           (4 5 6)
;;           (7 8 9)))
;; (submatrix? s m true)  ==> (0 0)
;; (setq s '((1 2 3 4)))
;; (submatrix? s m true)  ==> (nil nil)
;; (submatrix? s m)       ==> nil
;; (setq s '((1) (2) (3) (4)))
;; (submatrix? s m true)  ==> (nil nil)
;; (submatrix? s m)       ==> nil
(define (submatrix? sub-mat matrix idx)
"Check if a matrix is a submatrix"
  (local (out base-row base-col sub-rows sub-cols mat-rows mat-cols
          righe colonne check)
    (setq out nil)
    (setq base-row nil)
    (setq base-col nil)
    (setq sub-rows (length sub-mat))
    (setq sub-cols (length (sub-mat 0)))
    (setq mat-rows (length matrix))
    (setq mat-cols (length (matrix 0)))
    (cond
      ((or (zero? sub-rows) (zero? sub-cols))
        (if idx (list true true) true))
      ((or (zero? mat-rows) (zero? mat-cols))
       (if idx (list nil nil) nil))
      ((or (> sub-rows mat-rows) (> sub-cols mat-cols))
        (if idx (list nil nil) nil))
      (true
        (setq righe (- mat-rows sub-rows))
        (setq colonne (- mat-cols sub-cols))
        (for (r 0 righe 1 out)
          (for (c 0 colonne 1 out)
            (setq check nil)
            (for (i 0 (- sub-rows 1) 1 check)
              (for (j 0 (- sub-cols 1) 1 check)
                (if (!= (sub-mat i j) (matrix (+ r i) (+ c j))) (setq check true))))
            (if (not check) (set 'out true 'base-row r 'base-col c))))
        (if idx (list base-row base-col) out)))))

;; @syntax (merge-matrix A B position)
;; @description Merge two matrix
;; @param <A> list or array of integer, float and/or string
;; @param <B> list or array of integer, float and/or string
;; @param <position> position of B respect to A ("n", "e", "s", "o")
;; @return matrix
;; @example
;; (setq m1 '((1 2 3 4) (5 6 7 8)))
;; ==> ((1 2 3 4)
;; ==>  (5 6 7 8))
;; (setq m2 '((11 22 33 44) (55 66 77 88)))
;; ==> ((11 22 33 44)
;; ==>  (55 66 77 88))
;; (merge-matrix m1 m2 "e")
;; ==> ((1  2  3  4 11 22 33 44)
;; ==>  (5  6  7  8 55 66 77 88))
;; (merge-matrix m1 m2 "o")
;; ==> ((11 22 33 44  1  2  3  4)
;; ==>  (55 66 77 88  5  6  7  8))
;; (merge-matrix m1 m2 "n")
;; ==> ((11 22 33 44)
;; ==>  (55 66 77 88)
;; ==>  ( 1  2  3  4)
;; ==>  ( 5  6  7  8))
;; (merge-matrix m1 m2 "s")
;; ==> (( 1  2  3  4)
;; ==>  ( 5  6  7  8)
;; ==>  (11 22 33 44)
;; ==>  (55 66 77 88))
(define (merge-matrix A B position)
"Merge two matrix"
  (local (out rowsA colsA rowsB colsB)
    (setq out '())
    (setq rowsA (length A))
    (setq colsA (length (A 0)))
    (setq rowsB (length B))
    (setq colsB (length (B 0)))
    (cond ((= position "n") ; B sopra A (nord) con (colsA == colsB)
            (dolist (r B) (push r out -1))
            (dolist (r A) (push r out -1)))
          ((= position "s") ; B sotto A (sud) con (colsA == colsB)
            (dolist (r A) (push r out -1))
            (dolist (r B) (push r out -1)))
          ((= position "e") ; B a destra di A (est) con (rowsA == rowsB)
            (dolist (r A)
              (push (append r (B $idx)) out -1)))
          ((= position "o") ; B a sinistra di A (ovest) con (rowsA == rowsB)
            (dolist (r A)
              (push (append (B $idx) r) out -1))))
    out))

;; @syntax (swap-cols matrix col1 col2)
;; @description Swap the cols of a matrix (all if col1 and col2 are nil)
;; @param <matrix> list or array of integer, float and/or string
;; @param <col1> swap column 1
;; @param <col2> swap column 2
;; @return matrix
;; @example
;; (setq m '((1 2 3 4) (5 6 7 8)))
;; (setq g '((1 2 3) (4 5 6) (7 8 9) (10 11 12)))
;; (swap-cols m)      ==> ((4 3 2 1) (8 7 6 5))
;; (swap-cols m 0 1)  ==> ((2 1 3 4) (6 5 7 8))
;; (swap-cols g)      ==> ((3 2 1) (6 5 4) (9 8 7) (12 11 10))
;; (swap-cols g 0 1)  ==> ((2 1 3) (5 4 6) (8 7 9) (11 10 12))
(define (swap-cols matrix col1 col2)
"Swap the cols of a matrix (all if col1 and col2 are nil)"
  (cond ((!= col2 nil)
          (let (t (transpose matrix))
            (swap (t col1) (t col2))
            (transpose t)))
        (true
          (let ( (rows (length matrix))
                 (cols (length (matrix 0))) )
            (for (r 0 (- rows 1))
              (for (c 0 (- (/ cols 2) 1))
                (swap (matrix r c) (matrix r (- cols c 1)))))
          matrix))))

;; @syntax (swap-rows matrix row1 row2)
;; @description Swap the rows of a matrix (all if row1 and row2 are nil)
;; @param <matrix> list or array of integer, float and/or string
;; @return matrix
;; @example
;; (setq m '((1 2 3 4) (5 6 7 8)))
;; (setq g '((1 2 3) (4 5 6) (7 8 9) (10 11 12)))
;; (swap-rows m)      ==> ((5 6 7 8) (1 2 3 4))
;; (swap-rows m 0 1)  ==> ((5 6 7 8) (1 2 3 4))
;; (swap-rows g)      ==> ((10 11 12) (7 8 9) (4 5 6) (1 2 3))
;; (swap-rows g 0 1)  ==> ((4 5 6) (1 2 3) (7 8 9) (10 11 12))
(define (swap-rows matrix row1 row2)
"Swap the rows of a matrix (all if row1 and row2 are nil)"
  (cond ((!= row2 nil)
          (swap (matrix row1) (matrix row2))
          matrix)
        (true
          (let ( (rows (length matrix))
                 (cols (length (matrix 0))) )
              (for (c 0 (- cols 1))
                (for (r 0 (- (/ rows 2) 1))
                  (swap (matrix r c) (matrix (- rows r 1) c))))
            matrix))))

;; @syntax (adjacent4-matrix row col matrix [rows cols])
;; @description Calculate the values of cells adjacent to a cell in a matrix (4 cells)
;; @param <row> cell row
;; @param <col> cell column
;; @param <matrix> list or array of integer, float and/or string
;; @param <rows> number of rows of matrix (optional)
;; @param <cols> number of column of matrix (optional)
;; @param <type> order type (>= or <=)
;; @return list of values
;; @example
;; (setq m '((1 2 3 4)
;;           (5 6 7 8)
;;           (4 3 2 1)))
;; (adjacent4-matrix 0 0 m) ==> (2 5)
;; (adjacent4-matrix 1 1 m) ==> (2 7 3 5)
;; (adjacent4-matrix 2 3 m) ==> (8 2)
(define (adjacent4-matrix row col matrix rows cols)
"Calculate the values of cells adjacent to a cell in a matrix (4 cells N-E-S-W)"
  (let (out '())
    (setq rows (or rows (length matrix)))
    (setq cols (or cols (length (matrix 0))))
    ; Nord
    (if (>= (- row 1) 0) (push (matrix (- row 1) col) out -1))
    ; Est
    (if (< (+ col 1) cols) (push (matrix row (+ col 1)) out -1))
    ; Sud
    (if (< (+ row 1) rows) (push (matrix (+ row 1) col) out -1))
    ; Ovest
    (if (>= (- col 1) 0) (push (matrix row (- col 1)) out -1))
    out))
;Versione con 'nil' nelle celle impossibili (out of range)
;(adjacent4-matrix 0 0 m)  ==> (nil 2 5 nil)
;(adjacent4-matrix 1 1 m)  ==> (2 7 3 5)
;(adjacent4-matrix 2 3 m)  ==> (8 nil nil 2)
;(define (adjacent4-matrix row col matrix rows cols)
;"Calculate the values of cells adjacent to a cell in a matrix (4 cells N-E-S-W)"
;  (let (out '())
;    (setq rows (or rows (length matrix)))
;    (setq cols (or cols (length (matrix 0))))
;    ; Nord/North
;    (if (>= (- row 1) 0)
;        (push (matrix (- row 1) col) out -1)
;        (push nil out -1))
;    ; Est/East
;    (if (< (+ col 1) cols)
;        (push (matrix row (+ col 1)) out -1)
;        (push nil out -1))
;    ; Sud/South
;    (if (< (+ row 1) rows)
;        (push (matrix (+ row 1) col) out -1)
;        (push nil out -1))
;    ; Ovest/West
;    (if (>= (- col 1) 0)
;        (push (matrix row (- col 1)) out -1)
;        (push nil out -1))
;    out))

;; @syntax (adjacent8-matrix row col matrix [rows cols])
;; @description Calculate the values of cells adjacent to a cell in a matrix (8 cells N)
;; @param <row> cell row
;; @param <col> cell column
;; @param <matrix> list or array of integer, float and/or string
;; @param <rows> number of rows of matrix (optional)
;; @param <cols> number of column of matrix (optional)
;; @param <type> order type (>= or <=)
;; @return list of values
;; @example
;; (setq m '((1 2 3 4)
;;           (5 6 7 8)
;;           (4 3 2 1)))
;; (adjacent8-matrix 0 0 m) ==> (2 6 5)
;; (adjacent8-matrix 1 1 m) ==> (2 3 7 2 3 4 5 1)
;; (adjacent8-matrix 2 3 m) ==> (8 2 7)
(define (adjacent8-matrix row col matrix rows cols)
"Calculate the values of cells adjacent to a cell in a matrix (8 cells N-NE-E-SE-S-SW-W-NW)"
  (let (out '())
    (setq rows (or rows (length matrix)))
    (setq cols (or cols (length (matrix 0))))
    ; Nord
    (if (>= (- row 1) 0) (push (matrix (- row 1) col) out -1))
    ; Nord-Est
    (if (and (>= (- row 1) 0) (< (+ col 1) cols))
        (push (matrix (- row 1) (+ col 1)) out -1))
    ; Est
    (if (< (+ col 1) cols) (push (matrix row (+ col 1)) out -1))
    ; Sud-Est
    (if (and (< (+ row 1) rows) (< (+ col 1) cols))
        (push (matrix (+ row 1) (+ col 1)) out -1))
    ; Sud
    (if (< (+ row 1) rows) (push (matrix (+ row 1) col) out -1))
    ; Sud-Ovest
    (if (and (< (+ row 1) rows) (>= (- col 1) 0))
        (push (matrix (+ row 1) (- col 1)) out -1))
    ; Ovest
    (if (>= (- col 1) 0) (push (matrix row (- col 1)) out -1))
    ; Nord-Ovest
    (if (and (>= (- row 1) 0) (>= (- col 1) 0))
        (push (matrix (- row 1) (- col 1)) out -1))
    out))

;; @syntax (pad-matrix matrix numpad val)
;; @description Insert and fills numpad rows and columns around a matrix m x n with a number or char or string
;; @param <matrix> list or array of integer, float and/or string
;; @param <numpad> number of rows/column to add
;; @param <val> number, char or string used to pad
;; @return matrix
;; @example
;;(print-matrix (pad-matrix '((1.1 2 3) (-4 "s" 6) (7 abc 9)) 2 "0"))
;; 0   0   0   0   0   0   0
;; 0   0   0   0   0   0   0
;; 0   0 1.1   2   3   0   0
;; 0   0  -4   s   6   0   0
;; 0   0   7 abc   9   0   0
;; 0   0   0   0   0   0   0
;; 0   0   0   0   0   0   0
(define (pad-matrix matrix numpad val)
"Insert and fills numpad rows and columns around a matrix m x n with a number or char or string"
  (local (row col out)
    (setq out '())
    ; converte la matrice in lista?
    (if (array? matrix) (setq matrix (array-list matrix)))
    ; righe della nuova matrice
    (setq row (+ (* 2 numpad) (length matrix)))
    ; colonne della nuova matrice
    (setq col (+ (* 2 numpad) (length (matrix 0))))
    ; aggiunge numpad righe iniziali ad out
    (for (i 1 numpad)
      (push (dup val col true) out -1))
    ; aggiunge le righe centrali ad out
    (dolist (el matrix)
      (setq cur (append (dup val numpad true) el (dup val numpad true)))
      (push cur out -1))
    ; aggiunge numpad righe finali ad out
    (for (i 1 numpad)
      (push (dup val col true) out -1))
    out))

;; @syntax (unpad-matrix matrix numpad val)
;; @description Remove numpad rows and columns around a matrix m x n
;; @param <matrix> list or array of integer, float and/or string
;; @param <numpad> number of rows/column to remove
;; @return matrix
;; @example
;;(setq m '((0   0   0   0   0   0   0)
;;          (0   0   0   0   0   0   0)
;;          (0   0 1.1   2   3   0   0)
;;          (0   0  -4   s   6   0   0)
;;          (0   0   7 abc   9   0   0)
;;          (0   0   0   0   0   0   0)
;;          (0   0   0   0   0   0   0)))
;;(print-matrix (unpad-matrix m 2))
;; 1.1   2   3
;;  -4   s   6
;;   7 abc   9
;;(print-matrix (unpad-matrix '((1.1 2 3) (-4 "s" 6) (7 abc 9)) 1))
;; s
;;(setq m '((0   0   0   0   0   0   0)
;;          (0   0   0   0   0   0   0)
;;          (0   0 1.1   2   3   0   0)
;;          (0   0  -4   s   6   0   0)
;;          (0   0   7 abc   9   0   0)
;;          (0   0   0   0   0   0   0)))
;;(print-matrix (unpad-matrix m 2))
;; 1.1   2   3
;;  -4   s   6
(define (unpad-matrix matrix numpad)
"Remove numpad rows and columns around a matrix m x n"
  (local (rows cols out)
    (setq out '())
    ; converte la matrice in lista?
    (if (array? matrix) (setq matrix (array-list matrix)))
    (setq rows (length matrix))
    (setq cols (length (matrix 0)))
    (for (i numpad (- rows numpad 1))
      (push (slice (matrix i) numpad (- numpad)) out -1))
    out))

;; @syntax (plot-xy lst-xy width height)
;; @description Plot a list of points on terminal
;; @param <lst-xy> list of points ((x1 y1)...(xn yn))
;; @param <width> width of plot (number of chars)
;; @param <height> height of plot (number of chars)
;; @return nil
;; @example
;; (setq pts '((1 3) (4 4) (-5 6) (2 -2) (5 6) (-2 -3) (-1 -1)))
;; (plot-xy pts 20 12)  ==>
;; x: -5.000       5.000
;; y: -3.000       6.000
;;            ·
;;  ■         ·         ■
;;            ·
;;            ·
;;            ·       ■
;;            · ■
;;            ·
;;            ·
;;            ·
;;  ··········●···········
;;          ■ ·
;;            ·
;;            ·   ■
;;        ■   ·
(define (plot-xy lst-xy width height)
"Plot a list of points on terminal"
  (local (lst-x lst-y x-min x-max y-min y-max
          range-x range-y xx yy zero-x zero-y matrix)
    ; crea lista delle x
    (setq lst-x (map first lst-xy))
    ; crea lista delle y
    (setq lst-y (map last  lst-xy))
    ; calcola valori min,max x
    (setq x-min (apply min lst-x))
    (setq x-max (apply max lst-x))
    ; calcola valori min,max x
    (setq y-min (apply min lst-y))
    (setq y-max (apply max lst-y))
    ; calcolo intervallo valori x
    (setq range-x (sub x-max x-min))
    ; calcolo intervallo valori y
    (setq range-y (sub y-max y-min))
    ; calcolo valori normalizzati lista x
    ; (i valori vengono arrotondati e poi resi interi)
    (setq xx (normal-zero lst-x 0 width))
    (setq xx (map (fn(w) (int (round w))) xx))
    ; estrazione valore dello zero x normalizzato
    (setq zero-x (pop xx))
    ; calcolo valori normalizzati lista y
    (setq yy (normal-zero lst-y 0 height))
    (setq yy (map (fn(w) (int (round w))) yy))
    ; estrazione valore dello zero y normalizzato
    (setq zero-y (pop yy))
    ; Creazione matrice di caratteri di stampa
    ; Matrice = Sistema di coordinate (row col)
    ; x --> colonna della matrice
    ; y --> riga della matrice
    ; Valore cella vuota: " "
    (setq matrix (array (+ height 2) (+ width 2) '(" ")))
    ; Inserisce asse x sulla matrice
    ;(for (i 0 (- (length (matrix 0)) 1))
    ;  (setf (matrix zero-y i) "·")
    ;)
    ; asse x nella matrice
    (if (and (>= zero-y 0) (< zero-y (+ height 2)))
        (for (i 0 (- (length (matrix 0)) 1))
          (setf (matrix zero-y i) "·")))
    ; Inserisce asse y sulla matrice (se visibile)
    ; asse y nella matrice
    (if (and (>= zero-x 0) (< zero-x (+ width 2)))
        (for (i 0 (- (length matrix) 1))
          (setf (matrix i zero-x) "·")))
    ; Inserisce punti (x y) nella matrice (se visibile)
    ; (inserisce "■" nelle celle (y x) della matrice)
    (for (i 0 (- (length xx) 1))
      (setf (matrix (yy i) (xx i)) "■"))
    ; Inserisce origine degli assi (0 0) nella matrice (se visibile)
    ; (0,0) nella matrice
    (if (and (>= zero-x 0) (>= zero-y 0)
             (< zero-x (+ width 2)) (< zero-y (+ height 2)))
        (if (= (matrix zero-y zero-x) "■")
            (setf (matrix zero-y zero-x) "O")
            (setf (matrix zero-y zero-x) "∙")))
    ; stampa valori reali min e max
    (println (format "x: %-12.3f %-12.3f" x-min x-max))
    (println (format "y: %-12.3f %-12.3f" y-min y-max))
    ; stampa matrice di caratteri
    ; (le righe della matrice vengono invertite)
    (dolist (el (reverse (array-list matrix)))
      (println " " (join el)))
    nil))
; auxiliary function
(define (normal-zero lst-num val-min val-max)
  (local (hi lo k out)
    (setq out '())
    (setq hi (apply max lst-num))
    (setq lo (apply min lst-num))
    (setq k (div (sub val-max val-min) (sub hi lo)))
    (dolist (val lst-num)
      (push (add val-min (mul (sub val lo) k)) out -1))
    ; Zero (0) value in normalized list
    (push (add val-min (mul (sub 0 lo) k)) out)
    out))

;; @syntax (func-xy func x-min x-max step)
;; @description Create a list of points of a function y=f(x)
;; @param <func> functions y=f(x)
;; @param <x-min> x starting value
;; @param <x-max> x ending value
;; @param <step> increment of x
;; @return list of points ((x1 y1)...(xn yn))
;; @example
;; (func-xy sin -1 1 0.5) ==> ((-1 -0.841470984) (-0.5 -0.479425538) (0 0) (0.5 0.479425538) (1 0.841470984))
;; (func-xy log -1 1 0.5) ==> ((-1 1.#QNAN) (-0.5 1.#QNAN) (0 -1.#INF) (0.5 -0.6931471805599453) (1 0))
(define (func-xy func x-min x-max step)
"Create a list of points of a function y=f(x)"
  (let (pts '())
    (for (i x-min x-max step)
      (push (list i (func i)) pts -1))))

;; @syntax (histogram lst hmax)
;; @description Print the histogram of a list of integer numbers
;; @param <lst> list of integer numbers (values)
;; @param <h-max> max height of histogram's bar
;; @return print histogram
;; @example
;; (histogram '(3 3 3 56 56 56 56 -4 -4 -55 -55 -55) 8)
;; ==> -55 ******    3
;; ==>  -4 ****    2
;; ==>   3 ******    3
;; ==>  56 ********    4
(define (histogram lst hmax)
"Print the histogram of a list of integer numbers"
  (local (valori len-max-val unici ind-val val-ind f-lst hm scala linee fmt)
    ; lista ordinata dei valori unici
    (setq valori (sort (unique lst)))
    ; lunghezza del numero massimo (fmt)
    (setq len-max-val (length (apply max valori)))
    ; calcola quanti numeri diversi ci sono nella lista
    (setq unici (length valori))
    ; lista: (indice valore)
    (setq ind-val (map list (sequence 0 (- unici 1)) valori))
    ; lista: (valore indice)
    (setq val-ind (map list valori (sequence 0 (- unici 1))))
    ; crea la lista delle frequenze
    (setq f-lst (array unici '(0)))
    ; calcolo dei valori delle frequenze
    (dolist (el lst) (++ (f-lst (lookup el val-ind))))
    ; valore massimo delle frequenze
    (setq hm (apply max f-lst))
    ; fattore di scala
    (setq scala (div hm hmax))
    ; calcolo delle lunghezze delle colonne dell'istogramma
    (setq linee (map (fn (x) (round (div x scala))) f-lst))
    ; stampa dell'istogramma (orizzontale)
    (dolist (el linee)
      (setq fmt (string "%" (+ len-max-val 1) "d %s %4d"))
      (println (format fmt (lookup $idx ind-val) (dup "*" el) (f-lst $idx))))
    '>))

;; @syntax (line-fit lst [func])
;; @description Calculate the coefficients of linear regression of a list of points
;; @param <lst> list of points (x y)
;; @param [func] if true then return the function of regression line otherwise return the coefficients of regression line (y = a*x + b)
;; @return function or list of coefficients (a b)
;; @example
;; (setq points '((10 2.2) (15 4.6) (20 4.2) (25 7.0) (30 6.6) (35 9.2)))
;; (line-fit points)  ==> (0.2502857142857143 0.001904761904756361)
;; (define reg-line (line-fit points true)) ==> (lambda (x) (add (mul 0.2502857142857143 x) 0.001904761904756361))
;; (reg-line 10)  ==> 2.504761904761899
;; (reg-line 15)  ==> 3.75619047619047
(define (line-fit lst func)
"Calculate the coefficients of linear regression of a list of points"
  (local (n x y sx sy sxy sx2 a b)
    (setq n (length lst))
    (set 'sx 0 'sy 0 'sxy 0 'sx2 0)
    (setq x (map first lst))
    (setq y (map last lst))
    (for (i 0 (- n 1))
      (setq sx (add sx (x i)))
      (setq sy (add sy (y i)))
      (setq sxy (add sxy (mul (x i) (y i))))
      (setq sx2 (add sx2 (mul (x i) (x i)))))
    (setq den (sub (mul n sx2) (mul sx sx)))
    (setq a (div (sub (mul n sxy) (mul sx sy)) den))
    (setq b (div (sub (mul sy sx2) (mul sxy sx)) den))
    (if func ; if func = true
      ; return a function
      (let (f (string "(lambda (x) (add (mul " a " x) " b "))"))
           (eval-string f))
      ; else: return a and b
      (list a b))))

;; @syntax (poly-fit lst order)
;; @description Calculate the coefficients of polynomial regression of a list of points
;; @param <lst> list of points (x y)
;; @param <order> order of polynomial
;; @return list of coefficients of the polynomial
;; @example
;; (setq points '((0 1.00762) (5 1.00392) (10 1.00153) (15 1) (20 0.99907)
;;               (25 0.99852) (30 0.99826) (35 0.99818) (40 0.99828)
;;               (45 0.99849) (50 0.99878) (55 0.99919) (60 0.99967)
;;               (65 1.00024) (70 1.00091) (75 1.00167) (80 1.00253)
;;               (85 1.00351) (90 1.00461) (95 1.00586) (100 1.00721)))
;; g(x) = a0 + a1*x + a2*x^2 + a3*x^4
;; (poly-fit points 3)  ==> (1.00644556747601 -0.0004985711478970345 8.453810415389021e-006 -3.453389732580245e-008)
(define (poly-fit points order)
"Calculate the coefficients of polynomial regression of a list of points"
  (local (n m a b x y k)
    (setq n (length points))
    (setq m order)
    ; matrice del sistema
    (setq a (array (+ m 1) (+ m 1) '(0)))
    ; vettore termini noti
    (setq b (array (+ m 1) '(0)))
    (setq x (map first points))
    (setq y (map last points))
    (for (ir 0 m)
      (for (ic 0 m)
        (setq k (+ ir ic))
        (for (i 0 (- n 1))
          (setf (a ir ic) (add (a ir ic) (pow (x i) k)))))
      (for (i 0 (- n 1))
        (setf (b ir) (add (b ir) (mul (y i) (pow (x i) ir))))))
    ; calcola i coefficienti del polinomio di regressione
    ; risolvendo il sistema lineare
    (sislin-g a b)))

;; @syntax (sigmoid x)
;; @description Calculate the value of sigmoid (logistic) function at x
;; @param <x> floating number
;; @return value of sigmoid at x
;; @example
;; (sigmoid 0.5)  ==> 0.6224593312018546
;; (sigmoid 0)    ==> 0.5
(define (sigmoid x)
"Calculate the value of sigmoid (logistic) function at x"
  (div (add 1 (exp (sub x)))))

;; @syntax (same-digit? num)
;; @description Check if an integer has all digits equal
;; @param <num> integer
;; @return true or nil
;; @example
;; (same-digit? 2333)   ==> nil
;; (same-digit? 111)    ==> true
;; (same-digit? -3333)  ==> true
(define (same-digit? num)
"Check if an integer has all digits equal"
  (= num (* (div (- (pow 10 (length num)) 1) 9) (% num 10))))

;; @syntax (different-digits? num)
;; @description Check if an integer has all digits different
;; @param <num> integer
;; @return true or nil
;; @example
;; (different-digits? 2333)  ==> nil
;; (different-digits? 123)   ==> true
;; (different-digits? 3333)  ==> nil
;; (different-digits? -369)  ==> true
(define (different-digits? num)
"Check if an integer has all digits different"
  (let ( (digit-seen (array 10 '(nil)))
         (different true) (digit nil) )
    (setq num (abs num))
    (while (and (> num 0) different)
        (setq digit (% num 10))
        (if (digit-seen digit)
            (setq different nil)
            (setf (digit-seen digit) true))
      (setq num (/ num 10)))
    different))

;; @syntax (same-digits? num1 num2)
;; @description Check if two numbers have the same digits
;; @param <num1> non-negative integer
;; @return integer
;; @example
;; (same-digits? -12 -21)   ==> true
;; (same-digits? 123 231)   ==> true
;; (same-digits? 123 2314)  ==> nil
(define (same-digits? num1 num2)
"Check if two numbers have the same digits"
  (= (sort (explode (string num1))) (sort (explode (string num2)))))

;; @syntax (reverse-digits num)
;; @description Reverse the digits of an integer
;; @param <num> integer (base 10) or integer-string
;; @return integer
;; @example
;; (reverse-digits 1234)   --> 4321
;; (reverse-digits "789")  --> 987
;; (reverse-digits 10)     --> 1
;; (reverse-digits 2)      --> 2
(define (reverse-digits num)
"Reverse the digits of an integer"
  (int (reverse (string num)) 0 10))

;; @syntax (reverse-digits-big num)
;; @description Reverse the digits of an integer or big-integer
;; @param <num> integer or big-integer or integer-string or big-integer-string
;; @return integer or big-integer
;; @example
;; (reverse-digits-big 2)   ==> 2
;; (reverse-digits-big 2L)  ==> 2L
;; (reverse-digits-big 100000000000000000000000000000)   ==> 1L
;; (reverse-digits-big 100000000000000000000000000000L)  ==> 1L
;; (reverse-digits-big 1234567890)   ==> 987654321
;; (reverse-digits-big 1234567890L)  ==> 987654321L
(define (reverse-digits-big num)
"Reverse the digits of an integer or big-integer"
  (if (zero? num) 0
  ;else
    (begin
    ; converte 'num' in stringa e lo inverte
    (setq num (reverse (string num)))
    ; se 'num' è big-integer, allora sposta la "L" dall'inizio alla fine
    (when (= (num 0) "L") (pop num) (push "L" num -1))
    ; rimuove eventuali zeri iniziali
    (while (= (num 0) "0") (pop num))
    ; converte la stringa 'num' in numero intero o big-integer
    (eval-string num))))

;===========================================================================
;===========================================================================
;; <p><b><center>LISTS & STRINGS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (char-int ch)
;; @description Return the ASCII code of an ASCII character
;; @param <ch> ASCII character (string)
;; @return ASCII code (integer) (0-255)
;; @example (char-int "k")  ==> 107
; Use this instead of "char" to override a bug in 10.7.5
(define (char-int ch)
"Return the ASCII code of a character"
  (char ch))

;; @syntax (int-char num)
;; @description Return the ASCII character of an ASCII code
;; @param <num> ASCII code (integer) (0-255)
;; @return ASCII character (string)
;; @example (int-char 107)  ==> "k"
; Use this instead of "char" to override a bug in 10.7.5
(define (int-char num)
"Return the character of an ASCII code (0-255)"
  (char num))

;; @syntax (digit? ch)
;; @description Check if a char is a digit (0..9)
;; @param <ch> char
;; @return true or nil
;; @example
;; (digit? "t")  ==> nil
;; (digit? "4")  ==> true
(define (digit? ch)
"Check if a char is a digit (0..9)"
  (and (>= ch "0") (<= ch "9")))

;; @syntax (lower? ch)
;; @description Check if a char is lowercase (a..z)
;; @param <ch> char
;; @return true or nil
;; @example
;; (lower? "t")  ==> true
;; (lower? "4")  ==> nil
(define (lower? ch)
"Check if a char is lowercase (a..z)"
  (<= "a" ch "z"))

;; @syntax (upper? ch)
;; @description Check if a char is uppercase (A..Z)
;; @param <ch> char
;; @return true or nil
;; @example
;; (upper? "t")  ==> nil
;; (upper? "T")  ==> true
(define (upper? ch)
"Check if a char is uppercase (A..Z)"
  (>= "Z" ch "A"))

;; @syntax (clean-str chars str)
;; @description Clean chars from a string
;; @param <chars> chars to clean on str (string)
;; @param <str> string to clean (string)
;; @return string
;; @example (clean-str ":abc" "a1b2c3:4")  ==> 1234
(define (clean-str chars str)
"Clean chars from a string"
  (join (difference (explode str) (explode chars) true)))

;; @syntax (filter-str chars str)
;; @description Filter chars from a string
;; @param <chars> chars to filter from str (string)
;; @param <str> string to filter (string)
;; @return string
;; @example (filter-str ":abc" "a1b2c3:4")  ==> abc:"
(define (filter-str chars str)
"Filter chars from a string"
  (join (intersect (explode str) (explode chars) true)))

;; @syntax (substring str start end)
;; @description Extract a substring from a string
;; @param <str> input string
;; @param <start> start index (integer)
;; @param <end> end index (integer)
;; @return string (from start to (end - 1))
;; @example
;; (substring "zippo" 0 1)    ==> "z"
;; (substring "zippo" 1 3)    ==> "ip"
;; (substring "zippo" 2)      ==> "ppo"
;; (substring "zippo" 0)      ==> "zippo"
;; (substring "zippo" 0 0)    ==> ""
;; (substring "zippo" -2 2)   ==> "po"
;; (substring "zippo" -5)     ==> "zippo"
;; (substring "zippo" 5 4)    ==> ""
;; (substring "zippo" 10 20)  ==> ""
;(define (substring str start end)
;"Extract a substring from a string"
;  (if (nil? end)
;      (slice str start)
;      (slice str start (- end start))))

;; @syntax (slice-range obj start end)
;; @description Extract a sublist or a substring from a list or a string
;; @param <obj> list or  string
;; @param <start> start index (integer)
;; @param <end> end index (integer)
;; @return list or string (from start to (end - 1))
;; @example
;; (slice-range "zippo" 0 1)       ==> "z"
;; (slice-range "zippo" 1 3)       ==> "ip"
;; (slice-range "zippo" 2)         ==> "ppo"
;; (slice-range "zippo" 0)         ==> "zippo"
;; (slice-range "zippo" 0 0)       ==> ""
;; (slice-range "zippo" -2 2)      ==> "po"
;; (slice-range "zippo" -5)        ==> "zippo"
;; (slice-range "zippo" 5 4)       ==> ""
;; (slice-range "zippo" 10 20)     ==> ""
;; (slice-range '(1 2 3 4 5 6) 2 4)  ==> (2 3)
(define (slice-range str start end)
"Extract a sublist or a substring from a list or a string"
  (if (nil? end)
      (slice str start)
      (slice str start (- end start))))

;; @syntax (left-string str num-chars fill-char)
;; @description Justify a string to the left
;; @param <str> string
;; @param <num-chars> space length
;; @param <fill-char> filling char in space
;; @return string
;; @example
;; (left-string "newLISP" 15)      ==> "newLISP        "
;; (left-string "newLISP" 15 "-")  ==> "newLISP--------"
(define (left-string str num-chars fill-char)
"Justify a string to the left"
  (letn ( (len-str (length str)) (space (- num-chars len-str)) )
    (setq fill-char (or fill-char " "))
    (append str (dup fill-char (- num-chars len-str)))))

;; @syntax (right-string str num-chars fill-char)
;; @description Justify a string to the right
;; @param <str> string
;; @param <num-chars> space length
;; @param <fill-char> filling char in space
;; @return string
;; @example
;; (right-string "newLISP" 15)      ==> "        newLISP"
;; (right-string "newLISP" 15 "+")  ==> "++++++++newLISP"
(define (right-string str num-chars fill-char)
"Justify a string to the right"
  (letn ( (len-str (length str)) (space (- num-chars len-str)) )
    (setq fill-char (or fill-char " "))
    (append (dup fill-char (- num-chars len-str)) str)))

;; @syntax (center-string str num-chars fill-char)
;; @description Justify a string to the center
;; @param <str> string
;; @param <num-chars> space length
;; @param <fill-char> filling char in space
;; @return string
;; @example
;; (center-string "newLISP" 15 " ")  ==> "    newLISP    "
;; (center-string "newLISP" 15)      ==> "    newLISP    "
;; (center-string "newLISP" 15 "-")  ==> "----newLISP----"
;; (center-string "newLISP" 5)       ==> "newLISP"
(define (center-string str num-chars fill-char)
"Justify a string to the center"
  (letn ( (len-str (length str)) (space (- num-chars len-str)) )
    (setq fill-char (or fill-char " "))
    (if (even? space)
      ; centratura pari
      (append (dup fill-char (/ space 2)) str (dup fill-char (/ space 2)))
      ; centratura dispari
      (append (dup fill-char (/ space 2)) str (dup fill-char (+ (/ space 2) 1))))))

;; @syntax (merge-string str1 str2)
;; @description Superposition of one string on another string
;; @param <str1> string
;; @param <str2> string
;; @return string
;; @example
;; (merge-string "pippo" "torta")            ==> "pippo"
;; (merge-string "pippo" "xyz")              ==> "pip"
;; (merge-string "new" "oldLISP")            ==> "newLISP"
;; (merge-string "John" "     Von Neumann")  ==> "John Von Neumann"
(define (merge-string str1 str2)
"Superposition of one string on another string"
  (let ((len1 (length str1)) (len2 (length str2)))
    (cond
      ((= len1 len2) str1)
      ((> len1 len2) (slice str1 0 len2))
      ((< len1 len2)
        (string str1 (slice str2 len1))))))

;; @syntax (sublist? lst1 lst2 all)
;; @description Check if all elements of a list (lst1) are in another list (lst2)
;; @param <lst1> first list of elements
;; @param <lst2> second list of elements
;; @param <all> true -> correspondence between elements 1:1
;; @return boolean (true or nil)
;; @example
;; (sublist? '(1 1 2 2 3 3) '(1 2 3))       ==> true
;; (sublist? '(1 1 2 2 3 3) '(1 2 3) true)  ==> nil
;; (sublist? '(1 1 2 2 3 3) '(1 2 3 4))     ==> nil
;; (sublist? '(1 2 3) '(1 1 2 2 3 3))       ==> true
;; (sublist? '(1 2 3) '(1 1 2 2 3 3) true)  ==> true
;; (sublist? '(1 2 3 4) '(1 1 2 2 3 3))     ==> nil
(define (sublist? lst1 lst2 all)
"Check if all elements of a list (lst1) are in another list (lst2)"
  (if all
    ; check presence of numbers
    (for-all (fn(x) (ref x lst2)) lst1))
    ;else (corrispondece 1:1)
    ; checks presence and occurrence of numbers
    (let ( (pos nil) (stop nil) )
      ; Per ogni numero di lst1...
      (dolist (elem lst1)
        ; se esiste in lst2...
        (if (setq pos (ref elem lst2))
            ; lo elimina da lst2
            (pop lst2 pos)
            ; altrimenti ferma il ciclo e restituisce nil
            (setq stop true)))
      (not stop)))

;; @syntax (intersects)
;; @description Calculate intersection of lists (sets)
;; @param <lst1> first list of elements
;; @param <lstN> n-th list of elements
;; @return lists intersection (intersect (intersect lst1 lst2) ... lstN)
;; @example
;; (intersects '(1 2 3) '(1 2) '(2 4))        ==> (2)
;; (apply intersects '((1 2 3) (1 2) (2 4)))  ==> (2)
;; (intersects (sequence 1 10) (sequence 5 15) (sequence 7 12))  ==> (7 8 9 10)
(define (intersects)
"Calculate intersection of lists (sets)"
  (let (base (args 0))
    (for (k 1 (- (length (args)) 1))
      (setq base (intersect base (args k))))))

;; @syntax (shifted? lst1 lst2)
;; @description Check if two lists are rotated with each other
;; @param <lst1> first list of elements
;; @param <lst2> second list of elements
;; @return boolean (true or nil)
;; @example
;; (shifted? '(1 2 3 4 5) '(4 5 1 2 3))  ==> true
;; (shifted? '(1 2 3 4) '(1 2 3))        ==> nil
;; (shifted? '(1 2 3 4) '(5 1 2 3))      ==> nil
(define (shifted? lst1 lst2)
"Check if two lists are rotated with each other"
  (let ((len1 (length lst1))
        (len2 (length lst2)))
    (cond ((!= len1 len2) nil) ; lunghezze diverse?
          ;((!= (difference lst1 lst2) '()) nil) ; elementi con valori diversi?
          (true ; controllo di tutte le rotazioni
            (setq shiftate nil)
            (for (i 0 (- len1 1) 1 shiftate)
              (if (= (rotate (copy lst1) i) lst2) (setq shiftate true)))
            shiftate))))

;; @syntax (remove-items lst items)
;; @description Remove from lst the elements in items (remove 1:1)
;; @param <lst> list of elements
;; @param <items> list of elements
;; @example
;; (remove-items '(A A A B B) '(A B C A))  ==> (A B)
(define (remove-items lst items)
"Remove from lst the elements in items (remove 1:1)"
  ; A differenza di 'difference', ogni elemento viene rimosso una sola volta
  (let (result lst)
    (dolist (item items)
      (let (pos (find item result))
        (if pos
            (pop result pos))))
    result))

;; @syntax (remove elt lst all)
;; @description Remove an element from a list (first or all occurrence)
;; @param <elt> list element (atom or list)
;; @param <lst> list (nested)
;; @param <all> true -> remove all occurrence of elt (otherwise only the first)
;; @return list
;; @example
;; (remove 'a '(a a b c b a b))                       ==> (a b c b a b)
;; (remove 'a '(a a b c b a b) true)                  ==> (b c b b)
;; (remove 'a '((a b) a (a b c) (b (c (a))) a))       ==> ((b) a (a b c) (b (c (a))) a)
;; (remove 'a '((a b) a (a b c) (b (c (a))) a) true)  ==> ((b) (b c) (b (c ())))
;; (replace 'a '((a b) a (a b c) (b (c (a))) a))      ==> ((a b) (a b c) (b (c (a))))
(define (remove elt lst all)
"Remove an element from a list (first or all occurrence)"
  (cond (all
          (while (setq idx (ref elt lst)) (pop lst idx))
          lst)
        (true
          (let ((elt-pos (ref elt lst)))
            (if elt-pos (pop lst elt-pos))
            lst))))

;; @syntax (reverse-part obj idx len)
;; @description Reverse part of list or string
;; @param <obj> list or string
;; @param <idx> index of starting reverse
;; @param <len> number of elements to reverse
;; @return list or string
;; @example
;; (reverse-part "newLISP" 3 3)         ==> "newSILP"
;; (reverse-part "newLISP" 0 3)         ==> "wenLISP"
;; (reverse-part '(a b c d e f g) 2 3)  ==> (a b e d c f g)
;; (reverse-part '(a b c d e f g) 0 2)  ==> (b a c d e f g)
;; (reverse-part '(1 2 3 4 5 6 7) 0 6)  ==> (6 5 4 3 2 1 7)
(define (reverse-part obj idx len)
"Reverse part of list or string"
  (extend (slice obj 0 idx)             ; left part
          (reverse (slice obj idx len)) ; invert part
          (slice obj (+ idx len))))     ; right part

;; @syntax (pairs-ij lst)
;; @description Generate all pairs of elements of a list with (index i < index j)
;; @param <lst> list of elements
;; @return list of pairs
;; @example
;; (pairs-ij '(1 2 3 4 5))  ==> ((1 2) (1 3) (1 4) (1 5) (2 3) (2 4) (2 5) (3 4) (3 5) (4 5))
;; (pairs-ij '(1 2))        ==> ((1 2))
(define (pairs-ij lst)
"Generate all pairs of elements of a list with (index i < index j)"
  (let ( (out '()) (len (length lst)) )
    (for (i 0 (- len 2))
      (for (j (+ i 1) (- len 1))
        (push (list (lst i) (lst j)) out -1)))))

;; @syntax (slice-all obj)
;; @description Generate all the slice of a list or a string
;; @param <obj> list or string
;; @return list of slices
;; @example
;; (slice-all "1234")      ==> ("1" "12" "123" "1234" "2" "23" "234" "3" "34" "4")
;; (slice-all '(1 2 3 4))  ==> ((1) (1 2) (1 2 3) (1 2 3 4) (2) (2 3) (2 3 4) (3) (3 4) (4))
(define (slice-all obj)
"Generate all the slice of a list or a string"
  (let ( (out '()) (len (length obj)) )
    (for (i 0 (- len 1))
      (for (j 1 (- len i))
        (push (slice obj i j) out -1)))
    out))

;; @syntax (trim-leading value lst)
;; @description Removes all initial occurrences of an element in a list
;; @param <value> element value
;; @param <lst> list
;; @return list
;; @example
;; (trim-leading 0 '(0 0 1 0 30 5 2 0 0 0))  ==> (1 0 30 5 2 0 0 0)
(define (trim-leading value lst)
"Removes all initial occurrences of an element in a list"
  (slice lst (find value lst !=)))

;; @syntax (trim-trailing value lst)
;; @description Removes all final occurrences of an element in a list
;; @param <value> element value
;; @param <lst> list
;; @return list
;; @example
;; (trim-trailing 0 '(0 0 1 0 30 5 2 0 0 0))  ==> (0 0 1 0 30 5 2)
(define (trim-trailing value lst)
"Removes all final occurrences of an element in a list"
  (let (rev (reverse lst))
    (reverse (slice rev (find value rev !=)))))

;; @syntax (find-from-end value lst)
;; @description Find an element from the end of a list
;; @param <value> element value
;; @param <lst> list
;; @return index of element (integer) or nil
;; @example
;; (find-from-end 3 '(1 3 7 3 2))  ==> 3
;; (find-from-end 1 '(1 3 7 3 2))  ==> 0
;; (find-from-end 4 '(1 3 7 3 2))  ==> nil
(define (find-from-end value lst)
"Find an element from the end of a list"
  (let (idx (find value (reverse lst)))
    (if idx (- (length lst) 1 idx))))

;; @syntax (find-floor x lst)
;; @description Find in a list the integer closest to x that is less than or equal to x
;; @param <x> integer value
;; @param <lst> list
;; @return integer or nil
;; @example
;; (find-floor 4 '(-2 4 6 8))   ==> 4
;; (find-floor 1 '(-2 4 6 8))   ==> -2
;; (find-floor 9 '(-2 4 6 8))   ==> 8
;; (find-floor -3 '(-2 4 6 8))  ==> nil
(define (find-floor x lst)
"Find in a list the integer closest to x that is less than or equal to x"
  (let ((out nil) (diff 1e8))
    (dolist (el lst)
      (if (and (<= el x) (< (- x el) diff))
          (set 'out el 'diff (- x el))))
    out))

;; @syntax (find-ceil x lst)
;; @description Find in a list the integer gereater to x that is less than or equal to x
;; @param <x> integer value
;; @param <lst> list
;; @return integer or nil
;; @example
;; (find-ceil 4 '(-2 4 6 8))   --> 4
;; (find-ceil 1 '(-2 4 6 8))   --> 4
;; (find-ceil 9 '(-2 4 6 8))   --> nil
;; (find-ceil -3 '(-2 4 6 8))  --> -2
(define (find-ceil x lst)
"Find in a list the integer closest to x that is greater than or equal to x"
  (let ((out nil) (diff 1e8))
    (dolist (el lst)
      (if (and (>= el x) (< (- el x) diff))
          (set 'out el 'diff (- el x))))
    out))

;; @syntax (powerset lst)
;; @description Generate all sublists of a list
;; @param <lst> list
;; @return list of all sublists
;; @example
;; (powerset '())       ==> '(())
;; (powerset '(1))       ==> '((1) ())
;; (powerset '(1 2 3))  ==> ((1 2 3) (1 2) (1 3) (1) (2 3) (2) (3) ())
(define (powerset lst)
"Generate all sublists of a list"
  (if (empty? lst)
      (list '())
      (let ((element (first lst))
            (p (powerset (rest lst))))
         (extend (map (fn (subset) (cons element subset)) p) p))))

;; @syntax (powerset-i lst)
;; @description Generate all sublists of a list (binary mask)
;; @param <lst> list
;; @return list of all sublists
;; @example
;; (powerset-i '())       ==> '(())
;; (powerset-i '(1))      ==> '(() (1))
;; (powerset-i '(1 2 3))  ==> (() (1) (2) (1 2) (3) (1 3) (2 3) (1 2 3))
(define (powerset-i lst)
"Generate all sublists of a list (binary mask)"
  (if (= lst '()) lst
  ;else
      (let ((out '(())) (n (length lst)) (group '()))
        (for (mask 1 (- (<< 1 n) 1))
          (setq group '())
          (for (i 0 (- n 1))
            (if (!= (& mask (<< 1 i))) (push (lst i) group -1)))
          (push group out -1))
        out)))

;; @syntax (sublists-sum-to lst sum)
;; @description Generate all sublists that sum to a given number
;; @param <lst> list of integer
;; @param <sum> sum (positive integer)
;; @return list of list
;; @example
;; (sublists-sum-to '(1 2 3 4) 6)      ==> ((1 2 3) (2 4))
;; (sublists-sum-to '(1 -2 3 -3 6) 4)  ==> ((1 3) (-2 6) (1 -3 6) (-2 3 -3 6))
(define (sublists-sum-to lst sum)
"Generate all sublists that sum to a given number"
  (local (limit val len out)
    (setq out '())
    (setq len (length lst))
    ; numero di subset (2^len)
    (setq limit (<< 1 len))
    (for (i 0 (- limit 1))
      (setq val 0)
      (setq tmp '())
      (setq stop nil)
      (for (j 0 (- len 1) 1 stop)
        ; usa la rappresentazione binaria di "i"
        ; per decidere quali elementi prendere.
        (if (!= (& i (<< 1 j)))
          (begin
            (push (lst j) tmp -1)
            (setq val (+ val (lst j)))
            ; stop se somma del sottoinsieme corrente
            ; supera il valore sum
            (if (> val sum) (setq stop true)))))
      ; controlla se deve aggiungere un sottoinsieme che somma a sum
      (if (= val sum) (push tmp out -1)))
    out))

;; @syntax (assoc+ exp-key alst)
;; @description Search a key in an associative list
;; @param <exp-key> atom or list
;; @param <alst> associative list
;; @return element of alst (key value) or nil
;; @example
;; (setq alst '(((0 1) "a") ("uno" 1) ((3.14) 2)))
;; (assoc+ '(0 1) alst)  ==> ((0 1) "a")
;; (assoc+ "uno" alst)  ==> ("uno" 1)
(define (assoc+ exp-key alst)
"Search a key in an associative list"
  (find (list exp-key '?) alst match) $0)

;; @syntax (lookup+ exp-key alst)
;; @description Search a key in an associative list
;; @param <exp-key> atom or list
;; @param <alst> associative list
;; @return value of element (key value) or nil
;; @example
;; (setq alst '(((0 1) "a") ("uno" 1) ((3.14) 2)))
;; (lookup+ '(0 1) alst)  ==> "a"
;; (lookup+ "uno" alst)  ==> 1
(define (lookup+ exp-key alst)
"Search a key in an associative list"
  (find (list exp-key '?) alst match) ($0 1))

;; @syntax (find-all-ref s str all)
;; @description Find all start indexes of a substring in a string
;; @param <s> substring (string)
;; @param <str> input string (string)
;; @param <all> contiguous index? (boolean)
;; @return start indexes of s in str (list)
;; @example
;; (find-all-ref "abc" "abc-123-abc-123-xyz")  ==> (0 8)
;; (find-all-ref "ss" "ssss")                  ==> (0 2)
;; (find-all-ref "ss" "ssss" true)             ==> (0 1 2)
(define (find-all-ref s str all)
"Find all start indexes of a substring in a string"
  (local (idx incr)
    (setq idx -1)
    (if all (setq incr 0) (setq incr (- (length s) 1)))
    (collect (begin (setq idx (find s str nil (+ idx 1)))
                    (cond (idx (setq idx (+ idx incr)); calcola il nuovo indice
                          (- idx incr))))))); ma ritorna l'indice trovato

;; @syntax (gather lst)
;; @description Gather the elements of list into sublists of identical elements
;; @param <lst> list of elements
;; @return list
;; @example
;; (gather '(a b a d b))  ==> ((a a) (b b) (d))
;; (gather '((1 2) (3 3) (1 2) (3 4) (3 3) (2 3) (1 2)))  ==> (((1 2) (1 2) (1 2)) ((3 3) (3 3)) ((3 4)) ((2 3)))
(define (gather lst)
"Gather the elements of list into sublists of identical elements"
  (let ( (out '())
         (contatore (map list (unique lst) (count (unique lst) lst))) )
  (dolist (el contatore)
    (push (dup (el 0) (el 1) true) out -1))
  out))

;; @syntax (riffle args)
;; @description Create a list that alternates the elements of lists and atoms
;; @param <args> lists and atoms (first object must be a list)
;; @return list
;; @example
;; riffle[(x1 x2 ... xn) (a1 a2 ... an)] -->  (x1 a1 x2 a2 ... xn an)
;; riffle[(x1 x2 x3 x4) (a1 a2)] -->  (x1 a1 x2 a2 x3 x4)
;; riffle[(x1 x2) (a1 a2 a3 a4)] -->  (x1 a1 x2 a2)
;; riffle[(x1 x2 ... xn) k] --> (x1 k x2 k ... xn k)
;; (riffle '(1 a) '(2 b))  ==> (1 2 a b)
;; (riffle '(1 a) '(2 b) '(3 c))  ==> (1 2 3 a b c)
;; (riffle '(1 2) 'a)  ==> (1 a 2 a)
;; (riffle '(1 2) 'a '(3 4))  ==> (1 a 3 2 a 4)
;; (riffle '(1 2) '(3 4 5) '(6 7 8 9))  ==> (1 3 6 2 4 7)
;; (riffle '(1 2) '(3 4 5) '(6 7 8 9) 'a)  ==> (1 3 6 a 2 4 7 a)
;; (riffle '(1 2) 'a '(3 4 5) '(6 7 8 9))  ==> (1 a 3 6 2 a 4 7)
;; (riffle '(1 2) 'a 'b 'c)  ==> (1 a b c 2 a b c)
(define (riffle)
"Create a list that alternates the elements of lists and atoms"
  (flat (transpose (args))))

;; @syntax (regex-all regexp str all)
;; @description Find all occurrences of a regex in a string
;; @param <regex> regular expression
;; @param <str> input string (string)
;; @param <all> contiguous index? (boolean)
;; @return all occurrences of regex (list of list)
;; @example
;; (setq a "AAAaBBcADccAAAA")
;; (regex-all "[A]{3}" a true)             ==> (("AAA" 0 3) ("AAA" 11 3) ("AAA" 12 3))
;; (regex-all "[A]{3}" a)                  ==> (("AAA" 0 3) ("AAA" 11 3))
;; (regex-all "(?<!A)[A]{3}(?!A)" a true)  ==> (("AAA" 0 3))
;; (regex-all "(?<!A)[A]{3}(?!A)" a)       ==> (("AAA" 0 3))
(define (regex-all regexp str all)
"Find all occurrences of a regex in a string"
  (local (out idx res)
    (setq out '())
    (setq idx 0)
    (setq res (regex regexp str 64 idx))
    (while res
      (push res out -1)
      (if all
          (setq idx (+ (res 1) 1)) ; contiguos pattern (overlap)
          ;else
          (setq idx (+ (res 1) (res 2)))) ; no contiguos pattern
      (setq res (regex regexp str 64 idx)))
    out))
; Alternative version (by rrq)
;(define (regex-all EXPR STR OPT ALL)
;  (let ((i 0)
;        (move-i (fn (X) (setq i (+ (X 1) (if ALL 1 (X -1)))) X)))
;  (collect (if (regex EXPR STR OPT i) (move-i $it)))))
; (regex-all "[A]{3}" a 0 true)
; (("AAA" 0 3) ("AAA" 11 3) ("AAA" 12 3))

;; @syntax (couples lst all)
;; @description Generate all the couples of a list
;; @param <lst> list of elements
;; @param <all> generate couples with same element too (boolean)
;; @return list of couples (list)
;; @example
;; (couples '(1 2 3 4) true)  ==> ((1 1) (1 2) (1 3) (1 4) (2 2) (2 3) (2 4) (3 3) (3 4) (4 4))
;; (couples '(1 2 3 4))       ==> ((1 2) (1 3) (1 4) (2 3) (2 4) (3 4))
(define (couples lst all)
"Generate all the couples of a list"
  (let (out '())
    (if all
      (for (i 0 (- (length lst) 1))
        (for (j i (- (length lst) 1))
            (push (list (lst i) (lst j)) out -1)))
      ;else
      (for (i 0 (- (length lst) 2))
        (for (j (+ i 1) (- (length lst) 1))
            (push (list (lst i) (lst j)) out -1))))
    out))

;; @syntax (map-all func lst)
;; @description Apply a function to all the elements of annidate list
;; @param <func> list
;; @param <lst> list
;; @return list
;; @example
;; (map-all sqrt '((4 16) (25 49) (36 1 (64)))) ==> ((2 4) (5 7) (6 1 (8)))
(define (map-all func lst)
"Apply a function to all the elements of annidate list"
  (let (result '())
    (dolist (el lst)
      (if (list? el)
        (push (map-all func el) result -1)
        (push (func el) result -1)))
    result))

;; @syntax (rotate-index lst start-idx shift)
;; @description Rotate index in a circular list
;; @param <lst> list
;; @param <start-idx> starting index
;; @param <shift> shift value (+ right, - left) (integer)
;; @return arrival index (integer)
;; @example
;; (rotate-index '(7 -2 9 6) 2 0)   ==> 2
;; (rotate-index '(7 -2 9 6) 1 6)   ==> 3
;; (rotate-index '(7 -2 9 6) 1 -4)  ==> 1
(define (rotate-index lst start-idx shift)
"Rotate index in a circular list"
  (local (len idx)
    (setq len (length lst))
    (setq idx (% (+ start-idx shift) len))
    (when (< idx 0) (++ idx len))
    idx))

;; @syntax (index-list lst)
;; @description Create a list of indexes for all the elements of a list
;; @param <lst> list
;; @return list of indexes
;; @example
;; (index-list '(1 2 3 4 5))                      ==> ((0) (1) (2) (3) (4))
;; (index-list '((1 2) ((2 (3)) (4 4)) (((7)))))  ==> ((0) (0 0) (0 1) (1) (1 0) (1 0 0) (1 0 1) (1 0 1 0)
;; (index-list index-list)                        ==> ((0) (0 0) (1) (2) (2 0) (2 1) (2 2) (2 3) (2 3 0) (2 3 0 0) (2 3 1))
(define (index-list lst)
"Create a list of indexes for all the elements of a list"
  (ref-all nil lst (fn(x) true)))
; OLD VERSION
;(define (index-list lst)
;"Create a list of indexes for all the elements of a list"
;  (local (mylist mv)
;    (setq mylist '())
;    (define (h-index-list lst agg)
;      (dolist (x lst)
;        (setq mv (append agg (list $idx)))
;        (push mv mylist -1)
;        (if (list? x)
;          (h-index-list x mv)))
;      mylist)
;  (h-index-list lst '())))

;; @syntax (nesting lst [atom])
;; @description Return an association list (element nested-level)
;; @param <lst> list of elements
;; @param <atom> boolean to return only atoms (true or nil)
;; @return association list
;; @example
;; (nesting '(1 (3 5) (2 (7 8) 9) 6))       ==> ((1 0) ((3 5) 1) (3 0) (5 1) ((2 (7 8) 9) 2) (2 0) ((7 8) 1) (7 0) (8 1) ;; (9 2) (6 3))
;; (nesting '(1 (3 5) (2 (7 8) 9) 6) true)  ==> ((1 0) (3 0) (5 1) (2 0) (7 0) (8 1) (9 2) (6 3))
(define (nesting lst atom)
"Return an association list (element nested-level)"
  (local (out idx)
    (setq out '())
    (setq idx (ref-all nil lst (fn (x) true)))
    (dolist (ind idx)
      (if atom
          (if (atom? (lst ind))
              (push (list (lst ind) (ind (- (length ind) 1))) out -1))
          ;else
          (push (list (lst ind) (ind (- (length ind) 1))) out -1)))
  out))

;; @syntax (index-items items lst)
;; @description Find the index of all elements of a list in another list
;; @param <items> list of items
;; @param <lst> list to search
;; @return list of indexes of all elements
;; @example
;; (setq lst '(2 2 2 1 4 6 2 2 2 1 4 6 2 2 1))
;; (index-items '(1 4 6) lst)  ==> ((3) (4) (5) (9) (10) (11) (14))
;; (index-items '(6 1 4) lst)  ==> ((3) (4) (5) (9) (10) (11) (14))
;; (index-items '(3 5 7) lst)  ==> ()
(define (index-items items lst)
"Find the index of all elements of a list in another list"
  (ref-all items lst (fn (needles item) (member item needles))))

;; @syntax (index-seq seq lst all)
;; @description Find the sequence of elements of a list in another list
;; @param <seq> sequence of items (list)
;; @param <lst> list to search
;; @param <all> find all sequence? (true or nil)
;; @return list of indexes of sequence
;; @example
;; (setq lst '(2 2 2 1 4 6 2 2 2 1 4 6 2 2 1))
;; (index-seq '(1 4 6) lst)       ==> (3)
;; (index-seq '(1 4 6) lst true)  ==> (3 9)
;; (index-seq '(2 2 2) lst true)  ==> (0 6)
;; (index-seq '(1 4 5) lst)       ==> ()
(define (index-seq seq lst all)
"Find the sequence of elements of a list in another list"
  (if all
    (filter (fn (i) (= seq (i (length seq) lst))) (flat (ref-all (seq 0) lst)))
    (filter (fn (i) (= seq (i (length seq) lst))) (flat (ref (seq 0) lst)))))

;; @syntax (replace-all lst)
;; @description Multiple replace on list and string
;; @param <lst> list or string
;; @return list or string replaced
;; @example
;; (setq sost '((1 a) (2 b) (3 c)))
;; (setq lst '(1 3 5 4 3 1 5 5 7 1 2))
;; (replace-all sost lst)  ==> (a c 5 4 c a 5 5 7 a b)
;; (setq str "newlisp is hard")
;; (setq sost '(("newlisp" "newLISP") ("hard" "fun")))
;; (replace-all sost str)  ==> "newLISP is fun"
(define-macro (replace-all)
"Multiple replace on list and string"
    (dolist (r (eval (args 0)))
      (replace (first r) (eval (args 1)) (last r))))

;; @syntax (substitute subst lst)
;; @description Multiple substitution on a list
;; @param <subst> list or substitution ((el1 subst1)...(elN substN))
;; @param <lst> list to change
;; @return list with substitution
;; @example
;; (setq a '(1 2 3 4 5 2))
;; (setq b '((1 2) (2 4)))
;; (substitute b a)  ==> (2 4 3 4 5 4)
;; (setq a '(1 2 3 4 5 6 7 8 9))
;; (setq b '((1 2) (3 4) (8 9)))
;; (substitute b a)  ==> (2 2 4 4 5 6 7 9 9)
;; (setq a '(1 2 1 2 1 2 1 2))
;; (setq b '((1 2) (2 1)))
;; (substitute b a)  ==> (2 1 2 1 2 1 2 1)
(define (substitute subst lst)
"Multiple substitution on a list"
  (local (out idx)
    (setq out '())
    (dolist (el lst)
      ; ricerca l'elemento nella lista delle sostituzioni
      (setq idx (find (list el '?) subst match))
      (cond ((nil? idx) ; elemento trovato
              (push el out -1))
            (true ; elemento non trovato
              (setq val (subst idx 1))
              (push val out -1))))
    out))

;; @syntax (match? str pattern)
;; @description Wildcard string matching
;; @param str string
;; @param search pattern ("?"= any single char - "*" = any sequence of chars ("" too))
;; @return true or nil
;; @example
;; (match? "baaabab" "*b???b*")  ==> true
;; (match? "abbaino" "*ba*ino")  ==> true
;; (match? "abbaino" "ab*?"   )  ==> true
;; (match? "abbaino" "ba*a?"  )  ==> nil
;; (match? "abbaino" "abba?no")  ==> true
;; (match? "abbaino" "abba?o" )  ==> nil
(define (match? str pattern)
"Wildcard string matching"
  (local (n m dp)
    (setq n (length str))
    (setq m (length pattern))
    ; matrice di lookup
    (setq dp (array (+ n 1) (+ m 1) '(nil)))
    ; un pattern vuoto si abbina con la stringa vuota
    (setf (dp 0 0) true)
    ; solo "*" si abbina con la stringa vuota
    (for (j 1 m)
      (if (= (pattern (- j 1)) "*")
          (setf (dp 0 j) (dp 0 (- j 1)))))
    ; riempie la matrice in modo bottom-up
    (for (i 1 n)
      (for (j 1 m)
        (cond ((= (pattern (- j 1)) "*")
               ; Due casi se vediamo un '*':
               ; a) Ignoriamo il carattere '*' 'e ci muoviamo
               ; al carattere successivo nel pattern,
               ; ad esempio, "*" indica una sequenza vuota
               ; b) Il carattere "*" si abbina con l'i-esimo
               ; carattere in input
               (setf (dp i j) (or (dp i (- j 1)) (dp (- i 1) j))))
              ((or (= (pattern (- j 1)) "?") (= (pattern (- j 1)) (str (- i 1))))
               ; I caratteri correnti sono considerati come
               ; abbinati in due casi:
               ; (a) il carattere corrente del pattern è "?"
               ; (b) i caratteri corrispondono effettivamente
               (setf (dp i j) (dp (- i 1) (- j 1))))
              (true
               ; i caratteri non si abbinano
               (setf (dp i j) nil)))))
    (dp n m)))

;; @syntax (rle-encode lst)
;; @description Encode list with Run Length Encoding
;; @param <lst> list to encode
;; @return encoded list
;; @example
;; (rle-encode '(a a a a b c c a a d e e e e f))  ==> ((4 a) (1 b) (2 c) (2 a) (1 d) (4 e) (1 f))
(define (rle-encode lst)
"Encode list with Run Length Encoding"
  (local (palo conta out)
    (cond ((= lst '()) '())
          (true
           (setq out '())
           (setq palo (first lst))
           (setq conta 0)
           (dolist (el lst)
              ; se l'elemento è uguale al precedente aumentiamo il suo conteggio
              (if (= el palo) (++ conta)
                  ; altrimenti costruiamo la coppia (conta el) e la aggiungiamo al risultato
                  (begin (extend out (list (list conta palo)))
                         (setq conta 1)
                         (setq palo el))))
           ; aggiungiamo l'ultima coppia di valori
           (extend out (list (list conta palo)))
           out))))

;; @syntax (rle-decode lst)
;; @description Decode list with Run Length Encoding
;; @param <lst> list to decode
;; @return decoded list
;; @example
;; (rle-decode '((4 a) (1 b) (2 c) (2 a) (1 d) (4 e) (1 f)))   ==> (a a a a b c c a a d e e e e f)
;; (rle-decode (rle-encode '(a a a a b c c a a d e e e e f)))  ==> (a a a a b c c a a d e e e e f)
(define (rle-decode lst)
"Decode list with Run Length Encoding"
  (local (out)
    (cond ((= lst '()) '())
          (true
           (setq out '())
           (dolist (el lst)
              (extend out (dup (last el) (first el))))
           out))))

;; @syntax (list-break lst lst-len)
;; @description Break a list into sub-lists of specified lengths
;; @param <lst> list to break
;; @param <lst-len> list of the lengths of the sublists
;; @return list of sublist
;; @example
;; (list-break '(a b c d e f) '(2 1 2))            ==> ((a b) (c) (d e))
;; (list-break '(a b c d) '(5))                    ==> ((a b c d))
;; (list-break '(a b c d) '(2))                    ==> ((a b))
;; (list-break '(a b c d) '(1 2 3))                ==> ((a) (b c) (d))
;; (list-break '(a b c d e f g h i j) '(1 2 3 4))  ==> ((a) (b c) (d e f) (g h i j))
;; (list-break '(a b c d e f g h i j) '(1 2 3 8))  ==> ((a) (b c) (d e f) (g h i j))
;; (list-break '(a b c d e f g h i j) '(1 2 3 8 5))  ==> ((a) (b c) (d e f) (g h i j) ())
(define (list-break lst lst-len)
"Break a list into sub-lists of specified lengths"
  (let ((i 0) (q 0) (out '()))
    (dolist (el lst-len)
      (setq i (+ i q))
      (setq q el)
      (push (slice lst i q) out -1))
    out))

;; @syntax (pair-func lst func rev)
;; @description Produces a list applying a function to each pair of elements of a list
;; @param <lst> list of objects (number or string)
;; @param <func> function to apply
;; @param <rev> true: (el(n) func el(n+1)) or nil: (el(n+1) func el(n))
;; @return list of results (number or string)
;; @example
;; (pair-func '(7 11 13 17 21) -)       ==> (4 2 4 4)        ;operation: el(n) func el(n-1)
;; (pair-func '(7 11 13 17 21) - true)  ==> (-4 -2 -4 -4)    ;operation: el(n-1) func el(n)
;; (pair-func '(10 20 30) +)            ==> (30 50)
(define (pair-func lst func rev)
"Produces a list applying a function to each pair of elements of a list"
      (if rev
          (map func (chop lst) (rest lst))
          (map func (rest lst) (chop lst))))

;; @syntax (group-block obj num)
;; @description Create a list/string with blocks of elements: (0...num) (1...num+1) ... (n-num-1...n-1)
;; @param <obj> list or string
;; @param <num> length of block
;; @return list of blocks
;; @example
;; (group-block '(1 3 5 8 2) 3)  ==> ((1 3 5) (3 5 8) (5 8 2))
;; (group-block '(1 3 5 8 2) 2)  ==> ((1 3) (3 5) (5 8) (8 2))
;; (group-block '(1 3 5 8 2) 5)  ==> ((1 3 5 8 2))
;; (group-block '(1 3 5 8 2) 6)  ==> ()
(define (group-block obj num)
"Create a list with blocks of elements: (0..num) (1..num+1) (n..num+n)"
  (local (out items len)
    (setq out '())
    (setq len (length obj))
    (if (>= len num) (begin
        ; numero di elementi nella lista di output (numero blocchi)
        (setq items (- len num (- 1)))
        (for (k 0 (- items 1))
          (push (slice obj k num) out -1))))
    out))

;; @syntax (group-by-first lst assoc-lst sorted)
;; @description Group the values of the sublists based on the first value of each sublist
;; @param <lst> list with sublist (el0 el1 ... elN)
;; @param <assoc-lst> creates association list (boolean)
;; @param <sorted> sorts sublists of association list
;; @return list
;; @example
;; (setq lst '((a 1 2 3) (b 2 1) (b 4 3 5) (a 4 5) (b 6) (c 1) (a 6)))
;; (group-by-first lst)            ==> ((a 1 2 3 4 5 6) (b 2 1 4 3 5 6) (c 1))
;; (group-by-first lst true)       ==> ((a (1 2 3 4 5 6)) (b (2 1 4 3 5 6)) (c (1)))
;; (group-by-first lst true true)  ==> ((a (1 2 3 4 5 6)) (b (1 2 3 4 5 6)) (c (1)))
(define (group-by-first lst assoc-lst sorted)
"Group the values of the sublists based on the first value of each sublist"
  (local (out idx valori)
    (setq out '())
    ; Ciclo per ogni elemento della lista
    (dolist (el lst)
      (setq idx (find (list (el 0) '*) out match))
      ; Esiste il primo valore dell'elemento corrente nella lista di output?
      (cond (idx
        ; Esiste: calcola i valori da aggiungere
        (setq valori (rest el))
        ;(setf (out idx) (append (out idx) valori)))
        ; Aggiorna il relativo elemento della lista di output
        ; aggiungendo i nuovi valori
        (extend (out idx) valori))
        (true
          ; Non esiste: aggiunge l'elemento corrente alla lista di output
          (push el out -1))))
    ; Crea la lista di associazione?
    (if assoc-lst
        ; Sottoliste ordinate?
        (if sorted
            (map (fn(x) (list (x 0) (sort (rest x)))) out)
            (map (fn(x) (list (x 0) (rest x))) out))
        out)))

;; @syntax (normalize lst-num val-min val-max)
;; @description Normalize a list of numbers in the range (a,b)
;; @param <lst-num> list of numbers (float)
;; @param <val-min> minimum value of range
;; @param <val-max> maximum value of range
;; @return normalized list of numbers (float)
;; @example
;; (normalize '(2 4 10 6 8 4) 0 1)      ==> (0 0.25 1 0.5 0.75 0.25)
;; (normalize '(2 4 10 6 8 4))          ==> (0 2.5 10 5 7.5 2.5)
;; (normalize '(2 4 10 6 8 4) 100 200)  ==> (100 125 200 150 175 125)
(define (normalize lst-num val-min val-max)
"Normalize a list of numbers in the range (a,b)"
  (local (hi lo k out)
    (setq out '())
    (setq hi (apply max lst-num))
    (setq lo (apply min lst-num))
    ; if val-max == nil then val-max = hi
    (setq val-max (or val-max hi))
    ; if val-min == nil then val-min = 0
    (setq val-min (or val-min 0))
    (setq k (div (sub val-max val-min) (sub hi lo)))
    (dolist (val lst-num)
      (push (add val-min (mul (sub val lo) k)) out -1))
    out))

;; @syntax (frequency lst)
;; @description Calculate the count and the frequency of items in a list
;; @param <lst> list of items (int, float, string, symbol)
;; @return frequency list ((el1 count1 freq1) (el2 count2 freq2)...(eln countn freqn))
;; @example
;; (frequency '(a b g f a f g f g h))  ==> (("a" 2 0.2) ("b" 1 0.1) ("f" 3 0.3) ("g" 3 0.3) ("h" 1 0.1))
;; (frequency '(1 2 3 4 5 5 4 3 2 1))  ==> (("1" 2 0.2) ("2" 2 0.2) ("3" 2 0.2) ("4" 2 0.2) ("5" 2 0.2))
;; (frequency '())                     ==> ()
(define (frequency lst)
"Calculate the count and the frequency of items in a list"
  (let ((sum (length lst)) (out '()))
    (new Tree 'myHash)
    ; conta le ripetizioni degli elementi
    (dolist (el lst)
      ; se la chiave non esiste nella hashmap...
      (if (null? (myHash (string el)))
          ; allora inserisce la chiave con il valore 1
          (myHash (string el) 1)
          ; altrimenti aggiunge 1 al valore associato alla chiave (che esiste)
          (myHash (string el) (+ $it 1)))
    ; assegna la hashmap ad una lista
    (setq out (myHash))
    ; calcola la frequenza degli elementi
    (setq out (map (fn(x) (push (div (last x) sum) x -1)) out))
    ; elimina la hashmap
    (delete 'myHash)
    out)))

;; @syntax (binary-search el lst order)
;; @description Search an item on a sorted list
;; @param <el> item (int, float, string, symbol)
;; @param <lst> sorted list of items
;; @param <order> order of the list: crescent or decrescent (> o <)
;; @return index of item in the list (int)
;; @example
;; (binary-search "max" '("abc" "eva" "max" "sara") <) ==> 2
;; (binary-search 'd '(a b c d e) <)                   ==> 3
;; (binary-search 2 '(1 2 3 4 5) <)                    ==> 1
;; (binary-search 2 '(1 2 3 4 5) >)                    ==> nil
;; (binary-search 2 '(5 4 3 2 1) >)                    ==> 3
;; (binary-search 2 '(5 4 3 2 1) <)                    ==> nil
;; (binary-search 2 '(1 2 2 3 4) <)                    ==> 2
;; (binary-search 2 '(4 3 2 2 1) >)                    ==> 2
;; (binary-search 1 '(1 1 1 1) <)                      ==> 1
;; (binary-search 1 '(1 1 1 1) >)                      ==> 1
(define (binary-search el lst order)
"Search an item on a sorted list"
  (local (out low high idx)
    (setq out nil)
    (setq low 0)
    (setq high (- (length lst) 1))
    (while (and (>= high low) (= out nil))
      (setq idx (>> (+ low high))) ;; right shift
      (cond ((< (lst idx) el)
             (if (= order <) ; list crescente
                (setq low (+ idx 1))
                (setq high (- idx 1))))
            ((> (lst idx) el)
             (if (= order <) ; list crescente
                (setq high (- idx 1))
                (setq low (+ idx 1))))
            (true (setq out idx))))
    out))

;; @syntax (order-type lst)
;; @description Check the sort order of a list
;; @param <lst> list of items
;; @return type of sorting (symbol)
;; @example
;; (order-type '(1 1 1))    ==> =
;; (order-type '(1 2 3))    ==> <
;; (order-type '(3 2 1))    ==> >
;; (order-type '(1 2 2 3))  ==> <=
;; (order-type '(3 2 2 1))  ==> >=
;; (order-type '(1 3 2))    ==> nil
;; (order-type '(a b c))    ==> <
(define (order-type lst)
"Check the sort order of a list"
  (cond ((apply =  lst) '= ) ;lista con elementi uguali
        ((apply >  lst) '> ) ;lista strettamente decrescente
        ((apply <  lst) '< ) ;lista strettamente crescente
        ((apply >= lst) '>=) ;lista decrescente
        ((apply <= lst) '<=) ;lista crescente
        (true nil)))         ;lista non ordinata

;; @syntax (sorensen-str str1 str2)
;; @description Calculate the Sorensen-Dice coefficient for two strings (similarity)
;; @param <str1> string
;; @param <str2> string
;; @return coefficient of similarity of the two strings(float)
;; @example
;; (sorensen-string "" "test")                                  ==> 0
;; (sorensen-string "pippo" "pappa")                            ==> 0.25
;; (sorensen-string "gggg" "gg")                                ==> 0.5
;; (sorensen-string "prima stringa" "seconda stringa")          ==> 0.6153846153846154
;; (sorensen-string "algorithms are fun" "logarithms are not")  ==> 0.5882352941176471
(define (sorensen-string str1 str2)
"Calculate the Sorensen-Dice coefficient for two strings (similarity)"
  (if (or (zero? (length str1)) (zero? (length str2)))
      0
      (local (nx-lst ny-lst nt-lst)
        (setq bigram-x (bigrammi str1))
        (setq bigram-y (bigrammi str2))
        (setq nx (length bigram-x))
        (setq ny (length bigram-y))
        (setq nt (length (intersect bigram-x bigram-y)))
        (div (* 2 nt) (+ nx ny)))))

;; @syntax (sorensen-list lst1 lst2)
;; @description Calculate the Sorensen-Dice coefficient for two lists (similarity)
;; @param <lst1> list
;; @param <lst2> list
;; @return coefficient of similarity of the two lists (float)
;; @example
;; (sorensen-list '(1 2 3 4 5) '(1 2 3 4 5))            ==> 1
;; (sorensen-list '(1 2 3 4 5) '(1 2 3))                ==> 0.75
;; (sorensen-list '(1 2 3 4 5) '(5 6 7))                ==> 0.25
;; (sorensen-list (sequence 1 10) (sequence 10 19))     ==> 0.1
;; (sorensen-list (sequence 1 100) (sequence 100 199))  ==> 0.01
(define (sorensen-list lst1 lst2)
"Calculate the Sorensen-Dice coefficient for two lists (similarity)"
  (cond ((or (empty? lst1) (empty? lst2)) 0)
        (true
          (div (* 2 (length (intersect lst1 lst2)))
               (+ (length lst1) (length lst2))))))

;; @syntax (levenshtein str1 str2)
;; @description Calculate the difference between two strings (Levenshtein distance)
;; @param <str1> first string
;; @param <str2> second string
;; @return distance lenght (int)
;; @example
;; (levenshtein "mister" "monster")       ==> 2
;; (levenshtein "Common LISP" "newLISP")  ==> 7
;; (levenshtein "" "newLISP")             ==> 7
;; (levenshtein "" "")                    ==> 0
(define (levenshtein str1 str2)
"Calculate the difference between two strings (Levenshtein distance)"
  (if (or (null? str1) (null? str2))
      (length (append str1 str2))
  ; else
  (local (n m dp costo)
    (setq n (length str1))
    (setq m (length str2))
    (setq dp (array (add n 1) (add m 1)))
    (cond ((and (zero? n) (zero? m)) nil)
          ((zero? n) m)
          ((zero? m) n)
          (true
            (for (i 0 n) (setf (dp i 0) i))
            (for (j 0 m) (setf (dp 0 j) j))
            (for (i 1 n)
              (for (j 1 m)
                (if (= (str1 (sub i 1)) (str2 (sub j 1)))
                  (setq costo 0)
                  (setq costo 1))
                (setf (dp i j) (min (add (dp (sub i 1) j) 1)
                                   (add (dp i (sub j 1)) 1)
                                   (add (dp (sub i 1) (sub j 1)) costo)))))))
    (dp n m))))

;; @syntax (soundex str)
;; @description Phonetic algorithm for indexing names by sound
;; @param <str> string
;; @return soundex code (string)
;; @example
;; (soundex "Ashcraft")  ==> A261
;; (soundex "Ashcroft")  ==> A261
;; (soundex "Gauss")     ==> G200
;; (soundex "Ghosh")     ==> G200
;; (soundex "Robert")    ==> R163
;; (soundex "Rupert")    ==> R163
(define (soundex str)
"Phonetic algorithm for indexing names by sound"
  (local (out prev curr)
    (setq str (upper-case str))
    (setq out (str 0))
    (setq prev (get-soundex-code (out 0)))
    (dostring (el str)
      (setq curr (get-soundex-code (char el)))
      (if (and (!= curr "") (!= curr "-") (!= curr prev))
        (push curr out -1))
      (if (!= curr "-") (setq prev curr)))
    (pad-string out "0" 4)))
; auxiliary function for soundex
(define (get-soundex-code ch)
  (letn ((lst '(("B" "1") ("F" "1") ("P" "1") ("V" "1")
                ("C" "2") ("G" "2") ("J" "2") ("K" "2")
                ("Q" "2") ("S" "2") ("X" "2") ("Z" "2")
                ("D" "3") ("T" "3")
                ("L" "4")
                ("M" "5") ("N" "5")
                ("R" "6")
                ("H" "-") ("W" "-")))
        (out (lookup ch lst)))
        (if (nil? out) (setq out ""))
        out))

;; @syntax (palindrome? obj)
;; @description Check if a list or a string or a number is palindrome
;; @param <obj> list or string or integer
;; @return true or nil
;; @example
;; (palindrome? '())             ==> true
;; (palindrome? '(1 2 3 2 1))    ==> true
;; (palindrome? "12321")         ==> true
;; (palindrome? 12321)           ==> true
;; (palindrome? '(1 2 3 2 1 2))  ==> nil
;; (palindrome? "123212")        ==> nil
;; (palindrome? 123212)          ==> nil
(define (palindrome? obj)
"Check if a list or a string or a number is palindrome"
  (if (integer? obj)
      (let (str (string obj)) (= str (reverse (copy str))))
      (= obj (reverse (copy obj)))))
; Versione più veloce per i numeri interi
;(define (palindrome? num)
;"Check if a non-negative integer is palindrome"
;  (let ((rev 0) (val num))
;    ; crea il numero invertito
;    (until (zero? val)
;      (setq rev (+ (* rev 10) (% val 10)))
;      (setq val (/ val 10)))
;    (= rev num)))

;; @syntax (anagrams str)
;; @description Calculate all the anagrams of a string
;; @param <str> string
;; @return list of anagrams
;; @example
;; (anagrams "LISP")  ==> ("PSIL" "PSLI" "PILS" "PISL" "PLSI" "PLIS" "SILP" "SIPL" "SLPI" "SLIP" "SPIL" "SPLI" "ILPS" "ILSP" "IPSL" "IPLS" "ISLP" "ISPL" "LPSI" "LPIS" "LSIP" "LSPI" "LIPS" "LISP")
(define (anagrams str)
"Calculate all the anagrams of a string"
  (map (fn (perm) (select str perm))
       (permute-aux (sequence 0 (- (length str) 1)))))
; auxiliary permutation function
(define (permute-aux lst)
  (if (= (length lst) 1)
   lst
   (apply append (map (fn (rot)
                      (map (fn (perm) (cons (first rot) perm))
                           (permute-aux (rest rot))))
                      (rotate-aux lst)))))
; auxiliary rotation function
(define (rotate-aux lst)
  (map (fn (x) (rotate lst)) (sequence 1 (length lst))))

;; @syntax (pad-string str ch len left)
;; @description Pad a string to a predefinite length with a predefinite char
;; @param <str> string to pad
;; @param <ch> char used to pad the string
;; @param <len> length of padded string
;; @param <left> if true then pad the string to the left
;; @return padded string
;; @example
;; (pad-string "" "0" 2)          ==> "00"
;; (pad-string "ABC" "0" 5)       ==> "ABC00"
;; (pad-string "ABC" "0" 3)       ==> "ABC"
;; (pad-string "ABC" "0" 2)       ==> "AB"
;; (pad-string "ABC" "0" 5 true)  ==> "00ABC"
;; (pad-string "ABC" " " 5 true)  ==> "  ABC"
(define (pad-string str ch len left)
"Pad a string to a predefinite length with a predefinite char"
  (local (out len-str)
    (setq out "")
    (setq len-str (length str))
    (cond ((zero? len-str) (setq out (dup ch len)))
          ((= len-str len) (setq out str))
          ((> len-str len) (setq out (slice str 0 len)))
          ((< len-str len)
           (if left
               (setq out (push (dup ch (- len len-str)) str))
               (setq out (push (dup ch (- len len-str)) str -1)))))))

;; @syntax (butlast obj num)
;; @description Return the list or string without the last num elements (default num=1)
;; @param <obj> list or string
;; @param <num> elements to remove (from the end)
;; @return list or string
;; @example
;; (butlast '())             ==> '()
;; (butlast "")              ==> ""
;; (butlast '(1 2 3 4 5) 2)  ==> (1 2 3)
;; (butlast "newLISP-")      ==> "newLISP"
(define (butlast list-or-string num)
"Return the list or string without the last num elements (default num=1)"
  (chop list-or-string (or num 1)))

;; @syntax (file-list file-str)
;; @description Create a list with all the lines of a text file
;; @param <file-str> name of file (string)
;; @return list of string
;; @example
;; (save "demo.lsp" 'file-list)
;; (file-list "demo.lsp")
;; ("(define (file-list file-str)"
;; "  (let (lst '()) "
;; "   (setq file-str (open file-str \"read\")) "
;; "   (while (read-line file-str) "
;; "    (push (current-line) lst -1)) "
;; "   (close file-str) lst))"
;; "")
(define (file-list file-str)
"Create a list with all the lines of a text file"
  (let (lst '())
    (setq file-str (open file-str "read"))
    (while (read-line file-str)
      (push (current-line) lst -1))
    (close file-str)
    lst))

;; @syntax (list-csv lst file-str sepchar)
;; @description Create a file csv from a list
;; @param <lst> list/matrix of data
;; @param <file-str> name of file (string)
;; @param <sepchar> charactere separator (default ",")
;; @return true or nil (creates a file)
;; @example
;; (setq points (map list (randomize (sequence 1 100)) (randomize (sequence 1 100))))
;; (list-csv points "punti.csv")  ==>  true
;; (setq data '(("eva" "tommy" "max" "roby")
;;              (20 24 31 89)
;;              ("f" "t" "t" "f")
;;              (1.622 2.44 45.2 100.1)))
;; (setq nomi '("nome" "test" "tipo" "valore"))
;; (setq all (append (list nomi) (transpose data)))
;; (("nome" "test" "tipo" "valore")
;; ("eva" 20 "f" 1.622)
;; ("tommy" 24 "t" 2.44)
;; ("max" 31 "t" 45.2)
;; ("roby" 89 "f" 100.1))
;; (list-csv all "demo.csv")  ==> true
(define (list-csv lst file-str sepchar)
"Create a file csv from a list"
  (local (outfile)
    (if (nil? sepchar)
        (setq sepchar ","))
    (setq outfile (open file-str "write"))
    (dolist (el lst)
      (if (list? el)
          (setq line (join (map string el) sepchar))
          (setq line (string el)))
      (write-line outfile line))
    (print outfile { })
    (close outfile)))

;; @syntax (select-even lst)
;; @description Select the elements of a list that have even index
;; @param <lst> list
;; @return list
;; @example
;; (setq data '(0 1 2 3 4 5 6 7 8 9 10 11 12 13))
;; (select-even data)   ==> (0 2 4 6 8 10 12)
(define (select-even lst)
"Select the elements of a list that have even index"
  (let (len (length lst))
    (if (odd? len)
        (select lst (sequence 0 len 2))
        (select lst (sequence 0 (- len 1) 2)))))

;; @syntax (select-odd lst)
;; @description Select the elements of a list that have odd index
;; @param <lst> list
;; @return list
;; @example
;; (setq data '(0 1 2 3 4 5 6 7 8 9 10 11 12 13))
;; (select-odd data)   ==> (1 3 5 7 9 11 13)
(define (select-odd lst)
"Select the elements of a list that have odd index"
  (let (len (length lst))
    (if (even? len)
        (select lst (sequence 1 len 2))
        (select lst (sequence 1 (- len 1) 2)))))

;; @syntax (select-once lst)
;; @description Select the elements of a list that appear only once
;; @param <lst> list of elements
;; @return list of elements
;; @example
;; (once '(1 2 3 4 5 5 6 2 8 9 8))      ==> (1 3 4 6 9)
;; (once '(2 2 3 3 4 4 4 5 6 7 8 9 8))  ==> (5 6 7 9)
;; (once '(2 2 3 3))                    ==> ()
(define (select-once lst)
"Select the elements of a list that appear only once"
  (local (out unici conta)
    (setq out '())
    (setq unici (unique lst))
    ; conta le occorrenze di ogni elemento (elemento conteggio)
    (setq conta (map list unici (count unici lst)))
    ; filtra gli elementi che compaiono solo una volta (occorrenza = 1)
    (dolist (el conta)
      (if (= (el 1) 1) (push (el 0) out -1)))
    out))

;; @syntax (select-multi lst)
;; @description Select the elements of a list that appear more than once
;; @param <lst> list of elements
;; @param <all> boolean (true --> all multiple of elements)
;; @return list of elements
;; @example
;; (select-multi '(1 2 3 4 5 5 6 2 8 9 8))       ==> (2 5 8)
;; (select-multi '(1 2 3 4 5 5 6 2 8 9 8) true)  ==> (2 2 5 5 8 8)
;; (select-multi '(2 2 3 3 4 4 4 5 6 7 8 9 8))   ==> (2 3 4 8)
;; (select-multi '(2 2 3 3))                     ==> (2 3)
;; (select-multi '(2 2 3 3) true)                ==> (2 2 3 3)
(define (select-multi lst all)
"Select the elements of a list that appear more than once"
  (local (out unici conta)
    (setq out '())
    (setq unici (unique lst))
    ; conta le occorrenze di ogni elemento (elemento conteggio)
    (setq conta (map list unici (count unici lst)))
    ; filtra gli elementi che compaiono solo più di una volta (occorrenze > 1)
    (dolist (el conta)
      (if (> (el 1) 1)
          (if all
              (extend out (dup (el 0) (el 1))) ; all multiples
              (push (el 0) out -1)))) ; only one multiple
    out))

;; @syntax (select-freq lst k op)
;; @description Select elements from a list with specified frequency
;; @param <lst> list of elements
;; @param <k> frequency (integer)
;; @param <op> operator (=, >, <, >=, <=, !=)
;; @return elements with specified frequency (list)
;; @example
;-> (select-freq '(1 2 2 3 3 3 4 4 5) 2 =)   ==> (2 4)
;-> (select-freq '(1 2 2 3 3 3 4 4 5) 2 >)   ==> (3)
;-> (select-freq '(1 2 2 3 3 3 4 4 5) 2 <)   ==> (1 5)
;-> (select-freq '(1 2 2 3 3 3 4 4 5) 2 >=)  ==> (2 3 4)
;-> (select-freq '(1 2 2 3 3 3 4 4 5) 2 <=)  ==> (1 2 4 5)
;-> (select-freq '(1 2 2 3 3 3 4 4 5) 2 !=)  ==> (1 3 5)
(define (select-freq lst k op)
"Select elements from a list with specified frequency"
  (let ( (unici (unique lst)) ; elementi unici della lista
         (op (or op =)) ) ; operatore di default: op --> =
    (map first (filter (fn(x) (op (x 1) k))
                        (map list unici (count unici lst))))))

;; @syntax (select-k lst k)
;; @description Select elements from a list every k
;; @param <lst> list
;; @param <k> integer
;; @return list
;; @example
;; (select-k (sequence 1 21) 4)  ==> (4 8 12 16 20)
(define (select-k lst k)
"Select elements from a list every k"
  (select lst (sequence (- k 1) (- (length lst) 1) k)))
; OLD VERSION (slower)
;(define (select-k lst k)
;"Select elements from a list every k"
;  (let (out '())
;    (dolist (el lst) (if (= (% (+ $idx 1) k) 0) (push el out -1)))
;    out))

;; @syntax (remove-k lst k)
;; @description Remove elements from a list every k
;; @param <lst> list
;; @param <k> integer
;; @return list
;; @example
;; (remove-k (sequence 1 21) 4)  ==> (1 2 3 5 6 7 9 10 11 13 14 15 17 18 19 21)
(define (remove-k lst k)
"Remove elements from a list every k"
  (let (out '())
    (dolist (el lst) (if (!= (% (+ $idx 1) k) 0) (push el out -1)))
    out))

;; @syntax (insert-k val lst k)
;; @description Insert element into a list every k
;; @param <val> value/symbol to insert
;; @param <lst> list
;; @param <k> integer
;; @return list
;; @example
;; (insert-k ', '(1 2 3 4 5 6 7 8 9) 1)  ==> (1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 ,)
;; (insert-k ', '(1 2 3 4 5 6 7 8 9) 2)  ==> (1 2 , 3 4 , 5 6 , 7 8 , 9)
(define (insert-k val lst k)
"Insert element into a list every k"
  (let (out '())
    (dolist (el lst)
      (if (zero? (% (+ $idx 1) k))
          (extend out (list el val))
          (push el out -1)))
    out))

;; @syntax (remove-at lst indexes)
;; @description Remove elements from a list with a list of indexes
;; @param <lst> list of elements
;; @param <indexes> list of indexes
;; @return list
;; @example
;; (remove-at '(3 5 1 8 6 3) '(3 0 5))    ==> (5 1 6)
;; (remove-at '(3 5 1 8 6 3) '(0 1))      ==> (1 8 6 3)
;; (remove-at '(3 5 1 8 6 3) '(0 0 1 1))  ==> (1 8 6 3)
;; (remove-at '(3 5 1 8 6 3) '(0 1 7))    ==> ERR: invalid list index
(define (remove-at lst indexes)
"Remove elements from a list with a list of indexes"
  (map (fn(x) (pop lst x)) (unique (sort indexes >)))
  lst)

;; @syntax (natural-sort lst)
;; @description Sorts the strings of a list in natural order
;; @param <lst> list of string
;; @return natural ordered list
;; @example
;; (natural-sort '("1a" "11a" "a12" "c01" "01c" "010b" "b1" "a01" "a001"))
;;   ==> ("1a" "01c" "010b" "11a" "a001" "a01" "a12" "b1" "c01")
; Natural sort is the ordering of strings in alphabetical order,
; except that multi-digit numbers are treated atomically,
; i.e., as if they were a single character.
; ported to newLISP by G. Fischer
(define (natural-sort lst)
"Sorts the strings of a list in natural order"
  (let (natural-key (lambda (s) (filter true?
    (flat (transpose (list
            (parse s "[0-9]+" 0)
            (map int (find-all "[0-9]+" s))))))))
    (sort lst (fn (x y) (< (natural-key x)
            (natural-key y))))))

;; @syntax (zip lst1 lst2 ... lstN)
;; @description Transpose multiple lists into one
;; @param <lst(i)> lists
;; @return zipped list
;; @example
;; (zip '(1 2 3) '(a b c) '(x y z))        ==> ((1 a x) (2 b y) (3 c z))
;; (apply zip '((1 a x) (2 b y) (3 c z)))  ==> (1 2 3) '(a b c) '(x y z))
; written by Nigel et altri
(define (zip)
"Transpose multiple lists into one"
  (transpose (args)))

;; @syntax (append-nil [nil] obj1 obj2 ... objN)
;; @description Appends multiple objects into one
;; @param <obj(i)> lists or string
;; @return all objects appended
;; @example
;; (append-nil nil '(a b))                ==> (a b)
;; (append-nil '(1 2 3) '(4 5 6) '(a b))  ==> (1 2 3 4 5 6 a b)
;; (append-nil nil "" "Hello " "world")   ==> "Hello world"
(define (append-nil obj)
"Appends multiple objects into one"
  (if obj (append obj (apply append (args)))
            (apply append (args))))

;; @syntax (count-obj lst-obj obj)
;; @description Count elements of lst-obj in obj and returns a list of those counts
;; @param <lst-obj> list (or array) of strings and/or numbers (objects)
;; @param <obj> list (or array) of objects to be counted
;; @return list of counts
;; @example
;; (count-obj '("a") "mamma mia")                         ==> (3)
;; (count-obj '("a" "b" "c") "aabbcabsdbcgabcbfbghsgbc")  ==> (4 8 4)
;; (count-obj '(1 2) '(2 2 2 1 1 1 3 1 2 4 5))            ==> (4 4)
(define (count-obj lst-obj obj)
"Count elements of lst-obj in obj and returns a list of those counts"
  (let (out '())
    (dolist (s lst-obj)
      (push (length (find-all s obj)) out -1))
    out))

;; @syntax (cartesian)
;; @description Calculate the cartesian product of lists
;; @param <args> a number of lists
;; @return cartesian product of all lists
;; @example
;; (cartesian '(1 2) '(3 4) '(5 6))        ==> ((1 3 5) (1 3 6) (1 4 5) (1 4 6) (2 3 5) (2 3 6) (2 4 5) (2 4 6))
;; (apply cartesian '((1 2) (3 4) (5 6)))  ==> ((1 3 5) (1 3 6) (1 4 5) (1 4 6) (2 3 5) (2 3 6) (2 4 5) (2 4 6))
;; (cartesian '(1 2 3) '() '(4 5))   ==> ()
(define (cartesian)
"Calculate the cartesian product of lists"
  (let (out '(()) )
    (dolist (lst (args))
      (let (tmp '())
        (dolist (parz out)
          (dolist (el lst)
            (push (append parz (list el)) tmp -1)))
        (setq out tmp)))
    out))

;; @syntax (cartesian-product lst-lst)
;; @description Calculate the cartesian product of a list of lists
;; @param <lst-lst> list of lists
;; @return cartesian product of all lists
;; @example
;; (cartesian-product '((1 2) (3 4) (5 6)))  ==> ((1 3 5) (1 3 6) (1 4 5) (1 4 6) (2 3 5) (2 3 6) (2 4 5) (2 4 6))
;; (cartesian-product '((1 2 3) (4) (5 6)))  ==> ((1 4 5) (1 4 6) (2 4 5) (2 4 6) (3 4 5) (3 4 6))
;; (cartesian-product '((1 2 3) () (4 5)))   ==> ()
(define (cartesian-product lst-lst)
"Calculate the cartesian product of a list of lists"
  (let (out '())
    (dolist (el (apply cp lst-lst 2))
      (push (flat el) out -1))
    out))
; auxiliary function: cartesian product of two list
(define (cp lst1 lst2)
  (let (out '())
    (if (or (null? lst1) (null? lst2))
        '()
        (dolist (el1 lst1)
          (dolist (el2 lst2)
            (push (list el1 el2) out -1))))))

;; @syntax (min-max-idx lst)
;; @description Return min and max values with their index in a list
;; @param <lst> list of numbers or strings
;; @return list (min-val idx-of-min-val max-val idx-of-max-val)
;; @example
;; (min-max-idx '(10 20 3 -4 9 7)))  ==> (-4 3 20 1)
(define (min-max-idx lst)
"Return min and max values with their index in a list"
  (let ((minimo (apply min lst)) (massimo (apply max lst)))
    (list minimo (first (ref minimo lst)) massimo (first (ref massimo lst)))))

;; @syntax (min-idx lst)
;; @description Return min value and its index in a list
;; @param <lst> list of numbers or strings
;; @return list (min-val idx)
;; @example
;; (min-idx '(10 20 3 -4 9 7))  ==> (-4 3)
(define (min-idx lst)
"Return min values and its index"
  (let (minimo (apply min lst))
    (list minimo (first (ref minimo lst)))))

;; @syntax (max-idx lst)
;; @description Return max value and its index in a list
;; @param <lst> list of numbers or strings
;; @return list (max-val idx)
;; @example
;; (max-idx '(10 20 3 -4 9 7))  ==> (20 1)
(define (max-idx lst)
"Return max values and its index"
  (let (massimo (apply max lst))
    (list massimo (first (ref massimo lst)))))

;; @syntax (remove-common lst1 lst2)
;; @description Remove common elements of two lists (remove 1:1)
;; @param <lst1> list
;; @param <lst2> list
;; @return list
;; @example
;; (remove-common (explode "elisabeth") (explode "alexander"))  ==> ("a" "b" "d" "h" "i" "n" "r" "s" "t" "x")
(define (remove-common lst1 lst2)
"Remove common elements of two lists (remove 1:1)"
  (cond
    ((= lst1 '()) lst2)
    ((= lst2 '()) lst1)
    (true
      (local (out len1 len2 i j el1 el2)
        (setq out '())
        (setq len1 (length lst1))
        (setq len2 (length lst2))
        ; usa i vettori
        (setq lst1 (array len1 lst1))
        (setq lst2 (array len2 lst2))
        ; ordina le liste
        (sort lst1)
        (sort lst2)
        (setq i 0)
        (setq j 0)
        ; confronta gli elementi ed avanza con due puntatori
        (while (and (< i len1) (< j len2))
          (setq el1 (lst1 i))
          (setq el2 (lst2 j))
                ; elementi uguali
          (cond ((= el1 el2) (++ i) (++ j))
                ; primo elemento minore
                ((< el1 el2) (push el1 out -1) (++ i))
                ; secondo elemento minore
                ((> el1 el2) (push el2 out -1) (++ j))))
        ; aggiunge gli elementi della lista più lunga
        (cond ((and (= i len1) (= j len2)) out)
              ((= i len1) (extend out (array-list (slice lst2 j))))
              ((= j len2) (extend out (array-list (slice lst1 i)))))))))

;; @syntax (remove-commons)
;; @description Remove common elements of n lists (remove 1:1)
;; @param <args> n lists
;; @return list
;; @example
;; (remove-commons '(1 2) '(1 2) '(1 2))  ==> ()
;; (remove-commons '(1 2) '(1 2 3) '(1 2 3 4)) ==> (3 3 4)
(define (remove-commons)
"Remove common elements of n lists (remove 1:1)"
  ; calcola gli elementi in comune tra tutte le liste date
  (let (comuni (apply take-commons (args)))
    ; unisce le liste ed elimina le liste vuote
    (flat (clean null? (map (curry remove-common comuni) (args))))))

;; @syntax (take-common lst1 lst2)
;; @description Take common elements of two lists (take 1:1)
;; @param <lst1> list
;; @param <lst2> list
;; @return list
;; @example
;; (take-common '(1 2 3 4 4 4 1) '(4 1 2 6 4))  ==> (1 2 4 4)
;; (take-common '("a" "a" "a") '("a" "a" "a" "a"))  ==> ("a" "a" "a")
(define (take-common lst1 lst2)
"Take common elements of two lists (take 1:1)"
  (cond
    ((or (= lst1 '()) (= lst2 '())) '())
    (true
      (local (out len1 len2 i j el1 el2)
        (setq out '())
        (setq len1 (length lst1))
        (setq len2 (length lst2))
        ; usa i vettori
        (setq lst1 (array len1 lst1))
        (setq lst2 (array len2 lst2))
        ; ordina le liste
        (sort lst1)
        (sort lst2)
        (setq i 0)
        (setq j 0)
        ; confronta gli elementi ed avanza con due puntatori
        (while (and (< i len1) (< j len2))
          (setq el1 (lst1 i))
          (setq el2 (lst2 j))
                ; elementi uguali
          (cond ((= el1 el2) (push el1 out -1) (++ i) (++ j))
                ; primo elemento minore
                ((< el1 el2) (++ i))
                ; secondo elemento minore
                ((> el1 el2) (++ j))))
        out))))

;; @syntax (take-commons)
;; @description Take common elements of n lists (take 1:1)
;; @param <args> n lists
;; @return list
;; @example
;; (take-commons '("a" "a" "a") '("a" "a" "a" "a") '("m" "a" "m" "a"))  ==> ("a" "a")
;; (take-commons '(1 2 3 4 4 4 1) '(4 1 2 6 4) '(3 5 2 8 1))  ==> (1 2)
(define-macro (take-commons)
"Take common elements of n lists (take 1:1)"
  (apply take-common (map eval (args)) 2))

;; @syntax (count-same lst1 lst2)
;; @description Count the number of equal elements of two list (same value, same index)
;; @param <lst1> first list
;; @param <lst2> second list
;; @return number of equal elements
;; @example
;; (count-same '(1 2 3 4) '(0 2 3 5))    ==> 2
;; (count-same '(1 2 3) '(1 2 3 4))      ==> 3
;; (count-same '(1 2 3 4) '(0 2 3 4 1))  ==> 3
;; (count-same '(1 2 3 4) '(4 3 2 1))    ==> 0
(define (count-same lst1 lst2)
"Count the number of equal element of two list (same value, same index)"
  (first (count '(true) (map = lst1 lst2))))

;; @syntax (find-closest num lst idx)
;; @description Find closest number in a list
;; @param <num> num to search
;; @param <lst> list of numbers
;; @param <idx> index of number in sublist (-1 for flat list)
;; @return list (value index)
;; @example
;; (setq data '((a 151 a b c) (a -50 c d e) (a 230 x y z) (a 250 f g h)))
;; (find-closest 240 data 1)  ==> ((a 230 x y z) 2)
;; (find-closest 50 data 1)   ==> ((a -50 x y z) 2)
;; (setq data '(-101 200 -230 250))
;; (find-closest -181 data -1) ==> (-230 2)
(define (find-closest num lst idx)
"Find closest number in a list"
  (local (value val-index diff d)
    (cond ((= idx -1) ; flat list
            (setq value (lst 0))
            (setq val-index 0)
            (setq diff (abs (- num (lst 0))))
            (dolist (el lst)
              (setq d (abs (- num el)))
              (if (< d diff)
                  (set 'diff d 'val-index $idx 'value el)))
            (list value val-index))
          (true ; nested list
            (setq value (lst 0 idx))
            (setq val-index 0)
            (setq diff (abs (- num (lst 0 idx))))
            (dolist (el lst)
              (setq d (abs (- num (el idx))))
              (if (< d diff)
                  (set 'diff d 'val-index $idx 'value (el idx))))
            (list (lst val-index) val-index)))))

;; @syntax (sort-with lst base op)
;; @description Sort a list with the order of another list
;; @param <lst> list to sort
;; @param <base> list with ordered elements
;; @param <op> ascending (<=) or descending (>=) sort
;; @return sorted list
;; @example
;; (sort-with '("c" "b" "d" "a" "e" "e") '("a" "c" "b" "d" "e") <=)  ==> ("a" "c" "b" "d" "e" "e")
;; (sort-with '(1 2 3 4 5 6 7 8 9) '(1 9 2 8 3 7 4 5 6) <=)          ==> (1 9 2 8 3 7 4 5 6)
;; (sort-with '(1 2 3 4 5 6 7 8 9) '(1 9 2 8 3 7 4 5 6) >=)          ==> (6 5 4 7 3 8 2 9 1)
(define (sort-with lst base op)
"Sort a list with the order of another list"
  (define (check x y) (op (lookup x base-pos) (lookup y base-pos)))
  (let (base-pos (map (fn(x) (list x $idx)) base))
    (sort lst check)))

;; @syntax (sequence-alpha simboli num-chars)
;; @description Generate an alphanumeric sequence
;; @param <sym-str> string of symbols
;; @param <num-chars> number of chars of each element of the sequence
;; @return sequence (list of string)
;; @example
;; (sequence-alpha "0123456789" 2)  ==> ("00" "01" "02" "03" "04" "05" "06" "07" "08" "09" "10" "11" ... "92" "93" "94" "95" "96" "97" "98" "99")
;; (sequence-alpha "01" 4)  ==> ("0000" "0001" "0010" "0011" "0100" "0101" "0110" "0111" "1000" "1001" "1010" "1011" "1100" "1101" "1110" "1111")
;; (sequence-alpha "ABC" 1)  ==> ("A" "B" "C")
;; (sequence-alpha "ABC" 2)  ==> ("AA" "AB" "AC" "BA" "BB" "BC" "CA" "CB" "CC")
;; (sequence-alpha "ABC" 3)  ==> ("AAA" "AAB" "AAC" "ABA" ... "CBB" "CBC" "CCA" "CCB" "CCC")
;; (sequence-alpha "0123456789ABCDEF" 2)  ==> ("00" "01" "02" "03" "04" ... "F9" "FA" "FB" "FC" "FD" "FE" "FF")
;; (sequence-alpha "0123456789ABCDEF" 4)) ==> ("0000" "0001" "0002" "0003" ... "FFF9" "FFFA" "FFFB" "FFFC" "FFFD" "FFFE" "FFFF")
(define (sequence-alpha sym-str num-chars)
"Generate an alphanumeric sequence"
  (local (out len posizioni break numero pos)
    (setq out '())
    (setq len (length sym-str))
    ; Creazione di un array con num-chars zeri
    (setq posizioni (array num-chars '(0)))
    (setq break nil)
    (until break
      ; Creazione del numero corrente
      (setq numero "")
      (dolist (i posizioni) (extend numero (sym-str i)))
      ;(println numero)
      (push numero out -1)
      ; Incrementa le posizioni dall'ultima
      (setq pos (- num-chars 1))
      (while (and (>= pos 0) (= (posizioni pos) (- len 1)))
        (setf (posizioni pos) 0)
        (-- pos))
      ; Se tutte le posizioni sono arrivate alla fine, esce
      (if (< pos 0)
          (setq break true)
          ;else
          ; Altrimenti, incrementa la posizione corrente
          (++ (posizioni pos))))
    out))

;; @syntax (sum-diff lst after)
;; @description Calculate the alternate sum/diff of integers of a list
;; @param <lst> list of integers
;; @param <after> after = true --> (+ - + - ...) after the first integer
;; @return alternate sum/diff (integer)
;; @example
;; (sum-diff '(3 7 2 3 1))  ==> -4
;; (sum-diff '(3 7 2 3 1) true) ==> 10
(define (sum-diff lst after)
"Calculate the alternate sum/diff of integers of a list"
  (if (null? lst '()) 0
  ;else
    (let ( (s-d 0) )
      ; after = true --> segni alternati (+ - + - ...) dopo il primo termine
      (if after (setq s-d (pop lst)))
      (dolist (el lst)
        (if (even? $idx)
            (++ s-d el)
            (-- s-d el)))
      s-d)))

;; @syntax (diff-sum lst after)
;; @description Calculate the alternate diff/sum of integers of a list
;; @param <lst> list of integers
;; @param <after> after = true --> (- + - + ...) after the first integer
;; @return alternate diff/sum (integer)
;; @example
;; (diff-sum '(3 7 2 3 1))  ==> 4
;; (diff-sum '(3 7 2 3 1) true) ==> -4
(define (diff-sum lst after)
"Calculate the alternate diff/sum of integers of a list"
  (if (null? lst '()) 0
  ;else
    (let ( (d-s 0) )
      ; after = true --> segni alternati (- + - + ...) dopo il primo termine
      (if after (setq d-s (pop lst)))
      (dolist (el lst)
        (if (even? $idx)
            (-- d-s el)
            (++ d-s el)))
      d-s)))

;; @syntax (sum-free? lst)
;; @description Check if a list is sum-free (no pair of numbers (not necessarily distinct) sums to a number in the list)
;; @param <lst> list of integer
;; @return boolean (true/nil)
;; @example
;; (sum-free? '(1 3 5 7))  ==> true
;; (sum-free? '(2 4 5 7))  ==> nil
(define (sum-free? lst)
"Check if a list is sum-free (no pair of numbers (not necessarily distinct) sums to a number in the list)"
  (let (out nil)
    (dolist (el1 lst out)
      (dolist (el2 lst out)
        (if (find (+ el1 el2) lst) (setq out true))))
    (not out)))

;; @syntax (sum-num-from-list numbers num)
;; @description Find numbers in a list that add to a given number
;; @param <numbers> list of integer numbers
;; @param <num> sum number (integer)
;; @return list of numbers or nil
;; @example
;; (sum-num-from-list '(3 34 4 12 5 2) 9)   ==> (4 5)
;; (sum-num-from-list '(3 34 4 12 5 2) 35)  ==> nil
;; (sum-num-from-list '(3 34 4 12 5 2) 0)   ==> nil
;; (sum-num-from-list '(3 34 4 12 5 2) 50)  ==> (34 4 12)
;; (sum-num-from-list '(3 34 4 12 5 2) 5)   ==> (5)
(define (sum-num-from-list numbers num)
"Find numbers in a list that add to a given number"
  (let ( (dp (array (+ num 1) (dup nil (+ num 1))))
         (used-numbers (array (+ num 1) (dup nil (+ num 1)))) )
    (setf (dp 0) true)
    (dolist (el numbers)
      (for (i num 0 -1)
        (if (and (>= i el) (dp (- i el)))
          (begin
            (setf (dp i) true)
            (if (not (used-numbers i))
              (if (used-numbers (- i el))
                (setf (used-numbers i) (append (used-numbers (- i el)) (list el)))
                (setf (used-numbers i) (list el))))))))
    (used-numbers num)))

;; @syntax (all-contiguous-splits lst)
;; @description Split a list into two contiguous sublists in all possible ways
;; @param <lst> list of element
;; @return list of splits
;; @example
;; (all-contiguous-splits '(1 2 3 4 5))  ==> (((1) (2 3 4 5)) ((1 2) (3 4 5)) ((1 2 3) (4 5)) ((1 2 3 4) (5)))
;; (all-contiguous-splits '(1))  ==> (((1) ()) (() (1)))
;; (all-contiguous-splits '())   ==> ()
(define (all-contiguous-splits lst)
"Split a list into two contiguous sublists in all possible ways"
  (if (= lst '()) '()
  ;else
  (local (len cut out)
    (setq out '())
    (setq len (length lst))
    (setq cut (- len 1))
    (for (c 1 cut)
      ; parte sinistra corrente della lista
      (setq sx (slice lst 0 c))
      ; parte destra corrente della lista
      (setq dx (slice lst c))
      (push (list sx dx) out -1))
    out)))

;; @syntax (split-integer num)
;; @description Generate all the splits of an integer in order
;; @param <num> decimal integer
;; @return list of splits
;; @example
;; (split-integer 123)   ==> ((123) (12 3) (1 23) (1 2 3))
;; (split-integer 1203)  ==> ((1203) (120 3) (12 3) (12 0 3) (1 203) (1 20 3) (1 2 3) (1 2 0 3))
(define (split-integer num)
"Generate all the splits of an integer in order"
(if (= (length num) 1) (list (list num))
  ;else
  (local (str out len max-tagli taglio fmt cur-str)
    ; convert integer to string
    (setq str (string num))
    (setq out '())
    (setq len (length str))
    ; numero massimo di tagli
    (setq max-tagli (- len 1))
    ; formattazione con 0 davanti
    (setq fmt (string "%0" max-tagli "s"))
    (for (i 0 (- (pow 2 max-tagli) 1))
      ; taglio corrente
      (setq taglio (format fmt (bits i)))
      ; taglia la stringa con taglio corrente
      (setq cur-str (split-aux str taglio))
      ; trova tutti i numeri interi della stringa tagliata corrente e
      ; li inserisce come elemento nella soluzione
      ;(push (divide str taglio) out -1)
      (push (map (fn(x) (int x 0 10)) (find-all {-?\d+} cur-str)) out -1))
    out)))
; Auxiliary function
(define (split-aux str binary)
  (let (out "")
    (for (i 0 (- (length binary) 1))
      (if (= (binary i) "1")
          ; taglio
          (extend out (string (str i) { }))
          ; nessun taglio
          (extend out (str i))))
    ; inserisce caratteri finali
    (extend out (str -1))
    out))

;; @syntax (split-string str)
;; @description Generate all the splits of a string in order
;; @param <str> string
;; @return list of splits
;; @example
;; (split-string "123")  ==> ("123" "12 3" "1 23" "1 2 3")
(define (split-string str)
"Generate all the splits of a string in order"
(if (= (length str) 1) (list (list str))
  ;else
  (local (out len max-tagli taglio fmt cur-str)
    (setq out '())
    (setq len (length str))
    ; numero massimo di tagli
    (setq max-tagli (- len 1))
    ; formattazione con 0 davanti
    (setq fmt (string "%0" max-tagli "s"))
    (for (i 0 (- (pow 2 max-tagli) 1))
      ; taglio corrente
      (setq taglio (format fmt (bits i)))
      ; taglia la stringa con taglio corrente
      (setq cur-str (split-aux str taglio))
      ; inserisce la stringa tagliata corrente nella soluzione
      (push cur-str out -1))
    out)))

;; @syntax (split-list lst)
;; @description Generate all the splits of a list in order
;; @param <lst> list
;; @return list of splits
;; @example
;; (split-list '(1 2 3))  ==> (((1 2 3)) ((1 2) (3)) ((1) (2 3)) ((1) (2) (3)))
(define (split-list lst)
(if (= (length lst) 1) (list lst)
  ;else
"Generate all the splits of a list in order"
  (local (out len max-tagli taglio fmt cur-lst)
    (setq out '())
    (setq len (length lst))
    ; numero massimo di tagli
    (setq max-tagli (- len 1))
    ; formattazione con 0 davanti
    (setq fmt (string "%0" max-tagli "s"))
    (for (i 0 (- (pow 2 max-tagli) 1))
      ; taglio corrente
      (setq taglio (format fmt (bits i)))
      ; taglia la lista con taglio corrente
      (setq cur-lst (split-list-aux lst taglio))
      ; e la inserisce nella lista soluzione
      (push cur-lst out -1))
    out)))
; Auxiliary function
(define (split-list-aux lst binary)
  (local (out tmp)
    (setq out '())
    (setq tmp '())
    (for (i 0 (- (length binary) 1))
      (cond ((= (binary i) "1") ; taglio
              (push (lst i) tmp -1)
              (push tmp out -1)
              (setq tmp '()))
            (true  ; nessun taglio
              (push (lst i) tmp -1))))
    ; inserisce lista finale
    (push (lst -1) tmp -1)
    (push tmp out -1)
    out))

;===========================================================================
;===========================================================================
;; <p><b><center>COMBINATORICS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (perm lst)
;; @description Generate all permutations without repeating from a list of items
;; @param <lst> list of items
;; @return list of permutations (without repetition)
;; @example
;; (perm '(a b c))  ==> ((a b c) (b a c) (c a b) (a c b) (b c a) (c b a))
;; (perm '(a b b))  ==> ((a b b) (b a b) (b a b) (a b b) (b b a) (b b a))
;; (length (perm '(0 1 2 3 4 5 6 7 8 9)))  ==> 36628800
(define (perm lst)
"Generate all permutations without repeating from a list of items"
  (local (i indici out)
    (setq indici (dup 0 (length lst)))
    (setq i 0)
    ; aggiungiamo la lista iniziale alla soluzione
    (setq out (list lst))
    (while (< i (length lst))
      (if (< (indici i) i)
          (begin
            (if (zero? (% i 2))
              (swap (lst 0) (lst i))
              (swap (lst (indici i)) (lst i)))
            (push lst out -1)
            (++ (indici i))
            (setq i 0))
          (begin
            (setf (indici i) 0)
            (++ i))))
    out))

;; @syntax (perm-rep k lst)
;; @description Generate all permutations of k elements with repetition from a list of items
;; @param <k> number of items of each permutation
;; @param <lst> list of items
;; @return list of permutations. Number of elements = (pow (length lst) k)
;; @example
;; (perm-rep 2 '(a b c))  ==> ((a a) (b a) (c a) (a b) (b b) (c b) (a c) (b c) (c c))
;; (perm-rep 2 '(a b b))  ==> ((a a) (b a) (b a) (a b) (b b) (b b) (a b) (b b) (b b))
(define (perm-rep k lst)
"Generate all permutations of k elements with repetition from a list of items"
  (if (zero? k) '(())
      (flat (map (lambda (p) (map (lambda (e) (cons e p)) lst))
                         (perm-rep (- k 1) lst)) 1)))

;; @syntax (perm-alternate lst1 lst2 all)
;; @description Generates all permutations in which the elements of two lists alternate (the shorter one is cyclically lengthened)
;; @param <lst1> first list
;; @param <lst2> second list
;; @param <all> if true, use permutations with repetition for the second list
;; @return list of alternate permutations
;; @example
;; (perm-alternate '(1 2) '(a b))
;; ==> ((1 a 2 b) (1 b 2 a) (2 a 1 b) (2 b 1 a))
;; (perm-alternate '(1 2) '(a b) true)
;; ==> ((1 a 2 a) (1 b 2 a) (1 a 2 b) (1 b 2 b)
;; ==>  (2 a 1 a) (2 b 1 a) (2 a 1 b) (2 b 1 b))
;; (perm-alternate '(1 2 3) '(a b))
;; ==> ((1 a 2 b 3 a) (1 b 2 a 3 b) (2 a 1 b 3 a) (2 b 1 a 3 b) (3 a 1 b 2 a)
;; ==>  (3 b 1 a 2 b) (1 a 3 b 2 a) (1 b 3 a 2 b) (2 a 3 b 1 a) (2 b 3 a 1 b)
;; ==>  (3 a 2 b 1 a) (3 b 2 a 1 b))
;; (perm-alternate '(1 2) '(a b c))
;; ==> ((1 a 2 b 1 c) (1 b 2 a 1 c) (1 c 2 a 1 b) (1 a 2 c 1 b) (1 b 2 c 1 a)
;; ==>  (1 c 2 b 1 a) (2 a 1 b 2 c) (2 b 1 a 2 c) (2 c 1 a 2 b) (2 a 1 c 2 b)
;; ==>  (2 b 1 c 2 a) (2 c 1 b 2 a))
(define (perm-alternate lst1 lst2 all)
"Generates all permutations in which the elements of two lists alternate"
  (local (out len1 len2 more more2 permute1 permute2)
    (setq out '())                     ; lista dei risultati
    (setq len1 (length lst1))
    (setq len2 (length lst2))
    (setq more1 nil)                  ; indica se lst1 è più lunga
    (setq more2 nil)                  ; indica se lst2 è più lunga
    ;; Determina quale lista va estesa ciclicamente
    (if (> len1 len2) (setq more2 true))
    (if (< len1 len2) (setq more1 true))
    ;; Permutazioni della prima lista
    (setq permute1 (perm lst1))
    ;; Permutazioni della seconda lista (con o senza ripetizione)
    (if all
        (setq permute2 (perm-rep (length lst2) lst2))  ; con ripetizione
        (setq permute2 (perm lst2)))                   ; senza ripetizione
    ;; Combina ogni coppia di permutazioni
    (dolist (p1 permute1)
      (dolist (p2 permute2)
        ;; Allunga la lista più corta per poter alternare gli elementi
        (cond (more1 (setq p1
                     (slice (extend p1 (flat (dup p1 (/ len2 len1)))) 0 len2)))
              (more2 (setq p2
                     (slice (extend p2 (flat (dup p2 (/ len1 len2)))) 0 len1))))
        ;; Intercala p1 e p2: (map list p1 p2) produce ((x1 y1) (x2 y2) ...)
        ;; 'flat' la rende (x1 y1 x2 y2 ...)
        (push (flat (map list p1 p2)) out -1)))
    ;; Se con ripetizione, elimina i duplicati
    (if all (unique out) out)))

;; @syntax (perm-circ lst)
;; @description Generate all circular permutations without repetition from a list of items
;; @param <lst> list of items
;; @return list of circular permutations
;; @example
;; (perm-circ '(A B C))    ==> ((A B C) (A C B))
;; (perm-circ '(A A C))    ==> ((A A C) (A C A))
;; (perm-circ '(A B C D))  ==> ((A B C D) (A B D C) (A C B D) (A C D B) (A D B C) (A D C B))
(define (perm-circ lst)
"Generate all circular permutations without repetition from a list of items"
  (let (head (pop lst))
    (sort (map (fn(x) (push head x)) (sort (perm lst))))))

;; @syntax (dism lst)
;; @description Generate all dismutations without repeating from a list of items
;; @param <lst> list of items
;; @return list of dismutations (without repetition)
;; @example
;; (dism '(A B C D))  ==> ((B D A C) (D A B C) (B A D C) (C A D B) (C D A B) (D C A B) (D C B A) (C D B A) (B C D A))
;; (length (dism '(0 1 2 3 4 5 6 7 8 9)))  ==> 1334961
(define (dism lst)
"Generate all dismutations without repeating from a list of items"
  (local (i indici out base)
    ; lista originale
    (setq base lst)
    (setq indici (dup 0 (length lst)))
    (setq i 0)
    ; non aggiungiamo la lista iniziale alla soluzione
    ; perchè non è una dismutazione
    ; (setq out (list lst))
    (setq out '())
    (while (< i (length lst))
      (if (< (indici i) i)
          (begin
            (if (zero? (% i 2))
              (swap (lst 0) (lst i))
              (swap (lst (indici i)) (lst i)))
            ;(println lst)
            ; inseriamo la permutazione corrente solo se ogni elemento
            ; non appare nella sua posizione originale
            (if (dis?)
              (push lst out -1))
            (++ (indici i))
            (setq i 0))
          (begin
            (setf (indici i) 0)
            (++ i))))
    out))
; auxiliary function
(define (dis?)
(catch
  (let (ok true)
    (dolist (el lst)
      (if (= el (base $idx))
        (throw nil)))
    ok)))

;; @syntax (comb k lst)
;; @description Generate all combinations of k elements without repetition from a list of items
;; @param <lst> list of elements
;; @return list of combinations without repetition
;; @example
;; (comb 2 '(1 2 3 4))  ==> ((1 2) (1 3) (1 4) (2 3) (2 4) (3 4))
;; (comb 3 '(1 2 3 4))  ==> ((1 2 3) (1 2 4) (1 3 4) (2 3 4))
;; (comb 1 '(a b c))    ==> ((a) (b) (c))
;; (comb 2 '(a b c))    ==> ((a b) (a c) (b c))
;; (comb 3 '(a b c))    ==> ((a b c))
;; (comb 3 '(1 2))      ==> ()
(define (comb k lst (r '()))
"Generate all combinations of k elements without repetition from a list of items"
  (if (= (length r) k)
    (list r)
    (let (rlst '())
      (dolist (x lst)
        (extend rlst (comb k ((+ 1 $idx) lst) (append r (list x)))))
      rlst)))
; Alternative version (slower)
;(define (comb k lst)
;"Generate all combinations of k elements without repetition from a list of items"
;  (cond ((zero? k)   '(()))
;        ((null? lst) '())
;        (true
;          (append (map (lambda (k-1) (cons (first lst) k-1))
;                       (comb (- k 1) (rest lst)))
;                  (comb k (rest lst))))))

;; @syntax (comb-rep k lst)
;; @description Generate all combinations of k elements with repetition from a list of items
;; @param <lst> list of elements
;; @return list of combinations with repetition
;; @example
;; (comb-rep 2 '(a b))      ==> ((a a) (a b) (b b))
;; (comb-rep 2 '(1 2 3 4))  ==> ((1 1) (1 2) (1 3) (1 4) (2 2) (2 3) (2 4) (3 3) (3 4) (4 4))
;; (comb-rep 2 '(1 2 3))    ==> ((1 1) (1 2) (1 3) (2 2) (2 3) (3 3))
;; (comb-rep 3 '(1 2 3))    ==> ((1 1 1) (1 1 2) (1 1 3) (1 2 2) (1 2 3) (1 3 3) (2 2 2) (2 2 3) (2 3 3) (3 3 3))
(define (comb-rep k lst)
"Generate all combinations of k elements with repetition from a list of items"
  (cond ((zero? k 0) '(()))
        ((null? lst) '())
        (true
         (append (map (lambda (x) (cons (first lst) x))
                      (comb-rep (- k 1) lst))
                 (comb-rep k (rest lst))))))

;; @syntax (comb-list lst)
;; @description Generate all combinations by choosing one element from each sublist
;; @param <lst> list of lists of elements
;; @return list of combinations with one element from each sublist
;; @example
;; (comb-list '((-1 2) (1 -2)))  ==> ((-1 1) (-1 -2) (2 1) (2 -2))
;; (comb-list '((1 2 3) (4 5 6) (7 8)))  ==> ((1 4 7) (1 4 8) (1 5 7) (1 5 8) (1 6 7) (1 6 8)
;;                                            (2 4 7) (2 4 8) (2 5 7) (2 5 8) (2 6 7) (2 6 8)
;;                                            (3 4 7) (3 4 8) (3 5 7) (3 5 8) (3 6 7) (3 6 8))
;; (comb-list '((1 2) () (3 4)))  ==> ()
(define (comb-list lst)
"Generate all combinations by choosing one element from each sublist"
  (letn ( (len (length lst))
          (out '())
          (stack (list (list 0 '()))) )
    (while (not (null? stack))
      (letn ( (stato (pop stack))
              (r (stato 0))
              (sel (stato 1)) )
        (if (= r len)
            (push (reverse sel) out)
            ;else
            (dolist (v (lst r))
              (push (list (+ r 1) (cons v sel)) stack)))))
    out))

;; @syntax (partition lst)
;; @description Generate all the partitions of a list
;; @param <lst> list
;; @return list of partition (list)
;; @example
;; (partition '(1 2 3))  ==> (((1 2 3)) ((1 2) (3)) ((1) (2 3)) ((1) (2) (3)))
(define (partition lst)
"Generate all the partitions of a list"
  (if (= (length lst) 1) (list lst)
    (local (out len max-tagli taglio fmt)
      (setq out '())
      (setq len (length lst))
      ; numero massimo di tagli
      (setq max-tagli (- len 1))
      ; formattazione con 0 davanti
      (setq fmt (string "%0" max-tagli "s"))
      (for (i 0 (- (pow 2 max-tagli) 1))
        ; taglio corrente
        (setq taglio (format fmt (bits i)))
        ; taglia la lista con taglio corrente
        ; e la inserisce nella lista soluzione
        (push (partition-aux lst taglio) out -1))
    out)))
; Auxiliary function for (partition lst)
(define (partition-aux lst binary)
  (local (out tmp)
    (setq out '())
    (setq tmp '())
    (for (i 0 (- (length binary) 1))
      (cond ((= (binary i) "1") ; taglio
              (push (lst i) tmp -1)
              (push tmp out -1)
              (setq tmp '()))
            (true  ; nessun taglio
              (push (lst i) tmp -1))))
    ; inserisce lista finale
    (push (lst -1) tmp -1)
    (push tmp out -1)
    out))

;; @syntax (group-half lst)
;; @description Generate all partitions of a set into two disjoint, complementary sublists of size (N/2, N/2) (or (N/2, (N/2 + 1))
;; @param <lst> list of elements
;; @return list of all different groups
;; @example
;; (group-half '(4 3 2 1))  ==> (((1 2) (3 4)) ((1 3) (2 4)) ((1 4) (2 3)))
;; (group-half '(a b c d))  ==> (((a b) (c d)) ((a c) (b d)) ((a d) (b c)))
;; (group-half '("sara" "mario" "luca" "max" "maria"))
;; ==> ((("luca" "maria") ("mario" "max" "sara"))
;;      (("luca" "mario") ("maria" "max" "sara"))
;;      (("luca" "max") ("maria" "mario" "sara"))
;;      (("luca" "sara") ("maria" "mario" "max")))
(define (group-half lst)
"Generate all partitions into of a set two disjoint, complementary sublists of size (N/2, N/2) (or (N/2, (N/2 + 1))"
; The elements must be unique. Otherwise use the values of indexes.
  (sort lst) ; ordina la lista per avere ordine coerente nelle partizioni
  (letn ((N (length lst))
         (meta (/ N 2))
         (combinazioni (comb meta lst))
         (out '()))
    (dolist (c combinazioni)
      (let (resto (difference lst c)) ; resto degli elementi della lista
        ; evita duplicati
        (if (< (join (map string c)) (join (map string resto)))
            (push (list c resto) out -1))))
    out))

;; @syntax (group-all lst)
;; @description Generate all partitions of a set into two disjoint, complementary sublists of size (k, N-k), with 1 ≤ k ≤ floor(N/2)
;; @param <lst> list of unique elements (set)
;; @return list of all different groups
;; @example
;; (group-all '(1 2 3 4))  ==> (((1) (2 3 4)) ((2) (1 3 4)) ((3) (1 2 4)) ((4) (1 2 3)) ((1 2) (3 4)) ((1 3) (2 4)) ((1 4) (2 3)))
;; (group-all '("sara" "mario" "luca" "max" "maria"))
;; ==> ((("luca") ("maria" "mario" "max" "sara"))
;;      (("maria") ("luca" "mario" "max" "sara"))
;;      (("mario") ("luca" "maria" "max" "sara"))
;;      (("max") ("luca" "maria" "mario" "sara"))
;;      (("sara") ("luca" "maria" "mario" "max"))
;;      (("luca" "maria") ("mario" "max" "sara"))
;;      (("luca" "mario") ("maria" "max" "sara"))
;;      (("luca" "max") ("maria" "mario" "sara"))
;;      (("luca" "sara") ("maria" "mario" "max"))
;;      (("maria" "mario") ("luca" "max" "sara"))
;;      (("maria" "max") ("luca" "mario" "sara"))
;;      (("maria" "sara") ("luca" "mario" "max"))
;;      (("mario" "max") ("luca" "maria" "sara"))
;;      (("mario" "sara") ("luca" "maria" "max"))
;;      (("max" "sara") ("luca" "maria" "mario")))
;; (length (group-all '(a b c d e f g h i j)))  ==> 511
(define (group-all lst)
"Generate all partitions of a set into two disjoint, complementary sublists of size (k, N-k), with 1 ≤ k ≤ floor(N/2)"
; The elements must be unique. Otherwise use the values of indexes.
  (sort lst) ; ordina la lista per avere ordine coerente nelle partizioni
  (letn ((N (length lst))
         (out '())    ; lista finale di partizioni
         (visti '())) ; lista delle partizioni già viste (come chiavi stringa)
    ; prova tutti i valori di k da 1 a floor(N/2)
    (for (k 1 (/ N 2))
      ; per ogni combinazione c di k elementi da lst
      (dolist (c (comb k lst))
        (letn (
          (resto (difference lst c)) ; ottiene il complemento di c
          ; converte le due sottoliste in stringhe
          (k1 (join (map string c)))
          (k2 (join (map string resto)))
          ; ordina le due rappresentazioni per ottenere una chiave canonica
          (chiave (sort (list k1 k2))))
          ; se la chiave non è già stata vista, la aggiunge
          (unless (ref chiave visti)
            (push chiave visti -1)
            (push (list c resto) out -1)))))
    out)) ; restituisce la lista delle partizioni uniche

;; @syntax (groups parts lst)
;; @description Group the elements of a set into disjoint sublists
;; @param <parts> list of number of parts
;; @param <lst> list of elements
;; @return list of all different groups
;; @example
;; (groups '(1 2 1) '(luca eva tommy roby)) ==>
;; (((luca) (eva tommy) (roby)) 
;;  ((luca) (eva roby) (tommy))
;;  ((luca) (tommy roby) (eva))
;;  ((eva) (luca tommy) (roby))
;;  ((eva) (luca roby) (tommy))
;;  ((eva) (tommy roby) (luca))
;;  ((tommy) (luca eva) (roby))
;;  ((tommy) (luca roby) (eva))
;;  ((tommy) (eva roby) (luca))
;;  ((roby) (luca eva) (tommy))
;;  ((roby) (luca tommy) (eva))
;;  ((roby) (eva tommy) (luca)))
(define (groups parts lst)
"Group the elements of a set into disjoint sublists"
; The elements must be unique. Otherwise use the values of indexes.
  (if (!= (apply + parts) (length lst))
      nil
      (if (null? parts)
          '(())
          (let (out '())
            (dolist (c (comb (first parts) lst))
              (dolist (g (groups (rest parts)
                                 (remove-items lst c)))
                (push (cons c g) out -1)))
            out))))
; OLD VERSION
;(define (groups parts lst)
;"Group the elements of a set into disjoint sublists"
;  (local (tmp out)
;    ;------------------------
;    (define (loop parts xss lst)
;      (cond ((null? parts) xss)
;            ((null? xss) '())
;            (true
;            (letn ((xs (first xss)) (leftover (filter (lambda (e) (not (member e xs))) lst)))
;              ;(append (map (lambda (ys) (list xs ys)))
;              (append (map (lambda (ys) (flat (list xs ys)))
;                            (loop (rest parts) (comb (first parts) leftover) leftover))
;                      (loop parts (rest xss) lst))))))
;    ;------------------------
;    (setq tmp (loop (rest parts) (comb (first parts) lst) lst))
;    (setq out '())
;    (dolist (g tmp)
;      (push (list-break g parts) out -1))
;    out))

;; @syntax (binom num k)
;; @description Calculate the binomial coefficient (n k) = n!/(k!*(n - k)!) (combinations of k elements without repetition from n elements)
;; @param <num> number of elements (int)
;; @param <k> number of items of each combination
;; @return binomial coefficient (int)
;; @example
;; (binom 5 2)    ==> 10
;; (binom 100 5)  ==> 75287520
;; (binom 0 0)    ==> 1
;; (binom 3 0)    ==> 1
;; (binom 0 3)    ==> 0
(define (binom num k)
"Calculate the binomial coefficient (n k) = n!/(k!*(n - k)!) (combinations of k elements without repetition from n elements)"
  (cond ((> k num) 0L)
        ((zero? k) 1L)
        ((< k 0) 0L)
        (true
          (let (r 1L)
            (for (d 1 k)
              (setq r (/ (* r num) d))
              (-- num))
          r))))

;; @syntax (partition-num num)
;; @description Generate a list of all the partitions of a positive integer
;; @param <num> positive integer number (int)
;; @return list of partition (list of arrays)
;; @example
;; (partition-num 1)           ==> ((1))
;; (partition-num 3)           ==> ((3) (2 1) (1 1 1))
;; (partition-num 5)           ==> ((5) (4 1) (3 2) (3 1 1) (2 2 1) (2 1 1 1) (1 1 1 1 1))
;; (length (partition-num 50)) ==> 204226
(define (partition-num num)
"Generate a list of all the partitions of a positive integer"
(catch
  (local (part k temp-value out)
    (setq out '())
    (setq part (array num '(0)))
    (setq k 0)
    (setf (part k) num)
    ; Questo ciclo prima aggiunge la partizione corrente alla lista
    ; poi genera la partizione successiva.
    ; Il ciclo termina quando la partizione corrente è costituita da tutti 1.
    (while true
      ; Aggiunge la partizione corrente alla lista delle soluzioni
      (push (slice part 0 (+ k 1)) out -1)
      ; Genera la partizione successiva
      ; Trova il valore non-uno più a destra di part[]
      ; Aggiorna anche il valore di temp-value
      ; (cioè quanti valori possono essere inseriti)
      (setq temp-value 0)
      (while (and (>= k 0) (= (part k) 1))
        (setq temp-value (+ temp-value (part k)))
        (-- k))
      ; se k < 0, tutti i valori valgono 1
      ; quindi non ci sono altre partizioni da generare
      (if (< k 0) (throw out))
      ; Decrementa part[k] trovato sopra e calcola il valore di temp-value
      (setf (part k) (- (part k) 1))
      (++ temp-value)
      ; Se rem_val è maggiore, allora l'ordine è violato.
      ; Divide temp-value in diversi valori di dimensione part[k] e
      ; copia questi valori in posizioni diverse dopo part[k]
      (while (> temp-value (part k))
        (setf (part (+ k 1)) (part k))
        (setq temp-value (- temp-value (part k)))
        (++ k))
      ; Copia rem_val nella posizione successiva e incrementa la posizione
      (setf (part (+ k 1)) temp-value)
      (++ k)))))

;; @syntax (partition-numbers num)
;; @description Calculate a list of all numbers of partitions from 0 to a positive integer
;; @param <num> positive integer number (int)
;; @return list of all numbers of partitions from 0 to num
;; @example
;; (partition-numbers 50)
;; (1 1 2 3 5 7 11 15 22 30 42 56 77 101 135 176 231 297 385 490
;;  627 792 1002 1255 1575 1958 2436 3010 3718 4565 5604 6842
;;  8349 10143 12310 14883 17977 21637 26015 31185 37338 44583
;;  53174 63261 75175 89134 105558 124754 147273 173525 204226)
(define (partition-numbers num)
"Calculate a list of all numbers of partitions from 0 to a positive integer"
  (local (n p-vec segno penta continua i j val)
    (setq p-vec (array (+ num 1) '(0)))
    (setf (p-vec 0) 1)
    (setq continua true)
    (setq n 1)
    (while (<= n num)
      (setq i 0)
      (setq penta 1)
      (while (<= penta n)
        (if (> (% i 4) 1)
            (setq segno -1)
            (setq segno 1))
        (setf (p-vec n) (+ (p-vec n) (* segno (p-vec (- n penta)))))
        (++ i)
        (if (zero? (% i 2))
            (setq j (+ (/ i 2) 1))
            (setq j (- (+ (/ i 2) 1))))
        (setq penta (/ (* j (- (* 3 j) 1)) 2)))
      (++ n))
    p-vec))

;===========================================================================
;===========================================================================
;; <p><b><center>NUMBER THEORY</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (fact-i num)
;; @description Calculate the factorial of an integer number
;; @param <num> positive integer (int)
;; @return factorial (bigint)
;; @example
;; (fact-i 3)   ==> 6L
;; (fact-i 30)  ==> 265252859812191058636308480000000L
(define (fact-i num)
"Calculate the factorial of an integer number"
  (if (zero? num)
      1
      (let (out 1L)
        (for (x 1L num)
          (setq out (* out x))))))
; versione alternativa
; (define (fact-i num) (if (= num 0) 1 (apply * (map bigint (sequence 1 num)))))

;; @syntax (fact-i-arr num)
;; @description Create an array of factorials for numbers 0..num
;; @param <num> integer
;; @return list of factorials 0!..N!
;; @example
;; (fact-i-arr 6)  ==> (1L 1L 2L 6L 24L 120L 720L)
;; (time (fact-i-arr 1e5))  ==> 12001.064
(define (fact-i-arr num)
"Create an array of factorials for numbers 0..num"
(let ( (f (array (+ num 1) '(0L))) (val 1L) )
  (setf (f 0) 1L)
  (for (x 1 num)
    (setq val (* val x))
    (setf (f x) val))
  f))

;; @syntax (fibo-i num)
;; @description Calculate the Fibonacci number of an integer number
;; @param <num> positive integer (int)
;; @return fibonacci number (bigint)
;; @example
;; (fibo-i 3)   ==> 2L
;; (fibo-i 30)  ==> 832040L
;; (fibo-i 100) ==> 354224848179261915075L
;; (map fibo-i (sequence 0 10))  ==> (0L 1L 1L 2L 3L 5L 8L 13L 21L 34L 55L)
(define (fibo-i num)
"Calculate the Fibonacci number of an integer number"
  (if (zero? num) 0L
  ;else
  (local (a b c)
    (setq a 0L b 1L c 0L)
    (for (i 0 (- num 1))
      (setq c (+ a b))
      (setq a b)
      (setq b c))
    a)))

;; @syntax (collatz num)
;; @description Generate the collatz sequence of a positive integer number
;; @param <num> positive integer (int)
;; @return list of integer (int)
;; @example
;; (collatz 52) (52 26 13 40 20 10 5 16 8 4 2 1)
(define (collatz n)
"Generate the collatz sequence of a positive integer number"
  (let (out (list n))
    (until (= n 1)
      (if (even? n)
          (setq n (/ n 2))
          (setq n (+ (* 3 n) 1)))
      (push n out -1))
    out))

;; @syntax (collatz-length num)
;; @description Calculate the length of the collatz sequence of a positive integer number
;; @param <num> positive integer (int)
;; @return length of collatz sequence (int)
;; @example
;; (collatz-length 123456789) ==> 178
(define (collatz-length n)
"Calculate the length of the collatz sequence of a positive integer number"
  (let (c 1)
    (until (= n 1)
      (if (even? n)
          (setq n (/ n 2))
          (setq n (+ (* 3 n) 1)))
      (++ c))
    c))

;; @syntax (lcm num1 num2 ... numk)
;; @description Calculate the lcm of two or more number
;; @param <num> integer number (int)
;; @return least common multiple (int)
;; @example
;; (lcm 2 3)             ==> 6
;; (lcm 3 21 4)          ==> 84
;; (lcm 1 2 3 4)         ==> 12
;; (apply lcm '(3 5 7))  ==> 105
(define (lcm_ a b) (/ (* a b) (gcd a b)))
(define-macro (lcm)
"Calculate the lcm of two or more number"
  (apply lcm_ (map eval (args)) 2))

;; @syntax (diofantea a b c)
;; @description Solve a linear Diophantine equation ax + by = c
;; @param <a, b, c> integer
;; @return list ((x0 xp) (y0 yp)) x = x0 + k*xp; y = y0 + k*yp
;; @example
;; (diofantea 8 -6 26)  ==> ((13 -3) (13 -4))
;; x = 13 - 3k  (con k = 0 .. inf)
;; y = 13 – 4k (con k = 0 .. inf)
;; (diofantea 25 10 15) ==> ((3 2) (-6 -5))
;; x = 3 + 2k  (con k = 0 .. inf)
;; y = -6 – 5k (con k = 0 .. inf)
(define (diofantea a b c)
"Solve a linear Diophantine equation ax + by = c"
  (local (gcd-ex-lst g xg yg out)
    (setq out '())
    (setq gcd-ex-lst (gcd-ex a b))
    (setq g (first gcd-ex-lst))
    (setq xg (first (rest gcd-ex-lst)))
    (setq yg (last gcd-ex-lst))
    ;(println g { } xg { } yg)
    (cond ((not (zero? (% c g))) (setq out '()))
          (true
            (setq out (list (list (div (mul xg c) g) (div b g))
                            (list (div (mul yg c) g) (div (- a) g))))))
    out))
; auxiliary function: algoritmo di Euclide esteso
(define (gcd-ex a b)
  (local (x y lastx lasty temp)
    (setq x 0)
    (setq y 1)
    (setq lastx 1)
    (setq lasty 0)
    (while (not (zero? b))
      (setq q (div a b))
      (setq r (% a b))
      (setq a b)
      (setq b r)
      (setq temp x)
      (setq x (- lastx (* q x)))
      (setq lastx temp)
      (setq temp y)
      (setq y (- lasty (* q y)))
      (setq lasty temp))
    ; Adesso la variabile "a" contiene il valore di gcd
    (list a lastx lasty)))

;; @syntax (prime? num)
;; @description Check if a number is prime
;; @param <num> positive integer number (int)
;; @return true or nil
;; @example
;; (prime? 10)   ==> nil
;; (prime? 103)  ==> true
;; (prime? 1)    ==> nil
(define (prime? num)
"Check if a number is prime"
   (if (< num 2) nil
       (= 1 (length (factor num)))))

;; @syntax (factor-group num)
;; @description Factorize an integer number
;; @param <num> positive integer number (int)
;; @return list ((factor-1 exp-1) (factor-2 exp-2) ... (factor-n..exp-n))
;; @example
;; (factor-group 100)  ==> ((2 2) (5 2))
;; (factor-group 103)  ==> ((103 1))
;; (factor-group 1)    ==> nil
(define (factor-group num)
"Factorize an integer number"
  (if (< num 2) nil
      (letn ((out '()) (lst (factor num)) (cur-val (first lst)) (cur-count 0))
        (dolist (el lst)
          (if (= el cur-val) (++ cur-count)
              (begin
                (push (list cur-val cur-count) out -1)
                (setq cur-count 1 cur-val el))))
        (push (list cur-val cur-count) out -1))))
; Versione alternativa
;(define (factor-group num)
;"Factorize an integer number"
;  (if (= num 1) '((1 1))
;    (letn ( (fattori (factor num))
;            (unici (unique fattori)) )
;      (transpose (list unici (count unici fattori))))))

;; @syntax (factor-i num)
;; @description Factorize a big integer number
;; @param <num> positive integer number (bigint)
;; @return list (factor-1 factor-2 ... factor-k) (bigint)
;; @example
;; (factor-i 9223372036854775809L)   ==> (3L 3L 3L 19L 43L 5419L 77158673929L)
;; (factor-i 92233720368547758091L)  ==> (7L 13L 1013557366687338001L)
(define (factor-i num)
"Factorize a big integer number"
  (local (f k i dist out)
    ; Distanze tra due elementi consecutivi della ruota (wheel)
    (setq dist (array 48 '(2 4 2 4 6 2 6 4 2 4 6 6 2 6 4 2 6 4
                           6 8 4 2 4 2 4 8 6 4 6 2 4 6 2 6 6 4
                           2 4 6 2 6 4 2 4 2 10 2 10)))
    (setq out '())
    (while (zero? (% num 2)) (push '2L out -1) (setq num (/ num 2)))
    (while (zero? (% num 3)) (push '3L out -1) (setq num (/ num 3)))
    (while (zero? (% num 5)) (push '5L out -1) (setq num (/ num 5)))
    (while (zero? (% num 7)) (push '7L out -1) (setq num (/ num 7)))
    (setq k 11L i 0)
    (while (<= (* k k) num)
      (if (zero? (% num k))
        (begin
          (push k out -1)
          (setq num (/ num k)))
        (begin
          (setq k (+ k (dist i)))
          (if (< i 47) (++ i) (setq i 0)))))
    (if (> num 1) (push (bigint num) out -1))
    out))

;; @syntax (factorizations num)
;; @description Calculate all the factorizations of an integer number
;; @param <num> positive integer number (int)
;; @return list ((factorizations-1) (factorizations-2) ... (factorizations-n))
;; @example
;; (factorizations 8)               ==> ((2 2 2) (2 4))
;; (factorizations 24)              ==> ((2 2 2 3) (2 2 6) (2 3 4) (2 12) (3 8) (4 6))
;; (factorizations 11)              ==> ()
;; (length (factorizations 12000))  ==> 381
(define (factorizations num)
"Calculate all the factorizations of an integer number"
  (let (afc '())
    (factorizations-aux num '() num)))
; funzione ausiliaria
(define (factorizations-aux num parfac parval)
  (let ((newval parval) (i (- num 1)))
    (while (>= i 2)
      (cond ((zero? (% num i))
              (if (> newval 1) (setq newval i))
              (if (and (<= (/ num i) parval) (<= i parval) (>= (/ num i) i))
                  (begin
                    (push (append parfac (list i (/ num i))) afc -1)
                    (setq newval (/ num i))))
              (if (<= i parval)
                  (factorizations-aux (/ num i) (append parfac (list i)) newval))))
      (-- i))
    (sort (unique (map sort afc)))))

;; @syntax (primes num)
;; @description Generate a given number of prime numbers (starting from 2)
;; @param <num> positive integer number (int)
;; @return list of primes (prime-1 prime-2 ... prime-num)
;; @example
;; (primes 10) ==> (2 3 5 7 11 13 17 19 23 29)
;; (time (primes 1e5))  ==> 604
(define (primes num-primes)
"Generate a given number of prime numbers (starting from 2)"
  (let ( (k 3) (tot 1) (out '(2)) )
    (until (= tot num-primes)
      (when (= 1 (length (factor k)))
        (push k out -1)
        (++ tot))
      (++ k 2))
    out))

;; @syntax (primes-to num)
;; @description Generate all prime numbers less than or equal to a given number
;; @param <num> positive integer number (int)
;; @return list of primes (prime-1 prime-2 ... prime-k)
;; @example
;; (primes-to 10)  ==> (2 3 5 7)
;; (primes-to 77)  ==> (2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73)
;; (primes-to 1)   ==> ()
;; (primes-to 2)   ==> (2)
;(define (primes-to num)
;"Generate all prime numbers less than or equal to a given number"
;  (cond ((< num 2) '())
;        ((< num 3) '(2))
;        (true
;          (letn ((m (/ (- num 3) 2))
;                 (arr (array (+ m 1)))
;                 (lim (/ (- (int (sqrt num)) 3) 2))
;                 (lst '(2)))
;            (for (i 0 lim)
;              (when (nil? (arr i))
;                (letn ((p (+ (* 2 i) 3))
;                       (j (/ (- (* p p) 3) 2)))
;                  (for (k j m p (> k m))
;                    (setf (arr k) true)))))
;            (for (i 0 m)
;              (when (nil? (arr i))
;                (push (+ (* 2 i) 3) lst -1)))
;            lst))))

(define (primes-to num)
"Generate all prime numbers less than or equal to a given number"
  (cond ((= num 1) '())
        ((= num 2) '(2))
        (true
          (let ((lst '(2)) (arr (array (+ num 1))))
            (for (x 3 num 2)
              (when (not (arr x))
                (push x lst -1)
                (for (y (* x x) num (* 2 x) (> y num))
                  (setf (arr y) true)))) lst))))

;; @syntax (primes-to-count num)
;; @description Calculate the number of primes less than or equal to a given number
;; @param <num> positive integer number (int)
;; @return number of primes (int)
;; @example
;; (primes-to-count 10)   ==> 4
;; (primes-to-count 77)   ==> 21
;; (primes-to-count 1)    ==> 0
;; (primes-to-count 2)    ==> 1
;; (primes-to-count 1e7)  ==> 664579
(define (primes-to-count num)
"Calculate the number of primes less than or equal to a given number"
  (cond ((< num 2) 0)
        ((= num 2) 1)
        (true
         (let (np 1)
         (setq arr (array (+ num 1)))
         (for (x 3 num 2)
              (when (not (arr x))
                (++ np)
                (for (y (* x x) num (* 2 x) (> y num))
                     (setf (arr y) true)))) np))))

;; @syntax (primes-range n1 n2)
;; @description Generate all prime numbers in the interval [n1..n2]
;; @param <n1> lower limit of interval (int)
;; @param <n2> upper limit of interval (int)
;; @return list of primes
;; @example
;; (primes-range 10 100)  ==> (11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97)
;; (length (primes-range 1e3 1e5))  ==> 9424
(define (primes-range n1 n2)
"Generate all prime numbers in the interval [n1..n2]"
  (if (> n1 n2) (swap n1 n2))
  (cond ((= n2 1) '())
        ((= n2 2) '(2))
        (true
          (let ((lst '(2)) (arr (array (+ n2 1))))
            ; initialize lst
            (if (> n1 2) (setq lst '()))
            (for (x 3 n2 2)
              (when (not (arr x))
                ; push current primes (x) only if > n1
                (if (>= x n1) (push x lst -1))
                (for (y (* x x) n2 (* 2 x) (> y n2))
                  (setf (arr y) true)))) lst))))

;; @syntax (twins N)
;; @description Check if two numbers have the same digits
;; @param <num> positive integer
;; @return list of twins primes
;; @example
;; (twins 100)  ==> ((3 5) (5 7) (11 13) (17 19) (29 31) (41 43) (59 61) (71 73))
(define (twins num)
"Generate twins primes less than or equal to a given number"
  (local (out primi len)
    (setq out '())
    (setq primi (primes-to num))
    ; numero di primi
    (setq len (length primi))
    ; lista delle differenze tra coppie di primi adiacenti
    (setq diff (map - (rest primi) (chop primi)))
    ; trasforma la lista in vettore (indicizzazione più veloce)
    (setq primi (array len primi))
    ; ciclo sulla lista delle differenze
    (dolist (d diff)
      ; se la differenza corrente vale 2,
      ; allora recupera dal vettore i relativi gemelli
      ; e li inserisce nella soluzione
      (if (= d 2) (push (list (primi $idx) (primi (+ $idx 1))) out -1)))
    out))

;; @syntax (prime-pairs n1 n2)
;; @description Generate pairs of twin primes in the interval [n1..n2]
;; @param <n1> lower limit of interval (int)
;; @param <n2> upper limit of interval (int)
;; @return list of twin primes
;; @example
;; (prime-pairs 3 30)             ==> ((3 5) (5 7) (11 13) (17 19))
;; (length (prime-pairs 3 1000))  ==> 35
(define (prime-pairs n1 n2)
"Generate pairs of twin primes in the interval [n1..n2]"
  (let ((out (list)) (x nil) (FX (* 2 3 5 7 11 13)) (M 0))
    (for (y (if (odd? n1) n1 (inc n1)) n2 2)
      (if (if (< y FX) (1 (factor y))
             (or (= (setf M (% y FX))) (if (factor M) (<= ($it 0) 13)) (1 (factor y))))
        (setf y nil)
        x (push (list x y) out -1))
      (setf x y))
    out))

;; @syntax (coprime? num1 num2)
;; @description Check if two integer are coprime
;; @param <num1> integer number (int)
;; @param <num2> integer number (int)
;; @return true or nil
;; @example
;; (coprime? 10 11)  ==> true
;; (coprime? 10 5)   ==> nil
;; (coprime? 11 29)  ==> true
(define (coprime? a b)
"Check if two integer are coprime"
  (= (gcd a b) 1))

;; @syntax (divisors num)
;; @description Generate all the divisors of an integer number
;; @param <num> positive integer number (int)
;; @return list (divisor(1) divisor(2) ... divisor(k))
;; @example
;; (divisors 1)          ==> (1)
;; (divisors 360)        ==> (1 2 3 4 5 6 8 9 10 12 15 18 20 24 30 36 40 45 60 72 90 120 180 360)
;; (divisors 123456789)  ==> (1 3 9 3607 3803 10821 11409 32463 34227 13717421 41152263 123456789)
(define (divisors num)
"Generate all the divisors of an integer number"
  (local (f out)
    (cond ((= num 1) '(1))
          (true
           (setq f (factor-group num))
           (setq out '())
           (divisors-aux 0 1)
           (sort out)))))
; auxiliary function
(define (divisors-aux cur-index cur-divisor)
  (cond ((= cur-index (length f))
         (push cur-divisor out -1))
        (true
         (for (i 0 (f cur-index 1))
           (divisors-aux (+ cur-index 1) cur-divisor)
           (setq cur-divisor (* cur-divisor (f cur-index 0)))))))

;; @syntax (divisors-count num)
;; @description Count the divisors of an integer number
;; @param <num> positive integer number (int)
;; @return count of divisors (int)
;; @example
;; (divisors-count 1)          ==> 1
;; (divisors-count 360)        ==> 24
;; (divisors-count 123456789)  ==> 12
(define (divisors-count num)
"Count the divisors of an integer number"
  (if (= num 1)
      1
      (let (lst (factor-group num))
        (apply * (map (fn(x) (+ 1 (last x))) lst)))))

;; @syntax (divisors-sum num)
;; @description Sum all the divisors of integer number
;; @param <num> positive integer number (int)
;; @return sum of divisors (int)
;; @example
;; (divisors-sum 1)          ==> 1
;; (divisors-sum 360)        ==> 1170
;; (divisors-sum 123456789)  ==> 178422816
(define (divisors-sum num)
"Sum all the divisors of integer number"
  (local (sum out)
    (if (= num 1)
        1
        (begin
          (setq out 1)
          (setq lst (factor-group num))
          (dolist (el lst)
            (setq sum 0)
            (for (i 0 (last el))
              (setq sum (+ sum (pow (first el) i))))
            (setq out (* out sum)))))))

;; @syntax (totient num)
;; @description Calculate the eulero totient of a given number
;; @param <num> positive integer number (int)
;; @return totient (int)
;; @example
;; (totient 9223372036854775807)  ==> 7713001620195508224
;; (totient 222)                  ==> 72
;; (totient 123456)               ==> 41088
(define (totient num)
"Calculate the eulero totient of a given number"
  (if (= num 1) 1
    (let (res num)
      (dolist (f (unique (factor num)))
        (setq res (- res (/ res f))))
      res)))
; Alternative version
; (define (totient num)
; "Compute the Euler's Totient of a number"
;     (if (= num 1) 1
;     (round (mul num (apply mul (map (fn (x) (sub 1 (div 1 x))) (unique (factor num))))) 0)))

;; @syntax (totients-to num)
;; @description Calculate totients for all numbers less than or equal to a given number
;; @param <num> positive integer number (int)
;; @return array of integer totient (totient-1 totient-2 ... totient-num)
;; @example
;; (totients-to 10)  ==> (1 1 2 2 4 2 6 4 6 4)
(define (totients-to num)
"Calculate totients for all numbers less than or equal to a given number"
  (let (phi (array (+ num 1) '(0)))
    (setf (phi 0) 0)
    (setf (phi 1) 1)
    (for (i 2 num)
      (setf (phi i) i))
    (for (i 2 num)
      (if (= (phi i) i)
          (for (j i num i)
            (setf (phi j) (- (phi j) (/ (phi j) i))))))
    phi))

;; @syntax (totient-big num)
;; @description Calculate the eulero totient of a given big-integer number
;; @param <num> positive integer number (big-int)
;; @return totient (big-int)
;; @example
;; (totient-big 222)                   ==> 72
;; (totient-big 123456)                ==> 41088
;; (totient-big 9223372036854775807)   ==> 7713001620195508224
;; (totient-big 9223372036854775808L)  ==> 4611686018427387904L
(define (totient-big num)
"Calculate the eulero totient of a given big-integer number"
  (if (= num 1) 1
    (let ((res num) (i 2L))
      (while (<= (* i i) num)
        (if (zero? (% num i))
            (begin
              (while (zero? (% num i))
                (setq num (/ num i)))
              (setq res (- res (/ res i)))))
        (++ i))
      (if (> num 1)
        (setq res (- res (/ res num))))
      res)))

;; @syntax (chinese lst-div lst-rem)
;; @description Apply the chinese remainder theorem to solve a congruence system
;; @param <lst-div> list of divisors (int)
;; @param <lst-rem> list of remainders (int)
;; @return solution x + k*y as list: (x=solution-base y=multiplier) (int int)
;; @example
;; (chinese '(3 5 7) '(2 3 2))  ==> (23 105)
;; (chinese '(5 8 7) '(1 7 6))  ==> (111 280)
(define (chinese lst-div lst-rem)
"Apply the chinese remainder theorem to solve a congruence system"
    ;se tutte le coppie di numeri sono coprimi tra loro
    ;(minimo comune multiplo(numeri) = prodotto(numeri))
    (if (= (apply * lst-div) (apply lcm lst-div))
        ;allora cerchiamo la soluzione
        (chinese_solve lst-div lst-rem)
        ; altrimenti nessuna soluzione
        nil))
(define (chinese_solve lst-div lst-rem)
  (local (p prod sum)
    (setq prod 1 sum 0)
    (for (i 0 (- (length lst-div) 1))
      (setq prod (* prod (lst-div i))))
    (for (i 0 (- (length lst-div) 1))
      (setq p (/ prod (lst-div i)))
      (setq sum (+ sum (* (lst-rem i) (mul-inv p (lst-div i)) p))))
    (list (% sum prod) prod)))
; Restituisce il valore di x, dove (a * x) % b == 1
(define (mul-inv a b)
  (local (b0 t q x0 x1)
    (setq b0 b x0 0 x1 1)
    (cond ((= b 1) 1)
          (true
            (while (> a 1)
              (setq q (/ a b))
              (setq t b b (% a b) a t)
              (setq t x0 x0 (- x1 (* q x0)) x1 t))
            (if (< x1 0) (setq x1 (+ x1 b0)))
            x1))))

;; @syntax (pow-i num power)
;; @description Calculate the integer power of an integer
;; @param <num> integer number (int)
;; @param <power> integer power (int)
;; @return power of integer (int)
;; @example
;; (pow-i 10 3)     ==> 1000
;; (pow-i -2 -2)    ==> 4
;; (pow-i 21 201)   ==> -5893659389473055499 (overflow)
;; (pow-i 21L 201L) ==>  583550225901...444021L
(define (pow-i num power)
"Calculate the integer power of an integer"
  (if (zero? power) 1L
      (let (pot out)
        (setq pot (pow-i num (/ power 2)))
        (if (odd? power)
            (setq out (* num pot pot))
            (setq out (* pot pot)))
        out)))
; Alternative Version (Lutz)
(define (** num power)
"Calculate the integer power of an integer"
  (if (zero? power) 1L
      (let (out 1L)
        (dotimes (i power)
          (setq out (* out num))))))

;; @syntax (powmod base expt modulo)
;; @description Calculate (base^exponent % modulo)
;; @param <base> integer number (int)
;; @param <exponent> integer power (int)
;; @param <modulo> integer modulo (int)
;; @return base^exponent % modulo (int)
;; @example
;; (powmod 0L 0L 0L)         ==> 1L
;; (powmod 1234L 55555L 7L)  ==> 2L
(define (powmod base expt modulo)
"Calculate (base^exponent % modulo)"
  (let (out 1L)
    (while (> expt 0)
      (if (odd? expt)
          (setq out (% (* out base) modulo)))
      (setq base (% (* base base) modulo))
      (setq expt (/ expt 2)))
    out))

;; @syntax (log-i num base)
;; @description Calculate the integer logarithm of a positive number
;; @param <num> positive number (float)
;; @param <base> base of the logarithm (float)
;; @return logarithm of the number (int)
;; @example
;; (log-i 10 2)                  ==> 3
;; (log-i (exp 1) (exp 1))       ==> 1
;; (log-i 999 10)                ==> 22
;; (log-i 1001 10)               ==> 3
;; (log-i 1000 E)                ==> 9
;; (log-i (+ 1000L MAX-INT) 10)  ==> 18L
(define (log-i num base)
"Calculate the integer logarithm of a positive number"
  (local (out)
    (if (bigint? num) (setq out -1L) (setq out -1))
    (while (!= num 0)
      (setq num (/ num base))
      (setq out (+ out 1L)))
    out))

;; @syntax (sqrt-i num)
;; @description Calculate the integer square root of a positive integer
;; @param <num> positive integer (int)
;; @return square root of the number (int)
;; @example
;; (sqrt-i 4)                  ==> 2
;; (sqrt-i 1001)               ==> 32
;; (sqrt-i 1088)               ==> 33
;; (sqrt-i (+ 1000L MAX-INT))  ==> 3037000499L
(define (sqrt-i num)
"Calculate the integer square root of a positive integer"
  (local (start mid end trovato out)
    (if (bigint? num) (setq start 1L) (setq start 1))
    (setq end (/ num 2))
    (while (and (<= start end) (= trovato nil))
      (setq mid (/ (+ start end) 2))
      (if (= num (* mid mid))
          (setq out mid trovato true)
          (if (< (* mid mid) num)
              (setq start (+ mid 1) out mid)
              (setq end (- mid 1)))))
    out))

;; @syntax (perfect? num)
;; @description Check if an integer number is a perfect number (num = sum(proper-divisors))
;; @param <num> integer number (int)
;; @return true or nil
;; @example
;; (perfect? 2)      ==> nil
;; (perfect? 6)      ==> true
;; (perfect? 4192)  ==> true
(define (perfect? num)
"Check if an integer number is a perfect number (num = sum(proper-divisors))"
  (= (+ num num) (divisors-sum num)))

;; @syntax (power-of? x y)
;; @description Check if number y is a power of number x
;; @param <num> integer number (int)
;; @return true or nil
;; @example
;; (power-of? 3 117)                   ==> nil
;; (power-of? 4 4096)                  ==> true
;; (power-of? -2 -8)                   ==> true
;; (power-of? -2 8)                    ==> nil
;; (power-of? -2 -16)                  ==> nil
;; (power-of? -2 16)                   ==> true
;; (power-of?  1  1)                   ==> true
;; (power-of?  1 -1)                   ==> nil
;; (power-of? -1  1)                   ==> true
;; (power-of? -1 -1)                   ==> true
;; (power-of? 3 847288609443)          ==> true
;; (power-of? 34 2386420683693101056)  ==> true
(define (power-of? x y)
"Check if number y is a power of number x"
  (cond ((or (zero? x) (zero? y)) nil)
        ((= x 1) (= y 1))
        ((= x -1) (or (= y 1) (= y -1)))
        (true
          (while (zero? (% y x))
            (setq y (/ y x)))
          (= y 1))))

;; @syntax (power-of-2? num)
;; @description Check if an integer is a power of 2
;; @param <num> positive integer (int)
;; @return true or nil
;; @example
;; (power-of-2? 1024)  ==> true
;; (power-of-2? 1023)  ==> nil
(define (power-of-2? num)
"Check if an integer is a power of 2"
  (and (> num 0) (zero? (& num (- num 1)))))

;; @syntax (square? num)
;; @description Check if an integer is a perfect square
;; @param <num> positive integer (int)
;; @return true or nil
;; @example
;; (square? 100)  ==> true
;; (square? 101)  ==> nil
;; (square? 1524157878065965654042756L)  ==> true
;; (square? 1524157878065965654042756)  ==> true
;; (= (filter square? (sequence 1 1000000)) (map (fn(x) (* x x)) (sequence 1 1000)))  ==> true
(define (square? num)
"Check if an integer is a perfect square"
  (let (a (bigint num))
    (while (> (* a a) num)
      (setq a (/ (+ a (/ num a)) 2)))
    (= (* a a) num)))
; alternative faster version (non big-integer)
;(define (square? num)
;"Check if an integer is a perfect square"
;  (let (isq (int (sqrt num)))
;    (= num (* isq isq))))

;; @syntax (cube? num)
;; @description Check if an integer is a perfect cube
;; @param <num> positive integer (int)
;; @return true or nil
;; @example
;; (cube? 8)                ==> true
;; (cube? 281474976710656)  ==> true
;; (cube? 16)               ==> nil
;; (= (filter cube? (sequence 1 1000000)) (map (fn(x) (* x x x)) (sequence 1 100)))  ==> true
(define (cube? num)
"Check if an integer is a perfect cube"
  (let ((cr (int (pow num (div 3)))))
    (cond ((= (* cr cr cr) num) true)
          ((= (* (+ cr 1) (+ cr 1) (+ cr 1)) num) true)
          ((= (* (- cr 1) (- cr 1) (- cr 1)) num) true)
          (true nil))))

;; @syntax (power? num result)
;; @description Check (and find) if a number is a power of another number
;; @param <num> positive integer (int)
;; @param <result> if true return a list (base exponent)
;; @return true or nil or a list (base exponent)
;; @example
;; (power? 1)                ==> true
;; (power? 1 true)           ==> (1 1)
;; (power? (pow 12 3))       ==> true
;; (power? (pow 11 7) true)  ==> (11 7)
;; (power? 1234)             ==> nil
;; (power? 1234 true)        ==> nil
;; (power? 100 true)         ==> (10 2)
(define (power? num result)
"Check (and find) if a number is a power of another number"
  (local (a out)
    (cond ((zero? num) nil)
          ((= num 1)
           (if (nil? result)
               true
               '(1 1)))
          (true
           (if (nil? result)
               (> (apply gcd (factor-exponent num)) 1)
               ; if result is true
               (if (> (setq a (apply gcd (factor-exponent num))) 1)
                   (list (ceil (pow num (div 1 a))) a)
                   nil))))))
; crea la lista degli esponenti dei termini della fattorizzazione di un numero
(define (factor-exponent x)
  (if (= x 1) '(1)
    (letn (fattori (factor x)
           unici (unique fattori))
       (count unici fattori))))

;; @syntax (radical num)
;; @description Calculate the radical of a positive integer number (product of unique prime factors of num)
;; @param <num> positive integer number (int)
;; @return Radical of the number (int)
;; @example
;; (radical 123)                ==> 123
;; (radical 1000)               ==> 10
(define (radical num)
  "Calculate the radical of a positive integer number"
  (if (= num 1) 1
      (apply * (unique (factor num)))))

;; @syntax (digit-root num)
;; @description Calculate the repeated sum of the digits of an integer
;; @param <num> integer number (int)
;; @return Repeated sum of digits (int)
;; @example
;; (digit-root 0)                ==> 0
;; (digit-root 123456789)        ==> 9
;; (digit-root -48576293)        ==> 8
;; (digit-root (+ 10L MAX-INT))  ==> 8
(define (digit-root num)
"Calculate the repeated sum of the digits of an integer"
    (+ 1 (% (- (abs num) 1) 9)))

;; @syntax (digit-sum num)
;; @description Calculate the sum of the digits of an integer
;; @param <num> integer number (int)
;; @return sum of the digits (int)
;; @example
;; (digit-sum 0)                ==> 0
;; (digit-sum 123456789)        ==> 45
;; (digit-sum 48576293)         ==> 44
;; (digit-sum (+ 10L MAX-INT))  ==> 89
;; (digit-sum 111111111111111111111111111111111111111111L) ==> 42
(define (digit-sum num)
"Calculate the sum of the digits of an integer"
  (let (out 0)
    (while (!= num 0)
      (setq out (+ out (% num 10)))
      (setq num (/ num 10)))
    out))

;; @syntax (digit-prod num)
;; @description Calculate the product of the digits of an integer
;; @param <num> integer number (int)
;; @return product of the digits (int)
;; @example
;; (digit-prod 0)                      ==> 0
;; (digit-prod 123456789)              ==> 362880
;; (digit-prod 48576293)               ==> 362880
;; (digit-prod 9223372136854775817L)  ==> 179233689600
(define (digit-prod num)
"Calculate the product of the digits of an integer"
  (if (zero? num)
      0
      (let (out 1)
        (while (!= num 0)
          (setq out (* out (% num 10)))
          (setq num (/ num 10)))
    out)))

;; @syntax (digit-square-sum num)
;; @description Sum the squares of digits of a number
;; @param <num> integer
;; @return integer
;; @example
;; (map digit-square-sum '(10 21 42 123))  ==> (1 5 20 14)
(define (digit-square-sum num)
  (let ((sum 0) (d 0))
    (while (!= num 0)
      (setq d (% num 10))
      (++ sum (* d d))
      (setq num (/ num 10)))
    sum))

;; @syntax (digit-cube-sum num)
;; @description Sum the cubes of digits of a number
;; @param <num> integer
;; @return integer
;; @example
;; (map digit-cube-sum '(10 21 42 123))  ==> ((1 9 72 36))
(define (digit-cube-sum num)
  (let ((sum 0) (d 0))
    (while (!= num 0)
      (setq d (% num 10))
      (++ sum (* d d d))
      (setq num (/ num 10)))
    sum))

;; @syntax (first-digit num)
;; @description Return the first digit of a non-negative integer
;; @param <num> non-negative integer
;; @return integer
;; @example
;; (first-digit 9223372036854775807)     ==> 9
;; (first-digit 9223372036854775807000)  ==> 9L
(define (first-digit num)
"Return the first digit of a non-negative integer"
  (if (zero? num) 0
    ;else
    ;(/ num (pow 10 (- (length num) 1)))) ; slower
    ; (- (length num) 1) = (int (log num 10))
    (/ num (pow 10 (int (log num 10))))))

;; @syntax (last-digit num)
;; @description Return the last digit of a non-negative integer
;; @param <num> non-negative integer
;; @return integer
;; @example
;; (last-digit 9223372036854775807)     ==> 7
;; (last-digit 9223372036854775807000)  ==> 0L
(define (last-digit num)
"Return the last digit of a non-negative integer"
  (% num 10))

;; @syntax (same-digits? num1 num2)
;; @description Check if two numbers have the same digits
;; @param <num1> non-negative integer
;; @return integer
;; @example
;; (same-digits? -12 -21)   ==> true
;; (same-digits? 123 231)   ==> true
;; (same-digits? 123 2314)  ==> nil
(define (same-digits? num1 num2)
"Check if two numbers have the same digits"
  (= (sort (explode (string num1))) (sort (explode (string num2)))))

;; @syntax (sum-digit-pairs num all)
;; @description Generate the sums of the mirror digit pairs of a number
;; @param <num1> non-negative integer
;; @param <all> boolean (true: all digits sum)
;; @return true or nil
;; @example
;; (sum-digit-pairs 1234)       ==> (5 5)
;; (sum-digit-pairs 1234 true)  ==> (5 5 5 5)
;; (sum-digit-pairs 239)        ==> (11 6)
;; (sum-digit-pairs 239 true)   ==> (11 6 11)
(define (sum-digit-pairs num all)
"Generate the sums of the mirror digit pairs of a number"
  (let ( (out '()) (k (length num)) (d (int-list num)) (end 0) )
    (if all (setq end (- k 1)) (setq end (/ (- k 1) 2)))
    (for (i 0 end)
      (push (+ (d i) (d (- k 1 i))) out -1))
    out))

;; @syntax (digit-min num)
;; @description Find the smallest digit of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (digit-min 3278)  ==> 2
;; (digit-min 100)   ==> 0
(define (digit-min num)
"Find the smallest digit of an integer"
  (apply min (map int (explode (string (abs num))))))

;; @syntax (digit-max num)
;; @description Find the largest digit of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (digit-max 3278)  ==> 8
;; (digit-max 100)   ==> 1
(define (digit-max num)
"Find the largest digit of an integer"
  (apply max (map int (explode (string (abs num))))))

;; @syntax (pers-add num)
;; @description Calculate the additive persistence of an integer
;; @param <num> integer number (int)
;; @return additive digital root (int)
;; @example
;; (pers-add 0)    ==> 0
;; (pers-add 1)    ==> 0
;; (pers-add 10)   ==> 1
;; (pers-add 19)   ==> 2
;; (pers-add 199)  ==> 3
(define (pers-add n)
"Calculate the additive persistence of an integer"
  (let (out 0)
    (while (> n 9)
      (setq n (digit-sum n))
      (++ out))
    out))

;; @syntax (pers-mul num)
;; @description Calculate the multiplicative persistence of an integer
;; @param <num> integer number (int)
;; @return multiplicative digital root (int)
;; @example
;; (pers-mul 0)   ==> 0
;; (pers-mul 1)   ==> 0
;; (pers-mul 10)  ==> 1
;; (pers-mul 25)  ==> 2
;; (pers-mul 39)  ==> 3
(define (pers-mul n)
"Calculate the multiplicative persistence of an integer"
  (let (out 0)
    (while (> n 9)
      (setq n (digit-prod n))
      (++ out))
    out))

;; @syntax (number-stamp num)
;; @description Calculate the stamp of a number
;; @param <num> integer number (int)
;; @return stamp: an integer with ten digits. The n-th digit of the result represents how many times the digit n is repeated in the given number
;; @example
;; (number-stamp 121232)                ==> 1320
;; (number-stamp 211223)                ==> 1320
;; (number-stamp 1234567890)            ==> 1111111111
;; (number-stamp 12345678901234567890)  ==> 2222222222
(define (number-stamp num)
"Calculate the stamp of a number"
  (let ((ar (array 10 '(0))) (out 0))
    ; fill array with the count of digits
    (while (> num 0)
      (++ (ar (% num 10)))
      (setq num (/ num 10)))
    ; create output number from array
    (for (i 9 0)
      (setq out (+ (ar i) (* out 10))))
    out))

;; @syntax (pop-count1 num)
;; @description Calculate the number of 1 in binary value of an integer number
;; @param <num> positive integer number
;; @return number of 1 in binary value of num
;; @example
;; (bits 12345)  ==> "11000000111001"
;; (pop-count1 12345) ==> 6
;; (pop-count1 123456789) ==> 16
(define (pop-count1 num)
"Calculate the number of 1 in binary value of an integer number"
  (let (counter 0)
    (while (> num 0)
      (setq num (& num (- num 1)))
      (++ counter))
    counter))

;; @syntax (pop-count0 num)
;; @description Calculate the number of 0 in binary value of an integer number
;; @param <num> positive integer number
;; @return number of 0 in binary value of num
;; @example
;; (bits 12345)  ==> "11000000111001"
;; (pop-count0 12345) ==> 8
;; (pop-count0 123456789) ==> 11
(define (pop-count0 num)
"Calculate the number of 0 in binary value of an integer number"
  (- (length (bits num)) (pop-count1 num)))

;; @syntax (polygonal-number s n)
;; @description Calculate the nth polygonal number with s sides
;; @param <s> number of sides (int)
;; @param <n> index of polygonal number (int)
;; @return integer
;; @example
;; (map (curry polygonal-number 3) (sequence 1 10))  ==> (1 3 6 10 15 21 28 36 45 55)    ; triangular
;; (map (curry polygonal-number 5) (sequence 1 10))  ==> (1 5 12 22 35 51 70 92 117 145) ; pentagonal
(define (polygonal-number s n)
"Calculate the nth polygonal number with p sides"
 (- (/ (* s n (- n 1)) 2) (* n (- n 2))))

;; @syntax (derivative num)
;; @description Calculate the arithmetic derivative of an integer
;; @param <num> integer number (int)
;; @return integer
;; @example
;; (derivative 100)  ==> 140
;; (derivative -21)  ==> -10
(define (derivative num)
"Calculate the arithmetic derivative of an integer"
  (local (fattori sum)
    (cond
      ; calcola la derivata di un numero negativo
      ((< num 0) (- (derive (- num))))
      ; se num è uguale a 0 o 1, allora restituisce 0
      ((< num 2) 0)
      (true
        ; calcolo dei fattori primi raggruppati
        (setq fattori (factor-group num))
        ; se num è primo restituisce 1
        (if (and (= (length fattori) 1) (= (fattori 0 1) 1))
            1
            ; altrimenti calcola la derivata aritmetica
            (begin
              (setq sum 0)
              (dolist (f fattori)
                (setq sum (+ sum (/ (* num (f 1)) (f 0)))))))))))

;===========================================================================
;===========================================================================
;; <p><b><center>NUMERICS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (make-poly coeffs)
;; @description Generate a function who evaluate a polynomial with those coefficients
;; @param <coeffs> list of coefficients (float)
;; @return polynomial (function)
;; @example
;; (make-poly '(1 0))              ==> (lambda (x) (add 0 (mul x 1)))
;; (make-poly '(3 5 7))            ==> (lambda (x) (add 7 (mul x 5) (mul (pow x 2) 3)))
;; (make-poly '(4 5 7 10))         ==> (lambda (x) (add 10 (mul x 7) (mul (pow x 2) 5) (mul (pow x 3) 4)))
;; (make-poly '(1.5 -2 -2.2 4.5))  ==> (lambda (x) (add 4.5 (mul x -2.2) (mul (pow x 2) -2) (mul (pow x 3) 1.5)))
(define (make-poly coeffs)
"Generate a function who evaluate a polynomial with those coefficients"
  (local (func body)
    (reverse coeffs)
    (setq func '(lambda (x) x)) ; funzione lambda base
    (setq body '())             ; corpo della funzione
    (push 'add body -1)
    (push (first coeffs) body -1)            ; termine noto
    (push (list 'mul 'x (coeffs 1)) body -1) ; termine lineare
    (if (> (length coeffs) 2)
      (for (i 2 (- (length coeffs) 1))       ; termini di ordine superiore
        (push (list 'mul (list 'pow 'x i) (coeffs i)) body -1)))
    (setq (last func) body) ; modifica corpo della funzione
    func))

;; @syntax (make-poly-horner coeffs)
;; @description Generate a function who evaluate (horner) a polynomial with those coefficients
;; @param <coeffs> list of coefficients (float)
;; @return polynomial (function)
;; @example
;; (make-poly-horner '(1 0))              ==> (lambda (x) (add 0 (mul x 1)))
;; (make-poly-horner '(3 5 7))            ==> (lambda (x) (add 7 (mul x (add 5 (mul x 3)))))
;; (make-poly-horner '(4 5 7 10))         ==> (lambda (x) (add 10 (mul x (add 7 (mul x (add 5 (mul x 4)))))))
;; (make-poly-horner '(1.5 -2 -2.2 4.5))  ==> (lambda (x) (add 4.5 (mul x (add -2.2 (mul x (add -2 (mul x 1.5)))))))
(define (make-poly-horner coeffs)
"Generate a function who evaluate (horner) a polynomial with those coefficients"
  (push (if (< (length coeffs) 2)
            (first coeffs)
            (apply (fn (acc c) (list 'add c (cons 'mul (list 'x acc))))
                   coeffs 2))
        (copy '(fn (x))) -1))

;; @syntax (quadratic a b c)
;; @description Find the solutions of the quadratic equation: A*x^2 + B*x + C = 0
;; @param <A> coefficient of x^2
;; @param <B> coefficient of x
;; @param <C> costant term
;; @return list ((re1 im1) (re2 im2)) (float)
;; @example
;; (quadratic 1 1 -2)    ==> ((1 0) (-2 0))
;; (quadratic 1 -2 -15)  ==> ((5 0) (-3 0))
;; (quadratic 1 1 2)     ==> ((-0.5 1.322875655532295) (-0.5 -1.322875655532295))
;; (quadratic 1 -2 1)    ==> ((1 0) (1 0))
(define (quadratic a b c)
"Find the solutions of the quadratic equation: A*x^2 + B*x + C = 0"
  (local (x1 i1 x2 i2 delta)
    (setq delta (sub (mul b b) (mul 4 a c)))
    (cond ((= a 0) ; equazione di primo grado
            (if (!= b 0) (setq x1 (sub 0 (div c b)))))
          ((> delta 0) ; due radici reali
            (setq x1 (div (add (sub 0 b) (sqrt delta)) (mul 2 a)))
            (setq x2 (div (sub (sub 0 b) (sqrt delta)) (mul 2 a)))
            (setq i1 0.0)
            (setq i2 0.0))
          ((< delta 0) ; due radici complesse
            (setq x1 (div (sub 0 b) (mul 2 a)))
            (setq x2 (div (sub 0 b) (mul 2 a)))
            (setq i1 (div (sqrt (sub 0 delta)) (mul 2 a)))
            (setq i2 (sub 0 (div (sqrt (sub 0 delta)) (mul 2 a)))))
          (true ;((= delta 0) ; due radici coincidenti
            (setq x1 (sub 0 (div b (mul 2 a))))
            (setq x2 (sub 0 (div b (mul 2 a))))
            (setq i1 0.0)
            (setq i2 0.0)))
    (list (list x1 i1) (list x2 i2))))

;; @syntax (cubic a b c d)
;; @description Find the solutions of the cubic equation: A*x^3 + B*x^2 + C*x + D = 0
;; @param <A> coefficient of x^3
;; @param <B> coefficient of x^2
;; @param <C> coefficient of x
;; @param <D> constant term
;; @return list of solutions ((re1 im1) (re2 im2) (re3 im3)) (float)
;; @example
;; (cubic 1 -6 12 -8)    ==> ((2 0) (2 0) (2 0))
;; (cubic 1 1 -10 8)     ==> ((2 0) (-4 0) (1 0))
;; (cubic 1 -6 76 -136)  ==> ((2 0) (2 7.999999999999999) (2 -7.999999999999999))
;; (cubic 1 -8 29 -52)   ==> ((4 0) (2 3) (2 -3))
(define (cubic a b c d)
"Find the solutions of the cubic equation: A*x^3 + B*x^2 + C*x + D = 0"
  (local (x1 x2 x3 i1 i2 i3 ff gg hh ii jj kk ll mm nn pp qq rr ss tt uu)
    (setq x1 0 x2 0 x3 0 i1 0 i2 0 i3 0)
    ; Calcolo discriminanti ff, gg, hh
    ; ff = (3*(c/a) - (b*b)/(a*a)) / 3
    (setq ff (div (sub (mul 3 (div c a)) (div (mul b b) (mul a a))) 3))
    ; (println "ff = " ff)
    ; gg = ((2*(b*b*b)/(a*a*a)) - (9*b*c/(a*a)) + (27*(d/a))) / 27
    (setq gg (div (add (sub (mul 2 (div (mul b b b) (mul a a a))) (div (mul 9 b c) (mul a a))) (mul 27 (div d a))) 27))
    ; (println "gg = " gg)
    ; hh = ((gg*gg)/4) + ((ff*ff*ff)/27)
    (setq hh (add (div (mul gg gg) 4) (div (mul ff ff ff) 27)))
    ; (println "hh = " hh)
    ; Controllo discriminanti per determinare il tipo delle radici
    (cond ((> hh 0) ; una radice reale e due radici complesse
            ; ii = -(gg/2) + Math.sqrt(hh)
            (setq ii (sub (sqrt hh) (div gg 2)))
            ;(println "ii = " ii)
            ; jj = Math.cbrt(ii)
            (setq jj (pow-ext ii (div 1 3)))
            ;(println "jj = " jj)
            ; kk = (-gg/2) - Math.sqrt(hh)
            (setq kk (sub (sub 0 (div gg 2)) (sqrt hh)))
            ;(println "kk = " kk)
            ; ll = Math.cbrt(kk)
            (setq ll (pow-ext kk (div 1 3)))
            ;(println "ll = " ll)
            ; x1 =  (jj + ll) - (b/(3*a))
            (setq x1 (sub (add jj ll) (div b (mul 3 a))))
            ; x2 = -(jj + ll)/2 - (b/(3*a))
            (setq x2 (sub (sub 0 (div (add jj ll) 2)) (div b (mul 3 a))))
            ; i2 =  (jj - ll) * Math.sqrt(3)/2
            (setq i2 (mul (sub jj ll) (div (sqrt 3) 2)))
            ; x3 =  x2
            (setq x3 x2)
            ; i3 = -i2
            (setq i3 (sub 0 i2)))
          ((and (zero? ff) (zero? gg) (zero? hh)) ; tre radici reali coincidenti
            ; x1 = Math.cbrt(d/a) * (-1)
            (setq x1 (sub 0 (pow-ext (div d a) (div 1 3))))
            (setq x2 x1)
            (setq x3 x1))
          ((<= hh 0) ; tre radici reali
            ; mm = Math.sqrt((gg*gg)/4 - hh)
            (setq mm (sqrt (sub (div (mul gg gg) 4) hh)))
            ;(println "mm = " mm)
            ; nn = Math.cbrt(mm)
            (setq nn (pow-ext mm (div 1 3)))
            ;(println "nn = " nn)
            ; pp = Math.acos(-(gg/(2*mm)))
            (setq pp (acos (sub 0 (div gg (mul mm 2)))))
            ;(println "pp = " pp)
            ; qq = nn*(-1)
            (setq qq (sub 0 nn))
            ;(println "qq = " qq)
            ; rr = Math.cos(pp/3)
            (setq rr (cos (div pp 3)))
            ;(println "rr = " rr)
            ; ss = Math.sqrt(3) * Math.sin(pp/3)
            (setq ss (mul (sqrt 3) (sin (div pp 3))))
            ;(println "ss = " ss)
            ; tt = (b/(3*a)) * (-1)
            (setq tt (sub 0 (div b (mul 3 a))))
            ;(println "tt = " tt)
            ; x1 = 2*nn*Math.cos(pp/3) - (b/(3*a))
            (setq x1 (sub (mul 2 nn (cos (div pp 3))) (div b (mul 3 a))))
            ; x2 = qq * (rr + ss) + tt
            (setq x2 (add tt (mul qq (add rr ss))))
            ; x3 = qq * (rr - ss) + tt;
            (setq x3 (add tt (mul qq (sub rr ss)))))
          (true (println "cubic: error")))
    (list (list x1 i1) (list x2 i2) (list x3 i3))))
; Funzione ausiliaria (pow function with positive and negative number)
(define (pow-ext x n)
  (if (< x 0)
      (sub 0 (pow (sub 0 x) n))
      (pow x n)))
;(pow 3 0.33)      ;-> 1.436977652184852
;(pow -3 0.33)     ;-> 1.#IND
;(pow-ext 3 0.33)  ;-> 1.436977652184852
;(pow-ext -3 0.33) ;-> -1.436977652184852

;; @syntax (bairstow coeffs)
;; @description Find the roots of a real polynomial of arbitrary degree
;; @param <coeffs> list of coefficients of the polynomial (from the highest to the lowest degree)
;; @return list of roots ((re1 im1) (re2 im2) ... (rek imk)) (float)
;; @example
;; (bairstow '(4 32))          ==> ((-8 0))
;; (bairstow '(2 -4 10))       ==> (((1 2) (1 -2)))
;; (bairstow '(4 2 -4 10))     ==> (((0.6563019928818721 0.9739090873711072) (0.6563019928818721 -0.9739090873711072)) (-1.812603985763744))
;; (bairstow '(3 -2 -1 4 10))  ==> (((-0.871136997600388 0.7358894057211269) (-0.871136997600388 -0.7358894057211269)) ((1.204470330933721 1.054769962446627) (1.204470330933721 -1.054769962446627)))
(define (bairstow coeffs)
"Find the roots of a real polynomial of arbitrary degree"
  (local (w j i n
          t deter p q x1 x2 x1r x1i r s ds dr
          a b c d sol)
    (setq sol '())
    (setq x1 0.0)
    (setq x2 0.0)
    (setq r 0.1)
    (setq s 0.1)
    (setq a (array 100 '(0)))
    (setq b (array 100 '(0)))
    (setq c (array 100 '(0)))
    (setq d (array 100 '(0)))
    (setq (b 4) 0)
    (setq (b 3) 0)
    ;assegna i coefficienti al vettore "a"
    (dolist (el (reverse coeffs))
      (setq (a $idx) el))
    ;(println a)
    (setq n (- (length coeffs) 1))
    (setq w n)
    (cond ((= w 1) (linear-aux (a 0) (a 1)) (-- w))
          ((= w 2) (quadratic-aux (a 2) (a 1) (a 0)) (setq w (- w 2)))
          (true
           (while (>= w 3)
             (for (j 1 50)
               (setq (b n) (a n))
               (setq (b (- n 1)) (sub (a (- n 1)) (mul r (b n))))
               (for (i (- n 2) 1 -1)
                 (setq (b i) (sub (a i) (mul r (b (+ i 1))) (mul s (b (+ i 2))))))
               (setq (b 0) (sub (a 0) (mul s (b 2))))
               (setq (c n) (b n))
               (setq (c (- n 1)) (sub (b (- n 1)) (mul r (c n))))
               (for (i (- n 2) 2 -1)
                 (setq (c i) (sub (b i) (mul r (c (+ i 1))) (mul s (c (+ i 2))))))
               (setq (c 1) (sub (mul s (c 3))))
               (setq (d n) (b n))
               (setq (d (- n 1)) (sub (b (- n 1)) (mul r (d n))))
               (for (i (- n 2) 3 -1)
                 (setq (d i) (sub (b i) (mul r (d (+ i 1))) (mul s (d (+ i 2))))))
               (setq (d 2) (sub (b 2) (mul s (d 4))))
               (setq dr (div
                        (sub (mul (b 0) (d 3)) (mul (b 1) (d 2)))
                        (add (mul (sub (d 2) (mul r (d 3))) (d 2)) (mul s (d 3) (d 3)))))
               (setq ds (div
                        (sub (add (mul (b 1) s (d 3)) (mul (b 0) (sub (d 2) (mul r (d 3))))))
                        (add (mul (sub (d 2) (mul r (d 3))) (d 2)) (mul s (d 3) (d 3)))))
               (setq p (sub r dr))
               (setq q (sub s ds))
               (setq r p)
               (setq s q))
            (setq t 1)
            (quadratic-aux t r s)
            (setq w (- w 2))
            (for (i n 0 -1)
              (setq (a (- n i)) (b (- n i))))
            (for (i n 0 -1)
              (setq (a (- n i)) (a (+ (- n i) 2)))))
          (cond ((= w 2) (quadratic-aux (b 4) (b 3) (b 2)) (setq w (- w 2)))
                ((= w 1) (linear-aux (b 2) (b 3)) (-- w)))))
    sol))
; soluzione equazione lineare
(define (linear-aux a0 a1)
  (push (list (sub (div a0 a1)) 0) sol -1))
; soluzione equazione quadratica
(define (quadratic-aux t r s)
  (local (deter x1 x2 x1r x1i x2r x2i)
    (setq deter (sub (mul r r) (mul 4 s t)))
    ;(println t { } r { } s)
    (cond ((>= deter 0)
           (setq x1 (div (add (sub r) (sqrt deter)) (mul 2 t)))
           (setq x2 (div (sub (sub r) (sqrt deter)) (mul 2 t)))
           ;(println "x1: " x1 { } "x2: " x2)
           (push (list x1 x2) sol -1))
          (true
           (setq x1r (div (sub r) (mul 2 t)))
           (setq x1i (div (sqrt (abs deter)) (mul 2 t)))
           (setq x2r x1r)
           (setq x2i (sub x1i))
           ;(println "x1r: " x1r { , } "x1i: " x1i)
           ;(println "x2r: " x2r { , } "x2i: " x2i)
           ;(push (list (list x1r x1i) (list x2r x2i)) sol -1)
           (push (list x1r x1i) sol -1)
           (push (list x2r x2i) sol -1)))))

;; @syntax (sislin-c matrix terms)
;; @description Solve a linear system with Cramer's method (determinant)
;; @param <matrix> matrix of the linear system
;; @param <terms> known terms
;; @return list of solutions (sol1 sol2...soln) (float) or nil
;; @example
;; (sislin-c '((2 1 1) (4 -1 1) (-1 1 2)) '(1 -5 5))   ==> (-1 2 1)
;; (sislin-c '((1 2 3) (-3 -2 3) (4 -5 2)) '(1 -1 1))  ==> (0.3620689655172414 0.1379310344827586 0.1206896551724138)
;; (sislin-c '((2 1 1) (4 -1 1) (4 2 2)) '(1 -5 5))    ==> nil
(define (sislin-c matrix terms)
"Solve a linear system with Cramer's method (determinant)"
  (local (dim detm det-i sol copia)
    (setq dim (length matrix))
    (setq sol '())
    (setq copia matrix)
    (setq detm (det copia 0.0))
    ; la soluzione è indeterminata se il determinante vale zero.
    (if (= detm 0) (setq sol nil)
    ;(println detm)
      (for (i 0 (- dim 1))
        (for (j 0 (- dim 1))
          (setf (copia j i) (terms j)))
        ; 0.0 -> restituisce 0 (invece di nil),
        ; quando la matrix è singolare
        (setq det-i (det copia 0.0))
        (push (div det-i detm) sol -1)
        (setq copia matrix)))
    sol))

;; @syntax (sislin-g matrix terms)
;; @description Solve a linear system with Gauss's method (elimination with pivot and backwards substitution)
;; @param <matrix> matrix of the linear system
;; @param <terms> known terms
;; @return list of solutions (sol1 sol2...soln) (float) or nil
;; @example
;; (sislin-g '((2 1 1) (4 -1 1) (-1 1 2)) '(1 -5 5))   ==> (-1 2 1)
;; (sislin-g '((1 2 3) (-3 -2 3) (4 -5 2)) '(1 -1 1))  ==> (0.3620689655172414 0.1379310344827586 0.1206896551724138)
;; (sislin-g '((2 1 1) (4 -1 1) (4 2 2)) '(1 -5 5))    ==> nil
(define (sislin-g matrix terms)
"Solve a linear system with Gauss's method (elimination with pivot and backwards substitution)"
  (local (n m p rowx amax xfac temp temp1 x)
    (setq rowx 0) ;conta il numero di scambio righe
    (setq n (length matrix))
    (setq x (array n (dup '0 n)))
    (for (k 0 (- n 2))
      (setq amax (abs (matrix k k)))
      (setq m k)
      ; trova la riga con il pivot più grande
      (for (i (+ k 1) (- n 1))
        (setq xfac (abs (matrix i k)))
        (if (> xfac amax) (setq amax xfac m i)))
      ; scambio delle righe
      (if (!= m k) (begin
          (++ rowx)
          (setq temp1 (terms k))
          (setq (terms k) (terms m))
          (setq (terms m) temp1)
          (for (j k (- n 1))
            (setq temp (matrix k j))
            (setq (matrix k j) (matrix m j))
            (setq (matrix m j) temp))))
      (for (i (+ k 1) (- n 1))
        (setq xfac (div (matrix i k) (matrix k k)))
        (for (j (+ k 1) (- n 1))
          (setq (matrix i j) (sub (matrix i j) (mul xfac (matrix k j)))))
        (setq (terms i) (sub (terms i) (mul xfac (terms k))))))
    ; sostituzione all'indietro (backward sostitution)
    (for (j 0 (- n 1))
      (setq p (sub n j 1))
      (setq (x p) (terms p))
      (if (<= (+ p 1) (- n 1))
        (for (i (+ p 1) (- n 1))
          (setq (x p) (sub (x p) (mul (matrix p i) (x i))))))
      (setq (x p) (div (x p) (matrix p p))))
    (if (or (find true (map inf? x)) (find true (map NaN? x)))
        nil
        x)))

;; @syntax (check-sislin matrix terms sol)
;; @description Check the solution of a linear system (backwards substitution)
;; @param <matrix> matrix of the linear system
;; @param <terms> known terms
;; @param <sol> vector of solutions
;; @return list of residues (res-1 res-2 ... res-n) (float)
;; @example
;; (check-sislin '((2 1 1) (4 -1 1) (-1 1 2)) '(1 -5 5) '(-1 2 1))  ==> (0 0 0)
(define (check-sislin matrix terms sol)
"Check the solution of a linear system (backwards substitution)"
  (let (err '())
    (dolist (row matrix)
      (push (sub (terms $idx) (apply add (map mul row sol))) err -1))))

;; @syntax (spigot-e digits)
;; @description Calculate digits of 'e' with spigot method
;; @param <digits> number of digits
;; @return lists of digits
;; @example
;; (spigot-e 10)    ==>  (2 7 1 8 2 8 1 8 2 8)
;; (spigot-e 1000)  ==>  (2 7 1 8 2 8 1 8 2 8 4 5 9 0 ... 5 7 0 3 5 0 3 5)
(define (spigot-e digits)
"Calculate digits of 'e' with spigot method"
  (local (out n vec cifra)
    (setq out '(2))
    ; Calculate (n = digits + 100)
    ; (+ 100 to prevent last digits may be wrong)
    (setq n (+ digits 100))
    ; Vettore con n elementi tutti di valore 1
    (setq vec (array n '(1)))
    (for (i 0 (- n 1))
      (setq cifra 0)
      (for (j (- n 1) 0 -1)
        (setf (vec j) (+ (* 10 (vec j)) cifra))
        (setq cifra (/ (vec j) (+ j 2)))
        (setf (vec j) (% (vec j) (+ j 2))))
      (push cifra out -1))
    (slice out 0 digits)))

;; @syntax (spigot-pi digits)
;; @description Calculate digits of 'pi' with spigot method
;; @param <digits> number of digits
;; @return lists of digits
;; @example
;; (spigot-pi 10)    ==> (3 1 4 1 5 9 2 6 5 3)
;; (spigot-pi 1000)  ==> (3 1 4 1 5 9 2 6 5 3 5 8 9 7 ... 1 6 4 2 0 1 9 8)
(define (spigot-pi digits)
"Calculate digits of 'pi' with spigot method"
  (local (out n d q r t i u y)
    (setq out '())
    ; Calculate (n = digits + 100)
    ; (+ 100 to prevent last digits may be wrong)
    (setq n (+ digits 100))
    (setq d 0)
    (set 'q 1L 'r 180L 't 60L 'i 2L)
    (while (< d digits)
      (setq u (+ (* 27L i (+ i 1L)) 6L))
      (setq y (/ (+ (* q (- (* 27L i) 12L)) (* 5L r)) (* 5L t)))
      (push (+ 0 y) out -1)
      (setq r (* (* 10L u) (- (+ (* q (- (* 5L i) 2L)) r) (* y t))))
      (setq q (* 10L q i (- (* 2L i) 1L)))
      (setq t (* t u))
      (setq i (+ i 1))
      ;(print q { } r { } t { } i) (read-line)
      (++ d))
    (slice out 0 digits)))

;===========================================================================
;===========================================================================
;; <p><b><center>STATISTICS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (mean lst)
;; @description Calculate the mean of a list of numbers, (x1 + x2 +...+ xn)/n
;; @param <lst> list of numbers
;; @return mean (float)
;; @example
;; (mean (sequence 1 10))    ==> 5.5
;; (mean (sequence -10 10))  ==> 0
(define (mean lst)
"Calculate the mean of a list of numbers, (x1 + x2 +...+ xn)/n"
  (div (apply add lst) (length lst)))

;; @syntax (median lst)
;; @description Calculate the median of a list of numbers
;; @param <lst> list of numbers
;; @return median (float)
;; @example
;; (median (sequence 1 10))    ==> 5.5
;; (median (sequence -10 10))  ==> 0
;; (median (sequence 1 11))    ==> 6
(define (median lst)
"Calculate the median of a list of numbers"
  (let (len (length lst))
    (sort lst)
    (if (odd? len)
        (lst (/ len 2))
        (div (add (lst (- (/ len 2) 1)) (lst (/ len 2))) 2))))

;; @syntax (mode lst)
;; @description Calculate the mode of a list of numbers
;; @param <lst> list of numbers
;; @return mode (float)
;; @example
;; (mode '(1 1 2 2 2 3 3))  ==> 2
;; (mode '(1 2 3))          ==> 1
(define (mode lst)
"Calculate the mode of a list of numbers"
  (letn ((uniq (unique lst))
        (conta (count uniq lst)))
    (uniq (find (apply max conta) conta))))

;; @syntax (mean-geometric lst)
;; @description Calculate the geometric mean of a list of numbers, nth-root(x1*x2*...*xn)
;; @param <lst> list of numbers
;; @return geometric mean (float)
;; @example
;; (mean-geometric (sequence 1 10))    ==> 4.528728688116765
;; (mean-geometric (sequence -10 10))  ==> 0
(define (mean-geometric lst)
"Calculate the geometric mean of a list of numbers, nth-root(x1*x2*...*xn)"
  (pow (apply mul lst) (div (length lst))))

;; @syntax (mean-harmonic lst)
;; @description Calculate the harmonic mean of a list of numbers, n/(1/x1 + 1/x2 +...+ 1/n)
;; @param <lst> list of numbers
;; @return harmonic mean (float)
;; @example
;; (mean-harmonic (sequence 1 10))    ==> 3.414171521474055
;; (mean-harmonic (sequence -10 10))  ==> 0
(define (mean-harmonic lst)
"Calculate the harmonic mean of a list of numbers, n/(1/x1 + 1/x2 +...+ 1/n)"
  (let (sum-rec 0)
    (dolist (x lst)
      (setq sum-rec (add sum-rec (div x))))
    (div (length lst) sum-rec)))

;; @syntax (stdev lst)
;; @description Calculate the standard deviation of a list of numbers (population: N)
;; @param <lst> list of numbers
;; @return standard deviation (float)
;; @example
;; (stdev (sequence 1 10))    ==> 2.872281323269014
;; (stdev (sequence -10 10))  ==> 6.055300708194984
(define (stdev lst)
"Calculate the standard deviation of a list of numbers (population: N)"
  (let (sum (apply add lst))
    (sqrt (div (sub (apply add (map mul lst lst))
                    (div (mul sum sum) (length lst)))
               (length lst)))))

;; @syntax (stdev2 lst)
;; @description Calculate the standard deviation of a list of numbers (sample: N-1)
;; @param <lst> list of numbers
;; @return standard deviation (float)
;; @example
;; (stdev2 (sequence 1 10))    ==> 3.027650354097492
;; (stdev2 (sequence -10 10))  ==> 6.204836822995429
(define (stdev2 lst)
"Calculate the standard deviation of a list of numbers (sample: N-1)"
  (let (sum (apply add lst))
    (sqrt (div (sub (apply add (map mul lst lst))
                    (div (mul sum sum) (length lst)))
               (sub (length lst) 1)))))

;; @syntax (quantile p lst)
;; @description Calculate the p quantile of a list of numbers
;; @param <lst> list of numbers
;; @param <p> quantile (0..1)
;; @return quantile (float)
;; @example
;; The value of the x-th quantile divides the data into (1 - x) larger numbers and x smaller numbers (in percentage).
;; (setq a '(14 20 23 46 53 72 77 84 86 92 95))
;; First Quartile
;; (quantile 0.25 a)  ==> 23
;; Second Quartile
;; (quantile 0.5 a)   ==> 72
;; Third Quartile
;; (quantile 0.75 a)  ==> 86
(define (quantile p lst)
"Calculate the p quantile of a list of numbers"
  (sort lst)
  (cond ((zero? p) (lst 0)) ; min value
        ((= 1 p) (lst -1))  ; max value
        (true
          (let (k (mul p (length lst)))
            (if (= k (int k))
                (div (add (lst (- k 1)) (lst k)) 2) ; index are 0-based
                ;else
                (lst (int k))))))) ; index are 0-based

;; @syntax (rms lst)
;; @description Calculate the root-mean-square of a list of numbers, sqrt((x1^2 + x2^2 +...+ xn^2)/n)
;; @param <lst> list of numbers
;; @return root mean square (float)
;; @example
;; (rms (sequence 1 10))    ==> 6.204836822995429
;; (rms (sequence -10 10))  ==> 6.055300708194984
(define (rms lst)
"Calculate the root-mean-square of a list of numbers, sqrt((x1^2 + x2^2 +...+ xn^2)/n)"
  (sqrt(div (apply add (map (fn(x) (mul x x)) lst)) (length lst))))

;===========================================================================
;===========================================================================
;; <p><b><center>GEOMETRY</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (dist2d x1 y1 x2 y2)
;; @description Calculate 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)
;; @param <x1,y1> 2D cartesian coordinates of point P1
;; @param <x2,y2> 2D cartesian coordinates of point P2
;; @return 2D cartesian distance (float)
;; @example
;; (dist2d 1 2 5 5)  ==> 5
(define (dist2d x1 y1 x2 y2)
"Calculate 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)"
  (sqrt (add (mul (sub x1 x2) (sub x1 x2))
             (mul (sub y1 y2) (sub y1 y2)))))

;; Points as lists
;(define (dist2d p1 p2)
;"Calculate 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)"
;  (let ( (x1 (p1 0)) (y1 (p1 1))
;         (x2 (p2 0)) (y2 (p2 1)) )
;    (sqrt (add (mul (sub x1 x2) (sub x1 x2))
;               (mul (sub y1 y2) (sub y1 y2))))))

;; @syntax (dist2d-2 x1 y1 x2 y2)
;; @description Calculate the square of 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)
;; @param <x1,y1> 2D cartesian coordinates of point P1
;; @param <x2,y2> 2D cartesian coordinates of point P2
;; @return square of 2D cartesian distance (float)
;; @example
;; (dist2d-2 1 2 5 5)  ==> 25
(define (dist2d-2 x1 y1 x2 y2)
"Calculate the square of 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)"
  (add (mul (sub x1 x2) (sub x1 x2))
       (mul (sub y1 y2) (sub y1 y2))))

;; Points as lists
;(define (dist2d-2 p1 p2)
;"Calculate the square of 2D Cartesian distance of two points P1 = (x1 y1) and P2 = (x2 y2)"
;  (let ( (x1 (p1 0)) (y1 (p1 1))
;         (x2 (p2 0)) (y2 (p2 1)) )
;  (add (mul (sub x1 x2) (sub x1 x2))
;       (mul (sub y1 y2) (sub y1 y2)))))

;; @syntax (dist3d x1 y1 x2 y2 x3 y3)
;; @description Calculate 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)
;; @param <x1,y1,z1> 3D cartesian coordinates of point P1
;; @param <x2,y2,z2> 3D cartesian coordinates of point P2
;; @return 3D cartesian distance (float)
;; @example
;; (dist3d 1 3 1 5 3 1)  ==> 4
(define (dist3d x1 y1 z1 x2 y2 z2)
"Calculate 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)"
  (sqrt (add (mul (sub x1 x2) (sub x1 x2))
             (mul (sub y1 y2) (sub y1 y2))
             (mul (sub z1 z2) (sub z1 z2)))))

;; Points as lists
;(define (dist3d p1 p2)
;"Calculate 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)"
;  (let ( (x1 (p1 0)) (y1 (p1 1)) (z1 (p1 2))
;         (x2 (p2 0)) (y2 (p2 1)) (z2 (p2 2)) )
;    (sqrt (add (mul (sub x1 x2) (sub x1 x2))
;               (mul (sub y1 y2) (sub y1 y2))
;               (mul (sub z1 z2) (sub z1 z2))))))

;; @syntax (dist3d-2 x1 y1 z1 x2 y2 z2)
;; @description Calculate the square of 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)
;; @param <x1,y1,z1> 3D cartesian coordinates of point P1
;; @param <x2,y2,z2> 3D cartesian coordinates of point P2
;; @return square of 3D cartesian distance (float)
;; @example
;; (dist3d-2 1 3 1 5 3 1)  ==> 16
(define (dist3d-2 x1 y1 z1 x2 y2 z2)
"Calculate the square of 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)"
  (let ( (x1 (p1 0)) (y1 (p1 1)) (z1 (p1 2))
         (x2 (p2 0)) (y2 (p2 1)) (z2 (p2 2)) )
  (add (mul (sub x1 x2) (sub x1 x2))
       (mul (sub y1 y2) (sub y1 y2))
       (mul (sub z1 z2) (sub z1 z2)))))

;; Points as lists
;(define (dist3d-2 p1 p2)
;"Calculate the square of 3D Cartesian distance of two points P1=(x1 y1 z1) e P2=(x2 y2 z2)"
;  (let ( (x1 (p1 0)) (y1 (p1 1)) (z1 (p1 2))
;         (x2 (p2 0)) (y2 (p2 1)) (z2 (p2 2)) )
;  (add (mul (sub x1 x2) (sub x1 x2))
;       (mul (sub y1 y2) (sub y1 y2))
;       (mul (sub z1 z2) (sub z1 z2)))))

;; @syntax (dist p1 p2)
;; @description Calculate Cartesian distance of two points N dimensional: P1=(x1 y1 ... z1) e P2=(x2 y2 ... z2)
;; @param <p1> N-dimensional cartesian coordinates of point P1
;; @param <p2> N-dimensional cartesian coordinates of point P2
;; @return N-dimensional cartesian distance (float)
;; @example
;; (dist '(0 0) '(1 1))              ==> 1.414213562373095
;; (dist '(-4 -5 -6 -7) '(1 2 3 4))  ==> 16.61324772583615
(define (dist p1 p2)
"Calculate Cartesian distance of two points N dimensional: P1=(x1 y1 ... z1) e P2=(x2 y2 ... z2)"
  (sqrt (apply add (map (fn(x) (mul x x)) (map sub p1 p2)))))

;; @syntax (norm v)
;; @description Calculate the norm of a vector of arbitrary length (distance from origin)
;; @param <v> N-dimensional cartesian coordinates of a vector (point)
;; @return norm of vector (float)
;; @example
;; (norm '(1 2 3))  ==> 3.741657386773941
;; (norm '(1 1 1))  ==> 1.732050807568877
(define (norm v)
"Calculate the norm of a vector of arbitrary length (distance from origin)"
  (sqrt (apply add (map (fn(x) (mul x x)) v))))

;; @syntax (dist-manh4 x1 y1 x2 y2)
;; @description Calculate Manhattan distance (4 directions - rook) of two points P1=(x1 y1) e P2=(x2 y2)
;; @param <x1,y1> 2D cartesian coordinates of point P1
;; @param <x2,y2> 2D cartesian coordinates of point P2
;; @return manhattan distance (4 directions) (float)
;; @example
;; (dist-manh4 1 2 5 5)  ==> 7
(define (dist-manh4 x1 y1 x2 y2)
"Calculate Manhattan distance (4 directions - rook) of two points P1=(x1 y1) e P2=(x2 y2)"
  (add (abs (sub x1 x2)) (abs (sub y1 y2))))

;; @syntax (dist-manh8 x1 y1 x2 y2)
;; @description Calculate Manhattan distance (8 directions - queen) of two points P1=(x1 y1) e P2=(x2 y2)
;; @param <x1,y1> 2D cartesian coordinates of point P1
;; @param <x2,y2> 2D cartesian coordinates of point P2
;; @return manhattan distance (8 directions) (float)
;; @example
;; (dist-manh8 1 2 5 5)  ==> 4
(define (dist-manh8 x1 y1 x2 y2)
"Calculate Manhattan distance (8 directions - queen) of two points P1=(x1 y1) e P2=(x2 y2)"
  (max (abs (sub x1 x2)) (abs (sub y1 y2))))

;; @syntax (dist-chebyshev x1 y1 x2 y2)
;; @description Calculate Chebyshev distance of two points P1=(x1 y1) e P2=(x2 y2)
;; @param <x1,y1> 2D cartesian coordinates of point P1
;; @param <x2,y2> 2D cartesian coordinates of point P2
;; @return Chebishev distance (float)
;; @example
;; (dist-chebyshev 1 2 5 5)  ==> 4
;; (dist-chebyshev 1 1 2 2)  ==> 1
(define (dist-chebyshev x1 y1 x2 y2)
"Calculate Chebyshev distance of two points P1=(x1 y1) e P2=(x2 y2)"
  (max (abs (sub x2 x1)) (abs (sub y2 y1))))

;; @syntax (dist-chebyshevN p1 p2)
;; @description Calculate Chebyshev distance of two points N dimensional: P1=(x1 y1 ... z1) e P2=(x2 y2 ... z2)
;; @param <p1> N-dimensional cartesian coordinates of point P1
;; @param <p2> N-dimensional cartesian coordinates of point P2
;; @return Chebishev distance (float)
;; @example
;; (dist-chebyshevN '(1 2 3 4) '(4 7 8 2))  ==> 5
;; (dist-chebyshevN '(1 2) '(5 5))  ==> 4
(define (dist-chebyshevN p1 p2)
"Calculate Chebyshev distance of two points N dimensional: P1=(x1 y1 ... z1) e P2=(x2 y2 ... z2)"
  (apply max (map (fn(x y) (abs (sub x y))) p1 p2)))

;; @syntax (dist-earth lat1 lon1 lat2 lon2)
;; @description Calculate the minimal distance of two points on a sphere with haversine formula
;; @param <lat1,lon1> geographic coordinates of point P1 (decimal degrees)
;; @param <lat2,lon2> geographic coordinates of point P2 (decimal degrees)
;; @return great-circle distance between two points (float)
;; @example
;; (dist-earth 42.123456 13.123456 54.654321 8.654321)    ==> 1431.173709679866
;; (dist-earth 42.123456 -10.123456 54.654321 -2.654321)  ==> 1496.522788559527
(define (dist-earth lat1 lon1 lat2 lon2)
"Calculate the minimal distance of two points on a sphere with haversine formula"
  (local (r dlat dlon a c d)
  (setq r 6371) ; raggio medio della terra in km
  (setq dlat (deg-rad (sub lat2 lat1))) ; delta lat (in radianti)
  (setq dlon (deg-rad (sub lon2 lon1))) ; delta lon (in radianti)
  (setq a (add (mul (sin (div dlat 2)) (sin (div dlat 2)))
               (mul (cos (deg-rad lat1)) (cos (deg-rad lat2))
                    (sin (div dlon 2)) (sin (div dlon 2)))))
  (setq c (mul 2 (atan2 (sqrt a) (sqrt (sub 1 a)))))
  (setq d (mul r c)))) ; distanza in km

;; @syntax (parallel? p1 p2 p3 p4 eps)
;; @description Check if two segments s1(p1 p2) and s2(p3 p4) are parallel
;; @param <p1> first point of first segment (x1 y1)
;; @param <p2> second point of first segment (x2 y2)
;; @param <p3> first point of second segment (x3 y3)
;; @param <p4> second point of second segment (x4 y4)
;; @param <eps> tolerance threshold
;; @return true or nil
;; @example
;; (parallel? '(1 1) '(3 3) '(2 2) '(4 4))            ==> true
;; (parallel? '(1 1) '(3 3) '(2 2) '(4 4.0001))       ==> nil
;; (parallel? '(1 1) '(3 3) '(2 2) '(4 4.0001) 0.01)  ==> true
;; (parallel? '(1 1) '(3 3) '(1 2) '(3 5))            ==> nil
(define (parallel? p1 p2 p3 p4 eps)
"Check if two segments s1(p1 p2) and s2(p3 p4) are parallel"
  (let ( (v1x (sub (p2 0) (p1 0)))
         (v1y (sub (p2 1) (p1 1)))
         (v2x (sub (p4 0) (p3 0)))
         (v2y (sub (p4 1) (p3 1)))
         (eps (or eps 0)) )
    ; Due segmenti sono paralleli se risulta (v1x * v2y) = (v1y  * v2x)
    ; eps: soglia di accettazione
    (<= (abs (sub (mul v1x v2y) (mul v1y v2x))) eps)))

;; @syntax (orthogonal? p1 p2 p3 p4 eps)
;; @description Check if two segments s1(p1 p2) and s2(p3 p4) are orthogonal
;; @param <p1> first point of first segment (x1 y1)
;; @param <p2> second point of first segment (x2 y2)
;; @param <p3> first point of second segment (x3 y3)
;; @param <p4> second point of second segment (x4 y4)
;; @param <eps> tolerance threshold
;; @return true or nil
;; @example
;; (orthogonal? '(0 0) '(2 0) '(0 1) '(0 4))               ==> true
;; (orthogonal? '(0 0) '(2 0) '(0 1) '(0.1 4))             ==> nil
;; (orthogonal? '(0 0) '(2 0) '(0 1) '(0.001 4) 1e-6)      ==> nil
;; (orthogonal? '(0 0) '(2 0) '(0 1) '(0.0000001 4) 1e-6)  ==> true
;; (orthogonal? '(0 0) '(1 1) '(0 0) '(1 -1))              ==> true
;; (orthogonal? '(0 0) '(1 1) '(0 0) '(2 2))               ==> nil
(define (orthogonal? p1 p2 p3 p4 eps)
"Check if two segments s1(p1 p2) and s2(p3 p4) are orthogonal"
  (let ( (v1x (sub (p2 0) (p1 0)))
         (v1y (sub (p2 1) (p1 1)))
         (v2x (sub (p4 0) (p3 0)))
         (v2y (sub (p4 1) (p3 1)))
         (eps (or eps 0)) )
    ; Due segmenti sono perpendicolari se il loro prodotto scalare vale 0
    ; eps: soglia di accettazione
    (<= (abs (add (mul v1x v2x) (mul v1y v2y))) eps)))

;===========================================================================
;===========================================================================
;; <p><b><center>GRAPHS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (solve-maze maze start-row start-col end-row end-col show)
;; @description Search a solution path in a maze
;; @param <maze> matrix of cells (0 = wall)
;; @param <start-row> starting row
;; @param <end-row> ending row
;; @param <start-col> starting col
;; @param <end-col> ending col
;; @param <show> if true then print the maze with solution
;; @return solution path (list of cells) or '()
;; @example
;;(setq matrice (array 12 20 '(
;; 1 1 0 1 0 1 1 1 0 1 0 1 0 1 0 0 1 1 1 0
;; 0 1 1 1 0 0 1 1 1 1 1 0 0 1 1 1 1 1 0 0
;; 0 1 0 0 0 0 0 1 1 0 0 0 1 0 0 0 0 1 0 1
;; 0 1 1 1 1 1 0 0 0 1 1 1 1 0 0 0 1 0 1 0
;; 1 0 0 0 0 1 0 0 1 0 1 0 1 0 0 1 1 0 0 0
;; 1 0 0 0 0 1 1 1 1 0 1 0 1 0 0 1 1 0 0 0
;; 1 0 0 0 0 0 0 0 1 0 1 0 1 0 0 1 0 1 0 0
;; 1 0 0 0 0 0 0 0 1 1 1 0 1 0 0 1 1 1 0 0
;; 1 0 0 0 0 0 0 0 1 0 0 0 1 1 1 1 0 1 1 1
;; 1 0 0 0 0 0 0 0 1 0 0 0 1 0 0 1 0 0 0 1
;; 1 0 0 0 0 0 0 0 1 0 0 0 1 0 0 1 0 0 0 1
;; 1 0 0 0 0 0 0 0 1 0 0 0 1 0 0 1 0 0 0 1)))
;;(solve-maze matrice 0 0 11 19 true)
;; ■ ■ 0 1 0 1 1 1 0 1 0 1 0 1 0 0 1 1 1 0
;; 0 ■ 1 1 0 0 1 1 1 1 1 0 0 1 1 1 1 1 0 0
;; 0 ■ 0 0 0 0 0 1 1 0 0 0 1 0 0 0 0 1 0 1
;; 0 ■ ■ ■ ■ ■ 0 0 0 1 ■ ■ ■ 0 0 0 1 0 1 0
;; 1 0 0 0 0 ■ 0 0 1 0 ■ 0 ■ 0 0 1 1 0 0 0
;; 1 0 0 0 0 ■ ■ ■ ■ 0 ■ 0 ■ 0 0 1 1 0 0 0
;; 1 0 0 0 0 0 0 0 ■ 0 ■ 0 ■ 0 0 1 0 1 0 0
;; 1 0 0 0 0 0 0 0 ■ ■ ■ 0 ■ 0 0 ■ ■ ■ 0 0
;; 1 0 0 0 0 0 0 0 1 0 0 0 ■ ■ ■ ■ 0 ■ ■ ■
;; 1 0 0 0 0 0 0 0 1 0 0 0 1 0 0 1 0 0 0 ■
;; 1 0 0 0 0 0 0 0 1 0 0 0 1 0 0 1 0 0 0 ■
;; 1 0 0 0 0 0 0 0 1 0 0 0 1 0 0 1 0 0 0 ■
;; ((0 0) (0 1) (1 1) (2 1) (3 1) (3 2) (3 3) (3 4) (3 5) (3 10) (3 11)
;;  (3 12) (4 5) (4 10) (4 12) (5 5) (5 6) (5 7) (5 8) (5 10) (5 12)
;;  (6 8) (6 10) (6 12) (7 8) (7 9) (7 10) (7 12) (7 15) (7 16) (7 17)
;;  (8 12) (8 13) (8 14) (8 15) (8 17) (8 18) (8 19) (9 19) (10 19)
;;  (11 19))
;;(setq matrice (array righe colonne '(
;; 1 1 0 1 0 1 1 0 1
;; 0 1 1 1 0 0 1 1 1
;; 0 1 0 0 0 0 0 1 0
;; 0 1 1 1 1 1 0 1 1
;; 1 0 0 0 0 1 0 0 1
;; 1 0 0 0 0 1 1 1 1
;; 1 1 1 1 1 0 1 0 1
;; 1 0 0 0 1 0 1 0 1
;; 1 0 0 0 1 1 1 0 1)))
;;(solve-maze matrice 8 0 0 8 true)
;; 1 1 0 1 0 1 1 0 ■
;; 0 1 1 1 0 0 1 ■ ■
;; 0 1 0 0 0 0 0 ■ 0
;; 0 1 1 1 1 1 0 ■ ■
;; 1 0 0 0 0 1 0 0 ■
;; 1 0 0 0 0 1 ■ ■ ■
;; ■ ■ ■ ■ ■ 0 ■ 0 1
;; ■ 0 0 0 ■ 0 ■ 0 1
;; ■ 0 0 0 ■ ■ ■ 0 1
;; ((0 8) (1 7) (1 8) (2 7) (3 7) (3 8) (4 8) (5 6) (5 7) (5 8) (6 0) (6 1)
;;  (6 2) (6 3) (6 4) (6 6) (7 0) (7 4) (7 6) (8 0) (8 4) (8 5) (8 6))
; This algorithm does not guarantee that the solution found is the shortest one.
(define (solve-maze maze start-row start-col end-row end-col show)
"Search a solution path in a maze"
  (local (matrix row col wall visited solution-path s-row s-col e-row e-col out)
    ; lista soluzione percorso
    (setq out '())
    ; matrice labirinto
    (setq matrix maze)
    ; carattere che rappresenta il muro "0"
    (setq wall 0)
    ; righe della matrice
    (setq row (length matrix))
    ; colonne della matrice
    (setq col (length (first matrix)))
    ; matrice delle celle visitate
    (setq visited (array row col '(nil)))
    ; matrice soluzione del labirinto
    (setq solution-path (array row col '(nil)))
    ; posizione iniziale: riga
    (setq s-row start-row)
    ; posizione iniziale: colonna
    (setq s-col start-col)
    ; posizione finale: riga
    (setq e-row end-row)
    ; posizione finale: colonna
    (setq e-col end-col)
    ;
    ; funzione recursive solve
    ;
    (define (recursive-solve x y)
      (catch
        (local (return)
          ;controllo se abbiamo raggiunto la fine e non è un muro
          (if (and (= x e-row) (= y e-col) (!= (matrix x y) wall))
              (throw (setf (solution-path x y) true)))
          ; cella muro o cella visitata
          (if (or (= (matrix x y) wall) (= (visited x y) true)) (throw nil))
          ; imposta cella come visitata
          (setf (visited x y) true)
          ; controllo posizione riga 0
          (if (!= x 0)
              ; richiama la funzione una riga in basso
              (if (recursive-solve (- x 1) y)
                  (throw (setf (solution-path x y) true))))
          ; controllo posizione riga (row - 1)
          (if (!= x (- row 1))
              ; richiama la funzione una riga in alto
              (if (recursive-solve (+ x 1) y)
                  (throw (setf (solution-path x y) true))))
          ; controllo posizione colonna 0
          (if (!= y 0)
              ; richiama la funzione una colonna a sinistra
              (if (recursive-solve x (- y 1))
                  (throw (setf (solution-path x y) true))))
          ; controllo posizione colonna (col - 1)
          (if (!= y (- col 1))
              ; richiama la funzione una colonna a destra
              (if (recursive-solve x (+ y 1))
                  (throw (setf (solution-path x y) true))))
          return))); recursive-solve
    ;
    ; Chiama la funzione ricorsiva di soluzione
    ; Se (recursive-solve s-row s-col) ritorna nil,
    ; allora il labirinto non ha soluzione.
    ; Altrimenti la matrice booleana "solution-path"
    ; contiene la soluzione (valori true).
    (if (recursive-solve s-row s-col)
        (begin
          ; Se show = true --> stampa la soluzione
          (if show (show-aux solution-path))
          ; crea la lista con il percorso risolutivo
          (for (i 0 (- row 1))
            (for (j 0 (- col 1))
              (if (solution-path i j)
                  (push (list i j) out -1))))))
    out))
; funzione ausiliaria di stampa del labirinto (con soluzione)
(define (show-aux path)
  (local (row col)
    ; righe della matrice
    (setq row (length path))
    ; colonne della matrice
    (setq col (length (first path)))
    ; stampa
    (for (i 0 (- row 1))
      (for (j 0 (- col 1))
        ;(if (matrix i j) (print " ·") (print " 0"))
        ;(if (path i j) (print " ·") (print " " (matrix i j)))
        (if (path i j) (print " ■") (print " " (matrix i j))))
      (println))))

;; @syntax (gale-shapley prefs-a prefs-b)
;; @description Bind all the n items of group A with the n items of group B based on preferences of each items
;; @param <prefs-a> preferences of items of group A on items of group B (0, n-1)
;; @param <prefs-b> preferences of items of group B on items of group A (0, n-1)
;; @return list of item bindings ((a1 b1) (a2 b2) ... (an bn))
;; @example
;; (setq m '((4 1 2 3 0) (1 4 0 2 3) (3 2 1 0 4) (0 1 2 3 4) (4 1 2 3 0)))
;; (setq w '((4 2 3 0 1) (0 1 2 4 3) (3 4 2 1 0) (4 1 0 3 2) (1 0 3 2 4)))
;; (gale-shapley m w)  ==> ((0 3) (1 1) (2 4) (3 2) (4 0))
(define (gale-shapley prefs-a prefs-b)
"Bind all the n items of group A with the n items of group B based on preferences of each items"
  (local (len cur-choices links singles rank i j)
    (setq len (length prefs-a))
    (setq cur-choices (array len '(0)))
    (setq links (array len '(nil)))
    (setq rank (array len len '(0)))
    (for (j 0 (- len 1))
      (for (r 0 (- len 1))
        (setf (rank j (prefs-b j r)) r)))
    (setq singles (sequence 0 (- len 1)))
    (while singles
      (setq i (pop singles))
      (setq j (prefs-a i (cur-choices i)))
      (++ (cur-choices i))
      (cond ((nil? (links j))
             (setf (links j) i))
            ((< (rank j (links j)) (rank j i))
             (push i singles -1))
            (true
              (push (links j) singles -1)
              (setf (links j) i))))
    (sort (map (fn(x) (list $idx x)) links))))

;; @syntax (bellman-ford graph start-node)
;; @description Calculate shortest paths from a node to all other nodes of a graph
;; @param <graph> list of arcs (start-node end-node arc-weigth). $idx is the number of the arc.
;; @param <start> starting node
;; @return list of shortest path from start-node to all the nodes (start-node destination-node (nodes of path) length-of-path)
;; @example
;;   +---+  5   +---+  3   +---+
;;   | 0 |----->| 1 |----->| 3 |
;;   +---+      +---+      +---+
;;     |          ^          |
;;     |          | 6        |
;;     |          |          |
;;     | 4      +---+      2 |
;;     +------->| 2 |<-------+
;;              +---+
;; (setq grafo '((0 1 5) (0 2 4) (1 3 3) (2 1 6) (3 2 2)))
;; (bellman-ford grafo 0)  ==> ((0 0 (0) 0) (0 1 (0 1) 5) (0 2 (0 2) 4) (0 3 (0 1 3) 8))
;; (bellman-ford grafo 3)  ==> ((3 0 (0) 9999999) (3 1 (3 2 1) 8) (3 2 (3 2) 2) (3 3 (3) 0))
(define (bellman-ford graph start)
"Calculate shortest paths from a node to all other nodes of a graph"
  (local (max-val archi vertici edge dist pred u v w)
    (setq max-val 9999999)
    (setq archi (length graph))
    (setq vertici (length (unique (flat (map (fn(x) (list (x 0) (x 1))) graph)))))
    (setq edge (array archi '((0 0 0))))
    (setq dist (array vertici (list max-val)))
    (setq path '())
    (setq pred (array vertici '(nil)))
    (setf (dist start) 0)
    (for (i 1 (- vertici 1))
      (for (j 0 (- archi 1))
        (setq u ((graph j) 0))
        (setq v ((graph j) 1))
        (setq w ((graph j) 2))
        (if (and (!= (dist u) max-val)
                 (< (add (dist u) w) (dist v)))
          (begin
            (setf (dist v) (add (dist u) w))
            (setf (pred v) u)))))
    (for (j 0 (- archi 1))
      (setq u ((graph j) 0))
      (setq v ((graph j) 1))
      (setq w ((graph j) 2))
      (if (and (!= (dist u) max-val)
               (< (add (dist u) w) (dist v)))
          (setq negative true)))
    (if negative nil (bf-make-solution))))
; bellmann-ford make solution
(define (bf-make-solution)
  (let (out '())
    (for (i 0 (- vertici 1))
      (cond ((= start i)
             (push (list start i (list i) 0) out -1))
            (true
             (push (list start i (build-path pred i) (dist i)) out -1))))
    out))
; bellmann-ford build path
(define (build-path pred dest)
  (local (path curr))
  (setq path '())
  (setq curr dest)
  (while (!= curr nil)
    (push curr path)
    (setq curr (pred curr)))
  path)

;===========================================================================
;===========================================================================
;; <p><b><center>RANDOM</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (rand-range min-val max-val)
;; @description Generate a random integer in a closed range
;; @param <min-val> minimum value of range (int)
;; @param <max-val> maximum value of range (int)
;; @return Random integer within closed range
;; @example
;; (rand-range -10 10)  ==> -6
;; (rand-range 1 1)     ==> 1
;; (rand-range -5 5)    ==> -5
(define (rand-range min-val max-val)
"Generate a random integer in a closed range"
  (if (> min-val max-val) (swap min-val max-val))
  (+ min-val (rand (+ (- max-val min-val) 1))))

;; @syntax (rand-range-f min-val max-val)
;; @description Generate a random float in a closed range
;; @param <min-val> minimum value of range (int or float)
;; @param <max-val> maximum value of range (int or float)
;; @return Random float within closed range
;; @example
;; (rand-range-f -10 10)   ==> -4.877162999359111
;; (rand-range-f 0.5 1.0)  ==> 0.8731040375988037
;; (rand-range-f -5 5)     ==> 2.81945249794
(define (rand-range-f min-val max-val)
"Generate a random float in a closed range"
  (if (> min-val max-val) (swap min-val max-val))
  (add min-val (random 0 (sub max-val min-val))))

;; @syntax (rand-ascii len start-char end-char)
;; @description Generate a random string of a given length in a range of characters
;; @param <len> length of random string
;; @param <start-char> start range (char or ascii code of char)
;; @param <end-char> end range (char or ascii code of char)
;; @return random string
;; @example
;; (rand-ascii 10 "a" "z")  --> "ewsnhacjde"
;; (rand-ascii 12 32 126)   --> "}J+  CRVYY/^"
(define (rand-ascii len start-char end-char)
"Generate a random string of a given length in a range of characters"
  (let ( (min-val (if (string? start-char) (char start-char) start-char))
         (max-val (if (string? end-char)   (char end-char) end-char)) )
    (if (> min-val max-val) (swap min-val max-val))
    (join (collect (char (+ min-val (rand (+ (- max-val min-val) 1)))) len))))

;; @syntax (rand-circle1 num-pts)
;; @description Generate points (x y) within a circle (center (0,0) - radius = 1) (linear method)
;; @param <num-pts> number of points to generate
;; @return List of points (x y)
;; @example
;; (rand-circle1 2)  ==> ((-0.6133915219580676 0.6174810022278512) (0.1700186162907804-0.04025391399884026))
(define (rand-circle1 num-pts)
"Generate points (x y) within a circle (center (0,0) - radius = 1) (linear method)"
  (local (out i x y)
    (setq out '())
    (setq i 1)
    (while (<= i num-pts)
      (setq x (add -1 (random 0 2)))
      (setq y (add -1 (random 0 2)))
      (when (<= (add (mul x x) (mul y y)) 1)
            (push (list x y) out -1)
            (++ i)))
    out))

;; @syntax (rand-circle2 num-pts)
;; @description Generate points (x y) within a circle (center (0,0) - radius = 1) (polar method)
;; @param <num-pts> number of points to generate
;; @return List of points (x y)
;; @example
;; (rand-circle2 2)  ==> ((-0.8398662207229641 -0.071597139602192) (0.5489153793116122 0.05183415134442773))
(define (rand-circle2 num-pts)
"Generate points (x y) within a circle (center (0,0) - radius = 1) (polar method)"
  (local (out i u r theta x y pi)
    (setq out '())
    (setq i 0)
    (setq pi (mul 2 (acos 0)))
    (for (i 1 num-pts)
      (setq u (random))
      (setq r (sqrt u))
      (setq theta (mul (random) (mul 2 pi)))
      (setq x (mul r (cos theta)))
      (setq y (mul r (sin theta)))
      (push (list x y) out -1))
    out))

;; @syntax (rand-list nums min-val max-val type min-len max-len)
;; @description Generate a list with random elements
;; param <nums> number of elements to generate
;; param <min-val> minimum value of the range (number or character)
;; param <max-val> maximum value of the range (number or character)
;; param <type> integers "i" or floating point "f" or characters "c" or strings "s"
;; param <min-len> minimum string length
;; param <max-len> maximum string length
;; @return list with random elements
;; @example
;; (rand-list 10 5 25 "i")     --> (8 5 13 10 7 22 6 13 25 11)
;; (rand-list 3 0 1 "f")       --> (0.6226386303292947 0.6444898831141087 0.7817926572466201)
;; (rand-list 10 48 57 "c")    --> ("7" "1" "9" "9" "3" "9" "4" "8" "6" "0")
;; (rand-list 10 "A" "Z" "c")  --> ("R" "I" "X" "H" "A" "A" "L" "F" "X" "M")
;; (rand-list 4 "a" "z" "s" 1 6)  --> ("ucdiwl" "pjw" "m" "qtd")
(define (rand-list nums min-val max-val type min-len max-len)
"Generate a list with random elements"
  (let (out '())
    (cond ((= type "i") ; numeri interi
            (for (i 1 nums)
              (push (+ min-val (rand (+ (- max-val min-val) 1))) out -1)))
          ((= type "f") ; numeri floating
            (for (i 1 nums)
              (push (add min-val (random 0 (sub max-val min-val))) out -1)))
          ((= type "c") ; caratteri
            (if (string? min-val) (setq min-val (char min-val)))
            (if (string? max-val) (setq max-val (char max-val)))
            (for (i 1 nums)
               (push (char (+ min-val (rand (+ (- max-val min-val) 1)))) out -1)))
          ((= type "s") ; stringhe
            (if (string? min-val) (setq min-val (char min-val)))
            (if (string? max-val) (setq max-val (char max-val)))
            (for (i 1 nums)
              (setq len (+ min-len (rand (+ (- max-len min-len) 1))))
              (push (join (collect (char (+ min-val (rand (+ (- max-val min-val) 1)))) len)) out -1))))
    out))

;; @syntax (faircoin)
;; @description Simulate the flip of a coin (John VonNeumann algorithm)
;; @param <> none
;; @return 0 or 1
;; @example
;; (faircoin)                      ==> 0
;; (map faircoin (sequence 1 10))  ==> (0 1 0 0 1 0 0 1 1 1)
(define (faircoin)
"Simulate the flip of a coin (John VonNeumann algorithm)"
  (local (a b res)
    (setq res nil)
    (while (= res nil)
      (setq a (rand 2))
      (setq b (rand 2))
      (if (!= a b)
          (setq res a))) res))

;; @syntax (rand-pick lst)
;; @description Pick an index from a list of relative probabilities
;; @param <lst> list of probabilities of each index (sum = 1)
;; @return index (integer)
;; @example
;; (rand-pick '(0.3 0.6 0.1))  ==> 1
;; (setq arr (array 5 '(0)))
;; (dotimes (i 1e6) (++ (arr (rand-pick '(0 0.1 0.45 0.25 0.2)))))
;; arr  ==> (0 99688 449735 250016 200561)
(define (rand-pick lst)
"Pick an index from a list of relative probabilities"
  (local (rnd stop out)
    ; generiamo un numero random diverso da 1 e da 0
    ; (per evitare errori di arrotondamento)
    (while (and (setq rnd (random)) (or (= rnd 0) (= rnd 1))))
    (setq stop nil)
    ; ciclo per ogni valore di probabilità della lista...
    (dolist (p lst stop)
      ; sottraiamo la probabilità corrente al numero random
      (setq rnd (sub rnd p))
      ; se il risultato è minore di zero,
      ; allora restituiamo l'indice della probabilità corrente
      (if (< rnd 0) (set 'out $idx 'stop true)))
    out))

;; @syntax (sample-list num lst)
;; @description Generate a sample of items from a list
;; @param <num> numbers of items of the sample (int)
;; @param <lst> list of items
;; @return list of num items
;; @example
;; (sample-list 5 '(a b c d a e f b g h g))  ==> (e c a b a)
;; (sample-list 5 '(a b c d a e f b g h g))  ==> (a h b g f)
(define (sample-list num lst)
"Generate a sample of items from a list"
  (if (> num (length lst)) '()
      (slice (randomize lst) 0 num )))

;; @syntax (sample-list-unique num lst)
;; @description Generate a sample of unique items from a list
;; @param <num> numbers of integer of the sample (int)
;; @param <lst> list of items
;; @return list of num unique items
;; @example
;; (sample-list-unique 5 lst)  ==> (h e c b g)
;; (sample-list-unique 5 lst)  ==> (a d b e g)
(define (sample-list-unique num lst)
  (letn ( (len (length lst))
          (unici (unique lst)) (len-u (length unici))
          (out '()) )
    (if (> num len-u) '()
        (begin
          ; creazione di una hashmap
          (new Tree 'myHash)
          (until (= (length (myHash)) num)
            ; estrae un elemento a caso
            (setq value (lst (rand len)))
            ; inserisce valore casuale nell'hash (se non esiste)
            (myHash (string value) value))
          ; assegnazione dei valori dell'hashmap ad una lista
          (setq out (myHash))
          (setq out (map last out))
          ; eliminazione dell'hashmap
          (delete 'myHash)
          ; out è ordinata, quindi dobbiamo mischiare gli elementi
          (randomize out)))))
; Version for items equally probable
;(define (sample-list-unique num lst)
;  (letn ( (unici (unique lst)) (len (length unici)) )
;    (if (> num len) '()
;        (slice (randomize unici) 0 num))))

;; @syntax (one-in prob)
;; @description Convert probability (0..1) to '1 in x events'
;; @param <prob> probability (0..1) float
;; @return integer
;; @example
;; (one-in 0.0234)  ==> 43
(define (one-in prob)
"Convert probability (0..1) to '1 in x events'"
  (int (add 0.5 (div prob))))

;; @syntax (die6)
;; @description Roll a die with 6 sides
;; @return integer
;; @example
;; (die6)  ==> 5
(define (die6)
"Roll a die with 6 sides"
  (+ (rand 6) 1))

;; @syntax (die s)
;; @description Roll a die with S sides
;; @param <s> number of sides (integer)
;; @return integer
;; @example (die 4)  ==> 1
(define (die s)
"Roll a die with S sides"
  (+ (rand s) 1))

;; @syntax (dice6-sum n)
;; @description Roll N dice with 6 sides and return the sum of numbers
;; @param <n> number of dice (integer)
;; @return integer
;; @example
;; (dice6-sum 10)  ==> 19
(define (dice6-sum n)
"Roll N dice with 6 sides and return the sum of numbers"
  (+ n (apply + (rand 6 n))))

;; @syntax (dice-sum n s)
;; @description Roll N dice with S sides and return the sum of numbers
;; @param <n> number of dice (integer)
;; @param <s> number of sides (integer)
;; @return integer
;; @example
;; (dice-sum 10 4)  ==> 19
 (define (dice-sum n s)
"Roll N dice with S sides and return the sum of numbers"
  (+ n (apply + (rand s n))))

;; @syntax (dice6-lst n)
;; @description Roll N dice with 6 sides and return the list of numbers
;; @param <n> number of dice (integer)
;; @return list
;; @example (dice6-lst 5)  => (4 2 5 4 3)
(define (dice6-lst n)
"Roll N dice with 6 sides and return the list of numbers"
  (map (curry + 1) (rand 6 n)))

;; @syntax (dice-lst n s)
;; @description Roll N dice with S sides and return the list of numbers
;; @param <n> number of dice (integer)
;; @param <s> number of sides (integer)
;; @return list
;; @example (dice-lst 4 8)  ==> (3 8 7 6)
(define (dice-lst n s)
"Roll N dice with S sides and return the list of numbers"
  (map (curry + 1) (rand s n)))

;; @syntax (dice6-lst-freq n)
;; @description Roll N dice with 6 sides and return a list with the frequency of all sides
;; @param <n> number of dice (integer)
;; @return list
;; @example (dice6-lst-freq 20)  ==> (3 3 3 4 3 4)
(define (dice6-lst-freq n)
"Roll N dice with 6 sides and return a list with the frequency of all sides"
  (count '(1 2 3 4 5 6) (dice6-lst n)))

;; @syntax (dice-lst-freq n s)
;; @description Roll N dice with S sides and return a list with the frequency of all sides
;; @param <n> number of dice (integer)
;; @param <s> number of sides (integer)
;; @return list
;; @example (dice-lst-freq 20 8)  ==> (5 3 2 2 5 1 1 1)
(define (dice-lst-freq n s)
"Roll N dice with S sides and return a list with the frequency of all sides"
  (count (sequence 1 s) (dice-lst n s)))

;; @syntax (dice-pick lst)
;; @description Roll a non-fair dice with N sides
;; @param <lst> list of probabilities (one prob for each sides, sum = 1)
;; @return random number (0..N-1) with the distribution of the probabilities predefined (float)
;; Example
;; (setq p '(0.05 0.15 0.35 0.45))
;; (apply add p)  ==> 1
;; (setq vet (array 4 '(0)))
;; (for (i 0 999999) (++ (vet (dice-pick p))))
;; vet  ==> (49985 149556 350044 450415)
;; (apply + vet)  ==> 1000000
(define (dice-pick lst)
"Roll a non-fair dice with N sides"
  (local (rnd stop out)
    ; generiamo un numero random diverso da 1
    ; (per evitare errori di arrotondamento)
    (while (= (setq rnd (random)) 1))
    (setq stop nil)
    (dolist (p lst stop)
      ; sottraiamo la probabilità corrente al numero random...
      (setq rnd (sub rnd p))
      ; se il risultato è minore di zero,
      ; allora restituiamo l'indice della probabilità corrente
      (if (< rnd 0)
          (set 'out $idx 'stop true)))
    out))

;===========================================================================
;===========================================================================
;; <p><b><center>DATES</center></b></p>
;===========================================================================
;===========================================================================

; julian day = 0 on monday 1 january 4713 B.C. (-4712 1 1)
;; @syntax (gdate-julian gdate)
;; @description Convert gregorian date to julian day number (valid only from 15 ottobre 1582 A.D.)
;; @param <gdate> gregorian date (year month day)
;; @return julian day number (int)
;; @example
;; (gdate-julian '(2019 11 11))  ==> 2458799
;; (gdate-julian '(2019 11 12))  ==> 2458800
;; (gdate-julian '(-4712 1 1))   ==> 38
(define (gdate-julian gdate)
"Convert gregorian date to julian day number (valid only from 15 ottobre 1582 A.D.)"
  (local (a y m)
    (setq a (/ (- 14 (gdate 1)) 12))
    (setq y (+ (gdate 0) 4800 (- a)))
    (setq m (+ (gdate 1) (* 12 a) (- 3)))
    (+ (gdate 2) (/ (+ (* 153 m) 2) 5) (* y 365) (/ y 4) (- (/ y 100)) (/ y 400) (- 32045))))

;; @syntax (jdate-julian jdate)
;; @description Convert julian date to julian day number (valid only until 4 ottobre 1582 A.D.)
;; @param <jdate> julian date (year month day)
;; @return julian day number (int)
;; @example
;; (jdate-julian '(2019 11 11))  ==> 2458812
;; (jdate-julian '(2019 11 12))  ==> 2458813
;; (jdate-julian '(-4712 1 1))   ==> 0
(define (jdate-julian jdate)
"Convert julian date to julian day number (valid only until 4 ottobre 1582 A.D.)"
  (local (a y m)
    (setq a (/ (- 14 (jdate 1)) 12))
    (setq y (+ (jdate 0) 4800 (- a)))
    (setq m (+ (jdate 1) (* 12 a) (- 3)))
    (+ (jdate 2) (/ (+ (* 153 m) 2) 5) (* y 365) (/ y 4) (- 32083))))

;; @syntax (julian-gdate jd)
;; @description Convert julian day number to gregorian date (valid only from 15 ottobre 1582 A.D.)
;; @param <jd> julian day number (int)
;; @return gregorian date (year month day)
;; @example
;; (julian-gdate 2458799)                       ==> (2019 11 11)
;; (julian-gdate 2458800)                       ==> (2019 11 12)
;; (julian-gdate (gdate-julian '(2019 11 12)))  ==> (2019 11 12)
(define (julian-gdate jd)
"Convert julian day number to gregorian date (valid only from 15 ottobre 1582 A.D.)"
  (local (a b c d e m)
    (setq a (+ jd 32044))
    (setq b (/ (+ (* 4 a) 3) 146097))
    (setq c (- a (/ (* b 146097) 4)))
    (setq d (/ (+ (* 4 c) 3) 1461))
    (setq e (- c (/ (* 1461 d) 4)))
    (setq m (/ (+ (* 5 e) 2) 153))
    (list
      (+ (* b 100) d (- 4800) (/ m 10))
      (+ m 3 (- (* 12 (/ m 10))))
      (+ e (- (/ (+ (* 153 m) 2) 5)) 1))))

;; @syntax (julian-jdate jd)
;; @description Convert julian day number to julian date (valid only until 4 ottobre 1582 A.D.)
;; @param <jd> julian day number (int)
;; @return julian date (year month day)
;; @example
;; (julian-jdate 2458812)  ==> (2019 11 11)
;; (julian-jdate 2458813)  ==> (2019 11 12)
;; (julian-jdate 0)        ==> (-4712 1 1)
(define (julian-jdate jd)
"Convert julian day number to julian date (valid only until 4 ottobre 1582 A.D.)"
  (local (a b c d e m)
    (setq a 0)
    (setq b 0)
    (setq c (+ jd 32082))
    (setq d (/ (+ (* 4 c) 3) 1461))
    (setq e (- c (/ (* 1461 d) 4)))
    (setq m (/ (+ (* 5 e) 2) 153))
    (list
      (+ (* b 100) d (- 4800) (/ m 10))
      (+ m 3 (- (* 12 (/ m 10))))
      (+ e (- (/ (+ (* 153 m) 2) 5)) 1))))

;; @syntax (julian-weekday jd)
;; @description Find the day of week (number) of a julian day number
;; @param <jd> julian day number (int)
;; @return day of week number (ISO: Mon=1 ... Sun=7) (int)
;; @example
;; (julian-weekday (gdate-julian '(1900 3 15)))  ==> 4
;; (julian-weekday (gdate-julian '(1821 5 5)))   ==> 6
;; (julian-weekday (jdate-julian '(1400 1 1)))   ==> 4
(define (julian-weekday jd)
"Find the day of week (number) of a julian day number"
  (+ (% jd 7) 1))

;; @syntax (gdate-diff gdate1 gdate2)
;; @description Calculate the difference between two gregorian dates
;; @param <gdate1> first gregorian date (year month day)
;; @param <gdate2> second gregorian date (year month day)
;; @return (date1 - date2 = interval of days) (int)
;; @example
;; (gdate-diff '(2012 11 28) '(2010 4 22))  ==> 951
(define (gdate-diff gdate1 gdate2)
"Calculate the difference between two gregorian dates"
  (- (gdate-julian gdate1) (gdate-julian gdate2)))

;; @syntax (gdate-add gdate num-days)
;; @description Add days to a gregorian date
;; @param <gdate> gregorian date (year month day)
;; @param <num-days> days to add (int)
;; @return gregorian date (year month day)
;; @example
;; (gdate-add '(1980 3 15) 10)  ==> (1980 3 25)
(define (gdate-add gdate num-days)
"Add days to a gregorian date"
  (julian-gdate (+ (gdate-julian gdate) num-days)))

;; @syntax (gdate-sub gdate num-days)
;; @description Subtract days from a gregorian date
;; @param <gdate> gregorian date (year month day)
;; @param <num-days> days to sub (int)
;; @return gregorian date (year month day)
;; @example
;; (gdate-sub '(1980 3 15) 31)  ==> (1980 2 13)
(define (gdate-sub gdate num-days)
"Subtract days from a gregorian date"
  (julian-gdate (- (gdate-julian gdate) num-days)))

;; @syntax (leap? year)
;; @description Check if a year is a leap year
;; @param <year> integer
;; @return true or nil
;; @example
;; (leap? 1980)  ==> true
;; (leap? 2001)  ==> nil
;; (leap? 1900)  ==> nil
(define (leap? year)
"Check if a year is a leap year"
  (or (zero? (% year 400))
      (and (zero? (% year 4)) (not (zero? (% year 100))))))

;; @syntax (data-list data1 data2)
;; @description Generate a list of dates (yyyy mm dd) from data1 to data2
;; @param <data1> date values
;; @param <data2> date values
;; @return list of dates ((yyyy1 mm1 dd1) ... (yyyy2 mm2 dd2))
;; @example
;; (data-list '(1981 1 1) '(1981 1 5))  ==> ((1981 1 1) (1981 1 2) (1981 1 3) (1981 1 4) (1981 1 5))
;; (length (data-list '(1981 1 1) '(1981 12 31)))  ==> 365
;; (length (data-list '(1980 1 1) '(1980 12 31)))  ==> 366
;; (length (data-list '(1980 2 22) '(1981 8 10)))  ==> 536
(define (data-list data1 data2)
"Generate a list of datas (YYYY MM DD) from data1 data2"
  (local (y1 m1 d1 y2 m2 d2 out md n1 n2 days data num-data stop)
    ; unpack data
    (map set '(y1 m1 d1) data1)
    (map set '(y2 m2 d2) data2)
    (setq out '())
    ; lista (mese giorni)
    (setq md '((1 31) (2 28) (3 31) (4 30) (5 31) (6 30)
              (7 31) (8 31) (9 30) (10 31) (11 30) (12 31)))
    ; valore numerico data1
    (setq n1 (int (format "%d%02d%02d" y1 m1 d1)))
    ; valore numerico data2
    (setq n2 (int (format "%d%02d%02d" y2 m2 d2)))
    (if (< n2 n1) (setq stop nil))
    ; ciclo anni
    (for (yy y1 y2 1 stop)
      ;ciclo mesi
      (for (mm 1 12 1 stop)
        (setq days (lookup mm md))
        ; mese febbraio e anno bisestile?
        (if (and (= mm 2) (leap? yy)) (setq days 29))
        ; ciclo giorni
        (for (dd 1 days 1 stop)
          ; data corrente
          (setq data (list yy mm dd))
          ; valore numerico data corrente
          (setq num-data (int (format "%d%02d%02d" yy mm dd)))
          ;controllo (data1 <= data corrente <= data2)
          (cond ((< num-data n1) nil)
                ((and (>= num-data n1) (<= num-data n2))
                  (push data out -1))
                ((> num-data n2 (setq stop true)))))))
    out))

;; @syntax (verify-date year)
;; @description Check if a date is valid
;; @param <date> date (year month day)
;; @return true or nil
;; @example
;; (verify-date '(1901 2 29))   ==> nil
;; (verify-date '(2024 4 31))   ==> nil
;; (verify-date '(2024 2 29))   ==> true
;; (verify-date '(2023 12 25))  ==> true
(define (verify-date data)
"Check if a date is valid"
  (letn ( (year (data 0)) (month (data 1)) (day (data 2))
          (days-month '(0 31 28 31 30 31 30 31 31 30 31 30 31))
          (bisestile (and (= 0 (mod year 4))
                          (or (!= 0 (mod year 100)) (= 0 (mod year 400))))) )
    (if bisestile (setf (days-month 2) 29))
    (not (or (< month 1) (> month 12) (< day 1) (> day (days-month month))))))

;===========================================================================
;===========================================================================
;; <p><b><center>Bit manipulation</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (bit1-count num)
;; @description Count the bit 1 of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (bits 312)       ==> "100111000"
;; (bit1-count 312)  ==> 4
(define (bit1-count num)
"Count the bit 1 of an integer"
  (let (counter 0)
    (while (> num 0)
      (setq num (& num (- num 1)))
      (++ counter))
    counter))

;; @syntax (bit0-count num)
;; @description Count the bit 0 of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (bits 312)       ==> "100111000"
;; (bit0-count 312)  ==> 5
(define (bit0-count num)
"Count the bit 0 of an integer"
  (- (length (bits num)) (bit1-count num)))

;; @syntax (get-bit num idx)
;; @description Get the bit at the idx-th position of an integer
;; @param <num> integer
;; @param <idx> bit index position
;; @return 1 or 0
;; @example
;; (bits 142)  ==> "10001110"
;; (map (fn(x) (get-bit 142 x)) (sequence 8 0))  ==> (0 1 0 0 0 1 1 1 0)
(define (get-bit num idx)
"Get the bit at the idx-th position of an integer"
  (if (zero? (& num (<< 1 idx))) 0 1))

;; @syntax (set-bit num idx)
;; @description Set the bit at the idx-th position of an integer
;; @param <num> integer
;; @param <idx> bit index position
;; @return integer
;; @example
;; (bits 142)  ==> "10001110"
;; (set-bit 142 0)  ==> 143
;; (bits 143)  ==> "10001111"
;; (set-bit 142 6)  ==> 206
;; (bits 206)  ==> "11001110"
(define (set-bit num idx)
"Set the bit at the idx-th position of an integer"
  (| num (<< 1 idx)))

;; @syntax (clear-bit num idx)
;; @description Clear the bit at the idx-th position of an integer
;; @param <num> integer
;; @param <idx> bit index position
;; @return integer
;; @example
;; (bits 142)  ==> "10001110"
;; (clear-bit 142 1)  ==> 140
;; (bits 140)  ==> "10001100"
;; (clear-bit 142 7)  ==> 14
;; (bits 14)  ==> "1110"
(define (clear-bit num idx)
"Clear the bit at the idx-th position of an integer"
  (let (mask (~ (<< 1 idx))) (& num mask)))

;; @syntax (toggle-bit num idx)
;; @description Toggle the bit at the idx-th position of an integer
;; @param <num> integer
;; @param <idx> bit index position
;; @return integer
;; @example
;; (bits 45)  ==> "101101"
;; (toggle-bit 45 3)  ==> 37
;; (bits 37)  ==> "100101"
(define (toggle-bit num idx)
"Toggle the bit at the idx-th position of an integer"
  (^ num (<< 1 idx)))

;; @syntax (toggle-bits num)
;; @description Toggle all the bits of num (complement)
;; @param <num> integer
;; @return integer
;; @example
;; (bits 45)  ==> "101101"
;; (toggle-bits 45 3)  ==> 18
;; (bits 18)  ==>  "10010"
(define (toggle-bits num)
  (letn ( (len (length (bits num))) ; numero di bit significativi
          ; mask = (2^len - 1)
          (mask (- (<< 1 len) 1)) ) ; crea una maschera di 1 (lunghezza = len)
    (^ num mask)))                  ; inverte solo i bit significativi

;; @syntax (get-lsb num)
;; @description Get the least significant bit of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (bits 36)     ==> "100100"
;; (get-lsb 36)  ==> 4
;; (bits 4)      ==> "100"
(define (get-lsb num)
"Get the least significant bit of an integer"
  (& num (- num)))

;; @syntax (clear-lsb num)
;; @description Clear the least significant bit of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (bits 312)       ==> "100111000"
;; (clear-lsb 312)  ==> 304
;; (bits 304)       ==> "100110000"
(define (clear-lsb num)
"Clear the least significant bit of an integer"
  (& num (- num 1)))

;; @syntax (get-msb num)
;; @description Get the most significant bit of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (bits 21) ==> "10101"
;; (get-msb 21)  ==> 16
;; (bits 16)     ==> "10000"
(define (get-msb num)
"Get the most significant bit of an integer"
  (let (INT_SIZE 64)
    (setq num (| num (>> num 1)))
    (setq num (| num (>> num 2)))
    (setq num (| num (>> num 4)))
    (setq num (| num (>> num 8)))
    (setq num (| num (>> num 16)))
    (setq num (| (>> (add num 1) 1)
              (& num (<< 1 (- INT_SIZE 1)))))
    num))

;; @syntax (clear-msb num)
;; @description Clear the most significant bit of an integer
;; @param <num> integer
;; @return integer
;; @example
;; (bits 312)       ==> "100111000"
;; (clear-msb 312)  ==> 56
;; (bits 56)        ==> "111000"
(define (clear-msb num)
"Clear the most significant bit of an integer"
  (& num (^ (<< 1 (- (length (bits num)) 1)) -1)))

;; @syntax (snoob x)
;; @description Find the next number with the same number of 1-bit
;; @param <x> integer
;; @return integer
;; @example
;; (setq x 7)
;; (collect (setq x (snoob x)) 10)  --> (11 13 14 19 21 22 25 26 28 35)
(define (snoob x)
"Find the next number with the same number of 1-bit"
  (letn (c (& x (- x))
         r (+ x c))
    (| r (/ (>> (^ r x) 2) c))))

;; @syntax (prev-pow2 x)
;; @description Find the first power of 2 less than or equal to a number
;; @param <x> integer
;; @return integer
;; @example
;; (map prev-pow2 '(63 64 65))  ==> (32 64 64)
(define (prev-pow2 x)
"Find the first power of 2 less than or equal to a number"
  (setq x (| x (>> x 1)))
  (setq x (| x (>> x 2)))
  (setq x (| x (>> x 4)))
  (setq x (| x (>> x 8)))
  (setq x (| x (>> x 16)))
  (setq x (| x (>> x 32)))
  (- x (>> x 1)))

;; @syntax (next-pow2 x)
;; @description Find the first power of 2 greater than or equal to a number
;; @param <x> integer
;; @return integer
;; @example
;; (map next-pow2 '(63 64 65))  ==> (64 64 128)
(define (next-pow2 x)
"Find the first power of 2 greater than or equal to a number"
  (setq x (- x 1))
  (setq x (| x (>> x 1)))
  (setq x (| x (>> x 2)))
  (setq x (| x (>> x 4)))
  (setq x (| x (>> x 8)))
  (setq x (| x (>> x 16)))
  (setq x (| x (>> x 32)))
  (+ x 1))

;===========================================================================
;===========================================================================
;; <p><b><center>CAR and CDR (Four levels: C????R)</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (car lst)
;; @description Return the first element of a list or the first character of a string
;; @param <list or string> list or string
;; @return atom or list or string
;; @example
;; (car '(a b c))             ==> a
;; (car '((a b) (c d)))       ==> (a b)
;; (car '())                  ==> ERR: list is empty
;; (car "abc")                ==> "a"
;; (car "")                   ==> ""
;; (cadr '(7 3 5))            ==> 3
;; (cadr (cdr '(7 3 5)))      ==> 5
;; (cadadr '(0 (1 2 3) 4 5))  ==> 2
;; (caddr '(7 3 5))           ==> 5
;(define (car x)
;"Return the first items in a list or string"
;  (first x))
(define car first)

;; @syntax (cdr lst)
;; @description Return all of the items in a list or a string, except for the first
;; @param <list or string> list or string
;; @return list or string
;; @example
;; (cdr '(a b c))             ==> (b c)
;; (cdr '((a b) (c d)))       ==> ((c d))
;; (cdr '((a b) c))           ==> (c)
;; (cdr '(a))                 ==> ()
;; (cdr '())                  ==> ()
;; (cdr "abc")                ==> "bc"
;; (cdr "")                   ==> ""
;; (cadr '(7 3 5))            ==> 3
;; (cadr (cdr '(7 3 5)))      ==> 5
;; (cadadr '(0 (1 2 3) 4 5))  ==> 2
;; (caddr '(7 3 5))           ==> 5
;(define (cdr x)
;"Return all of the items in a list or a string, except for the first"
;  (rest x))
(define cdr rest)

; -----------------------
; C????R (four levels)
; -----------------------
;(define (car x)    (first x))
;(define (cdr x)    (rest x))
(define (caar x)   (first (first x)))
(define (cadr x)   (first (rest x)))
(define (cdar x)   (rest (first x)))
(define (cddr x)   (rest (rest x)))
(define (caaar x)  (first (first (first x))))
(define (caadr x)  (first (first (rest x))))
(define (cadar x)  (first (rest (first x))))
(define (caddr x)  (first (rest (rest x))))
(define (cdaar x)  (rest (first (first x))))
(define (cdadr x)  (rest (first (rest x))))
(define (cddar x)  (rest (rest (first x))))
(define (cdddr x)  (rest (rest (rest x))))
(define (caaaar x) (first (first (first (first x)))))
(define (caaadr x) (first (first (first (rest x)))))
(define (caadar x) (first (first (rest (first x)))))
(define (caaddr x) (first (first (rest (rest x)))))
(define (cadaar x) (first (rest (first (first x)))))
(define (cadadr x) (first (rest (first (rest x)))))
(define (caddar x) (first (rest (rest (first x)))))
(define (cadddr x) (first (rest (rest (rest x)))))
(define (cdaaar x) (rest (first (first (first x)))))
(define (cdaadr x) (rest (first (first (rest x)))))
(define (cdadar x) (rest (first (rest (first x)))))
(define (cdaddr x) (rest (first (rest (rest x)))))
(define (cddaar x) (rest (rest (first (first x)))))
(define (cddadr x) (rest (rest (first (rest x)))))
(define (cdddar x) (rest (rest (rest (first x)))))
(define (cddddr x) (rest (rest (rest (rest x)))))

; ----------------------------------------
; Ordinal index for list, array and string
; ----------------------------------------
(define (second  x) (unless (>= 1 (length x)) (nth 1 x) 'nil))
(define (third   x) (unless (>= 2 (length x)) (nth 2 x) 'nil))
(define (fourth  x) (unless (>= 3 (length x)) (nth 3 x) 'nil))
(define (fifth   x) (unless (>= 4 (length x)) (nth 4 x) 'nil))
(define (sixth   x) (unless (>= 5 (length x)) (nth 5 x) 'nil))
(define (seventh x) (unless (>= 6 (length x)) (nth 6 x) 'nil))
(define (eigth   x) (unless (>= 7 (length x)) (nth 7 x) 'nil))
(define (ninth   x) (unless (>= 8 (length x)) (nth 8 x) 'nil))
(define (tenth   x) (unless (>= 9 (length x)) (nth 9 x) 'nil))

;===========================================================================
;===========================================================================
;; <p><b><center>MISCELLANEOUS</center></b></p>
;===========================================================================
;===========================================================================

;; @syntax (list-IM lst file-str)
;; @description Create a graphic file (RGBA 8 bit) from a list of coords (with ImageMagick)
;; @param <lst> list of points (x y) or (x y r g b) (x y r g b a) with x >= 0 and y >= 0
;; @param <file-str> name of text file
;; @return boolean (result of text file creation)
;; @example
;; ; Image Black-White (no Alpha):
;; (silent
;;   (setq x (rand 200 1000))
;;   (setq y (rand 200 1000))
;;   (setq IM1 (map list x y))
;; )
;; (list-IM IM1 "IM1.txt")
;; ; ImageMagick command
;; (exec "convert IM1.txt -background white -flatten IM1.png")
;;
;; ; Image RGB (no Alpha):
;; (setq IM2 (map (fn(x) (append x (list (rand 255) (rand 255) (rand 255)))) IM1))
;; (list-IM IM2 "IM2.txt")
;; ; ImageMagick command
;; (exec "convert IM2.txt -background white -flatten IM2.png")
;;
;; ; Image RGBA (with Alpha):
;; (setq IM3 (map (fn(x) (append x (list (rand 255)))) IM2))
;; (list-IM IM3 "IM3.txt")
;; ; ImageMagick command
;; (exec "convert IM3.txt -background white -flatten IM3.png")
(define (list-IM lst file-str)
"Create a graphic file (RGBA 8 bit) from a list of coords (with ImageMagick)"
  (local (outfile x-width y-height line)
    ; remove duplicate pixel
    (setq lst (sort (unique lst)))
    ; open output file
    (setq outfile (open file-str "write"))
    ;(print outfile { }) ; debug
    ; Calculate image dimension (width and height)
    (setq x-width (add 1 (apply max (map (fn(c) (c 0)) lst))))
    (setq y-height (add 1 (apply max (map (fn(c) (c 1)) lst))))
    ; write file (ImageMagick format: rgba, 8bit)
    (write-line outfile (string "# ImageMagick pixel enumeration: "
                (string x-width) "," (string y-height) ",256,rgba"))
    (setq mode (length (lst 0)))
    (cond ((= mode 2) ; only coords
            (dolist (el lst)
              (setq line (string (string (el 0)) ", " (string (el 1))
                    ": (0,0,0,255)")) ; color black with alpha=100%
              (write-line outfile line)))
          ((= mode 5) ; coords and r g b
            (dolist (el lst)
              (setq line (string (string (el 0)) ", " (string (el 1)) ": ("
                    (string (el 1)) ", " (string (el 2)) ", " (string (el 3))
                    ", 255)")) ; color r g b with alpha=100%
              (write-line outfile line)))
          ((= mode 6) ; coords and r g b a
            (dolist (el lst)
              (setq line (string (string (el 0)) ", " (string (el 1)) ": ("
                    (string (el 1)) ", " (string (el 2)) ", " (string (el 3))
                    ", " (string (el 4)))) ; color r g b with alpha=100%
              (write-line outfile line)))
          (true (println "Error: only 2, 5 or 6 elements are allowed")))
    (close outfile)))

;; @syntax (println-unix)
;; @description Print the args with \n (unix style)
;; @param <args> expressions to print
;; @return <> none
;; @example
;; (println-unix 12)  ==> 12 (with "\n")
(define-macro (println-unix)
"Print the args with \n (unix style)"
  (apply print (map eval (args)))
  (print "\n"))

;; @syntax (println-windows)
;; @description Print the args with \r\n (windows style)
;; @param <args> expressions to print
;; @return <> none
;; @example
;; (println-windows 12)  ==> 12 (with "\r\n")
(define-macro (println-windows)
"Print the args with \r\n (windows style)"
  (apply print (map eval (args)))
  (print "\r\n"))


;; @syntax (emit lst)
;; @description Print name and value of quoted symbols and values
;; @param <lst> list of quoted symbols and values
;; @return print name and value of each symbol and value
;; @example
;; (set 'xx 1234  'yy 1.234 'zz "newLISP" 'ww '(1 2 3 4))
;; (emit 'xx 'yy 'zz 'ww "test")
;; xx: 1234
;; yy: 1.234
;; zz: newLISP
;; ww: (1 2 3 4)
;; test: test
(define (emit)
"Print name and value of quoted symbols and values"
  (dolist (_s (args))
    (println (string _s ": ") (eval _s))))

;; @syntax (noecho expr)
;; @description Evaluate expr without echo on REPL (standard output)
;; @param <expr> expression to evaluate
;; @return <> none
;; @example
;; (noecho (println (+ 3 3)))  ==> 6
;; (noecho (setq seq (sequence 1 10)))
(define (noecho expr)
"Evaluate expr without echo on REPL (standard output)"
  (silent expr)
  (print "\r\n>"))

;; @syntax (fore color)
;; @description Change the color of terminal foreground (text) (ANSI sequence)
;; @param <color> integer (0..255)
;; @return nil
;; @example
;; (for (i 0 255) (print (string "\027[38;5;" i "m") i { }))
;; (for (i 0 255) (print (fore i) i { }))
(define (fore color)
"Change the color of terminal foreground (text) (ANSI sequence)"
  (let (f (string "\027[38;5;" color "m"))
    ;(print f "\r" "")))
    (print f)))

;; @syntax (back color)
;; @description Change the color of terminal background (ANSI sequence)
;; @param <color> integer (0..255)
;; @return nil
;; @example
;; (for (i 0 255) (print (back i) i { }))
(define (back color)
"Change the color of terminal background (ANSI sequence)"
  (let (b (string "\027[48;5;" color "m"))
    ;(print b "\r" "")))
    (print b)))

;; @syntax (ascii-table last-char)
;; @description Print the ASCII table
;; @param <last-char> last char to show (integer)
;; @return nil
;; @example
;; (ascii-table)
;; (32  )  (33 !)  (34 ")  (35 #)  (36 $)  (37 %)  (38 &)  (39 ')
;; (40 ()  (41 ))  (42 *)  (43 +)  (44 ,)  (45 -)  (46 .)  (47 /)
;; (48 0)  (49 1)  (50 2)  (51 3)  (52 4)  (53 5)  (54 6)  (55 7)
;; (56 8)  (57 9)  (58 :)  (59 ;)  (60 <)  (61 =)  (62 >)  (63 ?)
;; (64 @)  (65 A)  (66 B)  (67 C)  (68 D)  (69 E)  (70 F)  (71 G)
;; (72 H)  (73 I)  (74 J)  (75 K)  (76 L)  (77 M)  (78 N)  (79 O)
;; (80 P)  (81 Q)  (82 R)  (83 S)  (84 T)  (85 U)  (86 V)  (87 W)
;; (88 X)  (89 Y)  (90 Z)  (91 [)  (92 \)  (93 ])  (94 ^)  (95 _)
;; (96 `)  (97 a)  (98 b)  (99 c)  (100 d)  (101 e)  (102 f)  (103 g)
;; (104 h)  (105 i)  (106 j)  (107 k)  (108 l)  (109 m)  (110 n)  (111 o)
;; (112 p)  (113 q)  (114 r)  (115 s)  (116 t)  (117 u)  (118 v)  (119 w)
;; (120 x)  (121 y)  (122 z)  (123 {)  (124 |)  (125 })  (126 ~)
(define (ascii-table last-char)
"Print the ASCII table"
  (let (out '())
    (if (nil? last-char) (setq last-char 126))
    (for (i 32 last-char)
      (if (zero? (% (- i 32) 8)) (println))
      (print "(" i { } (char i) ")  "))
    (println)))

;; @syntax (ascii-map)
;; @description Print the ASCII table
;; @param none
;; @return list (code char)
;; @example
;; (ascii-map)
;; ((32 " ") (33 "!") (34 "\"") ... (124 "|") (125 "}") (126 "~"))
(define (ascii-map)
"Return the ASCII table"
  (map (fn(x) (list (+ 32 $idx) (char x))) (sequence 32 126)))

;; @syntax (papersize type num)
;; @description Calculate dimensions of standard paper (mm)
;; @param <type> paper type A, B, C
;; @param <num> paper number (0..9) (int)
;; @return list dimension (hor ver) of papersize (float)
;; @example
;; (papersize 'A 4)  ==> (210.2241038134286 297.3017787506803)
;; (papersize 'B 4)  ==> (250 353.5533905932738)
;; (papersize 'C 4)  ==> (229.2510108011678 324.2098886627524)
;; (papersize 'A 3)  ==> (297.3017787506803 420.4482076268573)
(define (papersize type num)
"Calculate dimensions of standard paper (mm)"
  (local (s0 s1)
    (cond ((= type 'A)
           (setq s0 (mul 1000 (pow 2 (div 1 4))))
           (setq s1 (div s0 (sqrt 2))))
          ((= type 'B)
           (setq s0 (mul 1000 (sqrt 2)))
           ;(setq s1 (div s0 (sqrt 2)))
           (setq s1 (mul 1000 1)))
          ((= type 'C)
           (setq s0 (mul 1000 (pow 8 (div 1 8))))
           (setq s1 (div s0 (sqrt 2)))))
    (list (papersize-aux (+ num 1)) (papersize-aux num))))
; calcola le dimensioni dei lati ricorsivamente
(define (papersize-aux num)
    (if (< num 2)
        (if (= num 0) s0 s1)       ; misure conosciute
        (div (papersize-aux (- num 2)) 2))) ; piegando due volte la lunghezza dei lati si dimezza

;; @syntax (cls)
;; @description Clear screen of REPL (ANSI sequence)
;; @param <> none
;; @return clear screen
;; @example
;; (cls)
(define (cls)
"Clear screen of REPL (ANSI sequence)"
  (print "\027[H\027[2J"))

;; @syntax (beep)
;; @description Play a beep (sound)
;; @param <> none
;; @return sound
;; @example
;; (beep)
(define (beep)
"Play a beep (sound)"
  (silent (print (char 7)))
  (print "\r\n>"))

;===========================================================================
; Return to main context
; (context MAIN)
;===========================================================================

; symbol of library
(setq yo-library true)
; eof